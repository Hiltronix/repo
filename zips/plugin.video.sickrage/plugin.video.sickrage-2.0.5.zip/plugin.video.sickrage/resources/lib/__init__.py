# Author: Hiltronix <info@hiltronix.com>
# URL: https://hiltronix.com/

tvdb_api_key = '9172FC36FB4E4523'
tvdb_user_name = '' 
tvdb_account_id = ''
