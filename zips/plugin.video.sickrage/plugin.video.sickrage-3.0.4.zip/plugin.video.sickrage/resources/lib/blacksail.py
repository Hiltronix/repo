# -*- coding: utf-8 -*-

import xbmc
import os
import sys
import json
import requests
import common
import settings
import time
from datetime import datetime
from datetime import timedelta


# Replace troublesome characters, that effect sorting.
def FixBadChar(text):
    text = text.replace(u'\u2019', u"'")  # Replace curved apostrophe ’ with standard ' apostrophe.
    text = text.replace(u'\u2010', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2011', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2012', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2013', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2014', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2015', u"-")  # Replace wide dash with standard hyphen.
    return text
    

def getFromDict(dataDict, mapList, default_result=None):
# Similar to dictionary '.get' but for nested dictionaies.
# Example: getFromDict(dataDict, ["b", "v", "y"])
# Returns 'None' if not found, unless a default result is provided.
    try:
        value = reduce(lambda d, k: d[k], mapList, dataDict)
        if value:
            return value
        else:
            return default_result
    except Exception:
        return default_result


def GetUrlData(url=None, headers={}, proxies={}, verify=False, log=None, timeout=10):
    # Fetches data from "url" (http or https) and return it as a string, with timeout.
    # Supply any headers and proxies as dict.
    # A default User-Agent will be added if the headers dict doesn't contain one.
    # Set "verify" True if you want SSL certs to be verified.
    # If using logging, pass your log handle.
    try:
        if not headers.get('User-Agent'):
            headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'

        response = requests.get(url, headers=headers, proxies=proxies, verify=verify, timeout=timeout)
        if response.status_code == 200:
            return response.content
        else:
            return None
    except requests.Timeout:
        common.messageWindow('Network Connection', 'The request timed out.[CR]The server may be busy or unavailable.')
        return None
    except Exception, e:
        #print e
        xbmc.log('sickrage.sickbeard.GetUrlData: {0}'.format(e), xbmc.LOGERROR)
        if log:
            log.debug('*** Exception ***', exc_info=1)
        err = 'Exception: {0}'.format(e)
        common.messageWindow('Network Connection', err)
        return None


# SickRage class which mas all API calls to SickRage.
class BS:

    CONNECT_ERROR = "Error: "

    
    def GetLoginToken(self, url, username, password, log=None):
    # Performs authentication and return token.
        try:
            data = {
                    "username": username,
                    "password": password
                   }
    
            headers = {'Content-Type': 'application/json',
                       'Content-Length': str(len(data))}
    
            response = requests.post(url + 'login', json.dumps(data), headers=headers, proxies={}, timeout=5)
            result = json.loads(response.content)
            return result.get('token', None), result.get('expires', 0)
        except Exception, e:
            print e
    
    
    def RefreshToken(self, log=None):
    # Login token is good for limited number of hours.
    # If login token is about to expire, then refresh the token.

        data = self.LoadToken()
        # Get the token from the saved dict.
        token = data.get('token', None)
        expires = data.get('expires', int(time.time()))

        # If token doesn't exist, fetch a new token from BlackSail API.
        # If token expires UTC time (less 30 seconds) is less than current UTC time, fetch a new token from BlackSail API.
        if not token or (expires - 30 < time.time()):
            token, expires = self.GetLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
            if not self.SaveToken(token, expires):
                log.debug('ERROR: BlackSail API Token save error!')
                return None

        return token


    def LoadToken(self):
    # Loads the saved token (JSON file) as a dictionary.
        data = {}
        try:
            filename = __file__
            filename = str.replace(filename, filename.rpartition('.')[2], 'json')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = json.load(f)
        except Exception, e:
            print e
        finally:
            return data


    def SaveToken(self, token, expires):
    # Saves the token in a dictionary as a JSON file.
        try:
            data = {'token': token, 'expires': expires}
            filename = __file__
            filename = str.replace(filename, filename.rpartition('.')[2], 'json')
            with open(filename, 'w') as f:
                json.dump(data, f, sort_keys=True, indent=4)
        except Exception, e:
            print e
            return False
        return True


    def ClearToken(self):
    # Deletes the token JSON file, so it will be recreated next call for a token refresh.
        try:
            filename = __file__
            filename = str.replace(filename, filename.rpartition('.')[2], 'json')
            os.remove(filename)
        except Exception, e:
            print e
            return False
        return True


    def Logout(self, url, token):
    # Performs logout operation.
        try:
            data = {
                    "token": token
                   }
    
            headers = {'Content-Type': 'application/json',
                       'Content-Length': str(len(data))}
    
            response = requests.post(url + 'logout', json.dumps(data), headers=headers, proxies={}, timeout=5)
            result = json.loads(response.content)
            return result
        except Exception, e:
            print e


    def GetFutureShows(self, paused, log=None):
    # Get list of upcoming episodes
    # "paused" must be 0 for False, or 1 for True, to include/exclude paused shows in the list.
        future_list = {'today': [], 'soon': [], 'later': []}
        token = self.RefreshToken(log)
        if not token:
            return future_list
        try:
            response = GetUrlData(url=settings.__url__ + 'upcoming?token={}&paused={}'.format(token, paused))
            if not response:
                return future_list
            result = json.loads(response)
            if 'invalid token' in result.get('message', '').lower():
                self.ClearToken()
                return future_list

            # Change dict key names to match Sickbeard.
            week = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
            for each in result['data']:
                try:
                    each['airdate'] = each.pop('airsDate')
                    each['airs'] = each.pop('airsTime')
                    each['ep_name'] = each.pop('episodeName')
                    each['ep_plot'] = each.pop('overview')
                    each['indexerid'] = each.pop('dataProvider')
                    each['quality'] = ''
                    each['show_name'] = each.pop('showName')
                    each['show_status'] = each.pop('status')
                    each['weekday'] = each.pop('dayOfWeek')
                    each['weekday'] = week.index(each['weekday'])+1 if each['weekday'] in week else ''
                except Exception, e:
                    common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
                    xbmc.log('Renaming dict key names: {}'.format(e), level=xbmc.LOGERROR)
                    trbk = traceback.format_exc()
                    xbmc.log(trbk, level=xbmc.LOGERROR)
    
            dtNow = datetime.now().strftime("%Y-%m-%d")
            try:
                dtWeek = datetime.strptime(dtNow,"%Y-%m-%d") + timedelta(days=6)
            except TypeError:
                dtWeek = datetime(*(time.strptime(dtNow,"%Y-%m-%d")[0:6])) + timedelta(days=6)
            dtWeek = dtWeek.strftime("%Y-%m-%d")
            data = {}
            today = []
            soon = []
            later = []
            for each in result['data']:
                if each.get('airdate') == dtNow:
                    today.append(each)
                if each.get('airdate') > dtNow and each.get('airdate') <= dtWeek:
                    soon.append(each)
                if each.get('airdate') > dtWeek:
                    later.append(each)
            data['today'] = today
            data['soon'] = soon
            data['later'] = later
            data = {'data': data}
            
            future_list = data.get('data')
        except Exception, e:
            xbmc.log(self.CONNECT_ERROR+str(e), level=xbmc.LOGERROR)
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return future_list
    

    def GetShows(self, log=None):
    # Get the list of shows.
        shows = []
        token = self.RefreshToken(log)
        if not token:
            return shows
        try:
            response = GetUrlData(url=settings.__url__ + 'shows?token={}'.format(token))
            if not response:
                return shows
            result = json.loads(response)
            if 'invalid token' in result.get('message', '').lower():
                self.ClearToken()
                return shows

            for each in result['data']:
                show = {}
                # Minimum required fields listed first.
                show['tvdbid'] = each.get('tvdbId', '')
                show['show_name'] = each.get('show_name', '')
                show['paused'] = each.get('paused', 0)
                show['status'] = each.get('status', '')
                show['next_ep_airdate'] = each.get('firstAired', '')
                show['anime'] = each.get('anime', '')
                show['indexerid'] = each.get('dataProvider', '')
                show['language'] = each.get('language', 'en')
                show['network'] = each.get('network', '')
                show['quality'] = each.get('quality', '')
                show['sports'] = each.get('sports', '')
                show['subtitles'] = each.get('subtitles', '')
                show['tvrage_id'] = each.get('tvrage_id', '')
                show['tvrage_name'] = each.get('tvrage_name', '')
                shows.append(show)
        except Exception, e:
            xbmc.log(self.CONNECT_ERROR+str(e), level=xbmc.LOGERROR)
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return shows
    

    def GetVersion(self):
    # Get the version of SickRage.
        api = 'Unknown'
        version = 'Unknown'
        try:
            response = GetUrlData(url=settings.__url__ + 'version')
            if not response:
                return None
            result = json.loads(response)
            api = result.get('api_version', api)
            version = result.get('server_version', version)
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return api, version
    

    def GetSeasonNumberList(self, show_id, log=None):
    # Return a list of the season numbers.
        season_number_list = []
        token = self.RefreshToken(log)
        if not token:
            return season_number_list
        try:
            response = GetUrlData(url=settings.__url__ + 'seasonlist?token={}&tvdbid={}'.format(token, show_id))
            if not response:
                return
            result = json.loads(response)
            if 'invalid token' in result.get('message', '').lower():
                self.ClearToken()
                return season_number_list

            season_number_list = getFromDict(result, ['data', 'airedSeasons'], [])
            # Convert string values to int in list.
            season_number_list = map(int, season_number_list)
            season_number_list.sort()
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return season_number_list
    

    def GetSeasonEpisodeList(self, show_id, season, log=None):
    # Get the list of episodes in a given season.
        season_episodes = []
        token = self.RefreshToken(log)
        if not token:
            return season_episodes
        try:
            season = str(season)
            response = GetUrlData(url=settings.__url__+'seasonepisodes?token={}&tvdbid={}&season={}'.format(token, show_id, season))
            if not response:
                return
            result = json.loads(response)
            season_episodes = result.get('data')
              
            # Change dict key names to match Sickbeard.
            for each in season_episodes:
                try:
                    season_episodes[each]['airdate'] = season_episodes[each]['firstAired']
                    season_episodes[each]['file_size'] = 0
                    season_episodes[each]['location'] = ''
                    season_episodes[each]['name'] = season_episodes[each]['episodeName']
                    season_episodes[each]['quality'] = ''
                    season_episodes[each]['release_name'] = ''
                    season_episodes[each]['status'] = ''
                    season_episodes[each]['subtitles'] = ''
                except Exception, e:
                    common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
                    xbmc.log('Renaming dict key names: {}'.format(e), level=xbmc.LOGERROR)
                    trbk = traceback.format_exc()
                    xbmc.log(trbk, level=xbmc.LOGERROR)
    
            # Make episode number 2 digit string if a single digit, Ex: 1 becomes 01.
            for key in season_episodes.iterkeys():
                if int(key) < 10:
                    newkey = '{0}'.format(key.zfill(2))
                    if newkey not in season_episodes:
                        season_episodes[newkey] = season_episodes[key]
                        del season_episodes[key]
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))        
        return season_episodes
    

    def GetShowPoster(self, show_id, update=False, log=None):
    # Check if there is a cached poster image to use.
    # If not get image from server, and save in local cache.
    # Returns path to image if found.
    # If not found, or object is less than 1K meaning it's a json error message, then get generic image.
        data = {}
        if show_id == '0':
            return ''
        file_path = settings.image_cache_dir + show_id + '.poster.jpg'
        if not os.path.exists(file_path) or update:
            token = self.RefreshToken(log)
            if not token:
                return ''
            # Download image from BlackSail server.
            try:
                data = GetUrlData(url=settings.__url__+'getimage?token={}&tvdbid={}&image=poster'.format(token, show_id))
                if data.get('result') != 'success':
                    # Get generic image instead.
                    with open(xbmc.translatePath('special://home/addons/plugin.video.sickrage/resources/images/missing_poster.jpg'), mode='rb') as f:
                        image = f.read()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
                return ''
            # Write image file to local cache.
            try:
                if not os.path.exists(os.path.dirname(file_path)):
                    os.makedirs(os.path.dirname(file_path))
                f = open(file_path, 'wb+')
                f.write(base64.b64decode(data.get('data')))
                f.close()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, str(e))
        return file_path


    def GetShowFanArt(self, show_id, update=False, log=None):
    # Check if there is a cached fanart image to use.
    # If not get image from server, and save in local cache.
    # Returns path to image if found.
    # If not found, or object is less than 1K meaning it's a json error message, then get generic image.
        data = {}
        if show_id == '0':
            return ''
        file_path = settings.image_cache_dir + show_id + '.fanart.jpg'
        if not os.path.exists(file_path) or update:
            token = self.RefreshToken(log)
            if not token:
                return ''
            # Download image from BlackSail server.
            try:
                data = GetUrlData(url=settings.__url__+'getimage?token={}&tvdbid={}&image=fanart'.format(token, show_id))
                if data.get('result') != 'success':
                    # Get generic image instead.
                    with open(xbmc.translatePath('special://home/addons/plugin.video.sickrage/resources/images/missing_fanart.jpg'), mode='rb') as f:
                        image = f.read()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
                return ''
            # Write image file to local cache.
            try:
                if not os.path.exists(os.path.dirname(file_path)):
                    os.makedirs(os.path.dirname(file_path))
                f = open(file_path, 'wb+')
                f.write(base64.b64decode(data.get('data')))
                f.close()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, str(e))
        return file_path


    def GetShowBanner(self, show_id, update=False, log=None):
    # Check if there is a cached banner image to use.
    # If not get image from server, and save in local cache.
    # Returns path to image if found.
    # If not found, or object is less than 1K meaning it's a json error message, then get generic image.
        data = {}
        if show_id == '0':
            return ''
        file_path = settings.image_cache_dir + show_id + '.banner.jpg'
        if not os.path.exists(file_path) or update:
            token = self.RefreshToken(log)
            if not token:
                return ''
            # Download image from BlackSail server.
            try:
                data = GetUrlData(url=settings.__url__+'getimage?token={}&tvdbid={}&image=series'.format(token, show_id))
                if data.get('result') != 'success':
                    # Get generic image instead.
                    with open(xbmc.translatePath('special://home/addons/plugin.video.sickrage/resources/images/missing_banner.jpg'), mode='rb') as f:
                        image = f.read()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
                return ''
            # Write image file to local cache.
            try:
                if not os.path.exists(os.path.dirname(file_path)):
                    os.makedirs(os.path.dirname(file_path))
                f = open(file_path, 'wb+')
                f.write(base64.b64decode(data.get('data')))
                f.close()
            except Exception, e:
                common.errorWindow(sys._getframe().f_code.co_name, str(e))
        return file_path


    def SetPausedState(self, paused, show_id, log=None):
    # Set the "paused" field in the database.
        message = ""
        token = self.RefreshToken(log)
        if not token:
            return message
        try:
            response = GetUrlData(url=settings.__url__+'paused?token={}&tvdbid={}&paused={}'.format(token, show_id, paused))
            if not response:
                return None
            result = json.loads(response)
            message = result.get('message')
            success = result.get('result')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return message
    

    # Return a list of the last 'num_entries' snatched/downloaded episodes.
    def GetHistory(self, num_entries):
        history = []
        xbmc.log('sickbeard.GetHistory')
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=history&limit='+str(num_entries))
            if not response:
                return None
            result = json.loads(response)
            history = result.get('data')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return history
    

    # Return a list of the default settings for adding a new show.
    def GetDefaults(self):
        defaults = []
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=sb.getdefaults')
            if not response:
                return None
            result = json.loads(response)
            print result.keys()
            defaults_data = result.get('data')
            if defaults_data:
                defaults = [defaults_data['status'], defaults_data['flatten_folders'], str(defaults_data['initial'])]
            else:
                defaults = ['skipped', 1, ["sdtv", "sddvd", "hdtv", "rawhdtv", "fullhdtv", "hdwebdl", "fullhdwebdl", "hdbluray", "fullhdbluray", "unknown"]]
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return defaults
    

    # Return a list of the save paths set in SickRage.
    def GetRootDirs(self):
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=sb.getrootdirs')
            if not response:
                return None
            result = json.loads(response)
            result = result.get('data')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return result
    

    # Set the status of an episode.
    def SetShowStatus(self, tvdbid, season, ep, status):
        result = []
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=episode.setstatus&tvdbid='+str(tvdbid)+'&season='+str(season)+'&episode='+str(ep)+'&status='+status+'&force=True')
            if not response:
                return None
            result = json.loads(response)
            # No result is actually returned from this call.
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return result
    

    # Add a new show to SickRage.
    def AddNewShow(self, tvdbid, location, prev_aired_status, future_status, flatten_folders, quality):
        result = ""
        try:
            url = settings.__url__+'?cmd=show.addnew&tvdbid='+str(tvdbid)+'&location='+location+'&status='+prev_aired_status+'&future_status='+future_status+'&flatten_folders='+str(flatten_folders)+'&initial='+quality
            print 'Add Show Request:' + url
            response = GetUrlData(url=url)
            result = json.loads(response)
            success = result.get('result', 'Unknown result!')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return success
    

    def ForceSearch(self, show_id):
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=show.update&tvdbid='+show_id)
            if not response:
                return None
            result = json.loads(response)
            message = result.get('message')
            success = result.get('result')
            common.errorWindow("Force Update", message + " ["+success+"]")
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))

    
    def ForceDownload(self, tvdbid, season, ep):
        message = ""
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=episode.search&tvdbid='+str(tvdbid)+'&season='+str(season)+'&episode='+str(ep), timeout=120)
            if not response:
                return None
            result = json.loads(response)
            message = result.get('message')
            success = result.get('result')
            common.errorWindow(sys._getframe().f_code.co_name, message + " ["+success+"]")
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return message
    

    def DeleteShow(self, tvdbid, removefiles):
        message = ""
        try:
            response = GetUrlData(url=settings.__url__+'?cmd=show.delete&tvdbid='+str(tvdbid)+'&removefiles='+str(removefiles))
            result = json.loads(response)
            message = result.get('message')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return message
      

    # Get the backlog list.
    def GetBacklog(self):
        results = [] 
        try:
            response = GetUrlData(url=settings.__url__+"?cmd=backlog")
            if not response:
                return None
            result = json.loads(response)
            for show in result['data']:
                show_name = show['show_name']
                status = show['status']
                for episode in show['episodes']:
                    episode['show_name'] = show_name
                    episode['status'] = status
                    results.append(episode)
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return results


    # Get the log file.  min_level: ["error", "warning", "info", "debug"]
    def GetLog(self, min_level):
        log_list = []
        try:
            response = GetUrlData(url=settings.__url__ + '?cmd=logs&min_level=' + str(min_level))
            if not response:
                return None
            result = json.loads(response)
            log_list = result.get('data')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return log_list

      
    # Run Post Processing.
    def PostProcessing(self):
        try:
            response = GetUrlData(url=settings.__url__ + '?cmd=postprocess', timeout=120)
            if not response:
                return None
            result = json.loads(response)
            msg = result.get('message')
            res = result.get('result')
        except Exception, e:
            common.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return msg, res
      

