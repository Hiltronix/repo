import xbmc
import xbmcgui
import sys
import common
import settings
import blacksail
import sickbeard


# Initialize Classes
Sickbeard = sickbeard.SB()
BlackSail = blacksail.BS()


__tvdbid__ = sys.argv[1]
__season__ = sys.argv[2]
__episode__ = sys.argv[3]


def statusSelection():
# Show status selection dialog.
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Set Status", ["Wanted", "Skipped", "Archived", "Ignored"])
    return ret  

  
def setStatus(status):
# Set the status of a show.
    status_list = ["wanted", "skipped", "archived", "ignored"]
    episode_list = []
    
    if "|" in __episode__:
        episode_list = __episode__.split("|")
        for ep in episode_list:
            if (settings.__servertype__ == settings.BlackSail):
                BlackSail.SetShowStatus(__tvdbid__, __season__, ep, status_list[status])
            else:
                Sickbeard.SetShowStatus(__tvdbid__, __season__, ep, status_list[status])
    else:
        if (settings.__servertype__ == settings.BlackSail):
            BlackSail.SetShowStatus(__tvdbid__, __season__, __episode__, status_list[status])
        else:
            Sickbeard.SetShowStatus(__tvdbid__, __season__, __episode__, status_list[status])


status = statusSelection()
if (status != -1):
    result = setStatus(status)
    if result:
        common.messageWindow('Set Episode Status', result)
    xbmc.executebuiltin("Container.Refresh")
