import settings
import blacksail
import sickbeard


# Initialize Classes
Sickbeard = sickbeard.SB()
BlackSail = blacksail.BS()


__tvdbid__ = sys.argv[1]

if (settings.__servertype__ == settings.BlackSail):
    BlackSail.ForceSearch(__tvdbid__)
else:
    Sickbeard.ForceSearch(__tvdbid__)
