import xbmc
import xbmcgui
import settings
import blacksail
import sickbeard


# Initialize Classes
Sickbeard = sickbeard.SB()
BlackSail = blacksail.BS()


# Show error pop up then exit plugin
def messageWindow(message):
    dialog = xbmcgui.Dialog()
    dialog.ok("Show Status", message)


paused = sys.argv[1]
tvdbid = sys.argv[2]

if paused == "Pause":
    pause = "1"
else:
    pause = "0"
    
if (settings.__servertype__ == settings.BlackSail):
    message = BlackSail.SetPausedState(pause, tvdbid)
else:
    message = Sickbeard.SetPausedState(pause, tvdbid)
messageWindow(message)
xbmc.executebuiltin("Container.Refresh")

