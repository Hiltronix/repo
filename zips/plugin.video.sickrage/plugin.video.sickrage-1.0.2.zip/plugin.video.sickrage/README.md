# plugin.video.sickrage
SickRage Interface Addon for Kodi/XBMC

This is an addon/plugin for the Kodi/XBMC Home Theatre software.
It allows the user to view and control SickRage from within Kodi/XBMC.

Note:
This is an updated version of the Sickbeard plugin created by Zach Moore.
It expands on his original work starting at his version 1.0.10.
