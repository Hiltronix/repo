import lookup
from BeautifulSoup import BeautifulSoup


def getMovie(id):
    url = "http://www.imdb.com/title/" + id
    try:
        content = lookup.GetUrlData(url)
        soup = BeautifulSoup(content)
        #hxs = lxml.html.document_fromstring(requests.get("http://www.imdb.com/title/" + id).content)
    except Exception, e:
        print "Error: %s  Getting data from: %s" %(e, url)

    #print soup.prettify()

    meta = {}
    try:
        # <meta property='og:title' content="Aliens (1986)" />
        meta['title'] = soup.find('meta', {'property':'og:title'}).get('content')
    except IndexError:
        meta['title']

    return meta


