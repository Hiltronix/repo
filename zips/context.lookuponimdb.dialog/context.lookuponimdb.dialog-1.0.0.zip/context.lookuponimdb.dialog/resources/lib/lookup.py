import re
import json
import urllib2
import xbmc
import xbmcgui
import resources.lib.common as common


def RemoveHtmlTags(text):
    HTML_RE = re.compile(r'<[^>]+>')
    return HTML_RE.sub('', text)


def RemovePerenthTags(text):
    PERENTH_RE = re.compile(r'\([^\)]+\)')
    return PERENTH_RE.sub('', text)


def UrlSafe(s, char):
     # Remove all non-word characters (everything except numbers and letters)
     s = re.sub(r"[^\w\s]", '', s)
     # Replace all runs of whitespace with a single 'char'
     s = re.sub(r"\s+", char, s)
     return s


def GetUrlData(url=None, add_useragent=False):
    # Fetches data from "url" (http or https) and return it as a string, with timeout.
    attempts = 0
    request = urllib2.Request(url)
    if add_useragent:
        headers = {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:32.0) Gecko/20100101 Firefox/32.0'}
        for (key, value) in headers.iteritems():
            request.add_header(key, value)
    # Try up to 3 times to make connection.
    while (attempts < 3):
        try:
            # Wait 5 seconds for connection.
            response = urllib2.urlopen(request, timeout=5)
            data = response.read()
            return data
        except:
            print "Timeout getting data from: %s" % url
            time.sleep(0.5)
            attempts += 1
    return None


def DoImdbLookupMovie(search_text):
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    try:
        search_text = RemovePerenthTags(search_text)  # Remove years enclosed in round brackets.
        search_text = search_text.strip()             # Strip leading and trailing spaces.
        text = UrlSafe(search_text, '+')              # Replace spaces with '+'.  
        
        url = "http://www.imdb.com/xml/find?json=1&nr=1&ttype=ft&tt=on&q=" + text
        
        try:
            response = GetUrlData(url, False)
            result = json.loads(response)
            #print json.dumps(response,indent=2)
        except Exception, e:
            common.messageWindow('Get Data Error', str(e))
            return '', ''
        
        data = []
        try:
            data += result['title_exact']
        except:
            pass
        try:
            data += result['title_popular']
        except:
            pass
        try:
            data += result['title_approx']
        except:
            pass
        try:
            data += result['title_substring']
        except:
            pass
        
        names = []
        imdb_id = []
        for show in data:
            desc = show['title_description']
            desc = RemoveHtmlTags(desc)
            desc = UrlSafe(desc, ' ')
            if len(desc) > 0:
                desc = '('+desc+')'
            names.append(show['title'] + ' ' + desc)
            imdb_id.append(show['id'])

    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
    
    if len(names) == 0:
        common.CreateNotification(header="Not Found", message=search_text, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
        return '', ''
        
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select from IMDB Results', names)

    if ret == -1:
        return '', ''
    else:
        return imdb_id[ret], names[ret]


def DoImdbLookupTVShow(search_text):
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    try:
        search_text = RemovePerenthTags(search_text)  # Remove years enclosed in round brackets.
        search_text = search_text.strip()             # Strip leading and trailing spaces.
        text = UrlSafe(search_text, '+')              # Replace spaces with '+'.  
        
        url = "http://www.imdb.com/xml/find?json=1&nr=1&ttype=ts&tt=on&q=" + text
        
        try:
            response = GetUrlData(url, False)
            result = json.loads(response)
            #print json.dumps(response,indent=2)
        except Exception, e:
            common.messageWindow('Get Data Error', str(e))
            return '', ''
        
        data = []
        try:
            data += result['title_exact']
        except:
            pass
        try:
            data += result['title_popular']
        except:
            pass
        try:
            data += result['title_approx']
        except:
            pass
        try:
            data += result['title_substring']
        except:
            pass
        
        names = []
        imdb_id = []
        for show in data:
            desc = show['title_description']
            desc = RemoveHtmlTags(desc)
            desc = UrlSafe(desc, ' ')
            if len(desc) > 0:
                desc = '('+desc+')'
            names.append(show['title'] + ' ' + desc)
            imdb_id.append(show['id'])

    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
    
    if len(names) == 0:
        common.CreateNotification(header="Not Found", message=search_text, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
        return '', ''
        
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select from IMDB Results', names)

    if ret == -1:
        return '', ''
    else:
        return imdb_id[ret], names[ret]


def DoImdbLookupEpisode(search_text):
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    try:
        search_text = RemovePerenthTags(search_text)  # Remove years enclosed in round brackets.
        search_text = search_text.strip()             # Strip leading and trailing spaces.
        text = UrlSafe(search_text, '+')              # Replace spaces with '+'.  
        
        url = "http://www.imdb.com/xml/find?json=1&nr=1&ep=on&q=" + text
        
        try:
            response = GetUrlData(url, False)
            result = json.loads(response)
            #print json.dumps(response,indent=2)
        except Exception, e:
            common.messageWindow('Get Data Error', str(e))
            return '', ''
        
        data = []
        try:
            data += result['title_exact']
        except:
            pass
        try:
            data += result['title_popular']
        except:
            pass
        try:
            data += result['title_approx']
        except:
            pass
        try:
            data += result['title_substring']
        except:
            pass
        
        tv_series = []
        names = []
        imdb_id = []
        for show in data:
            names.append(show['episode_title'])
            imdb_id.append(show['id'])
            tv_series.append(show['episode_title'].split(':')[0])

    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
    
    if len(names) == 0:
        common.CreateNotification(header="Not Found", message=search_text, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
        return '', ''
        
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select from IMDB Results', names)

    if ret == -1:
        return '', ''
    else:
        return tv_series[ret], names[ret]


def DoImdbLookupPeople(search_text):
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    try:
        search_text = RemovePerenthTags(search_text)  # Remove years enclosed in round brackets.
        search_text = search_text.strip()             # Strip leading and trailing spaces.
        text = UrlSafe(search_text, '+')              # Replace spaces with '+'.  
        
        #url = "http://www.imdb.com/xml/find?json=1&nr=1&tt=on&q=" + text
        #url = "http://www.imdb.com/xml/find?json=1&nr=1&ep=on&q=" + text
        url = "http://www.imdb.com/xml/find?json=1&nr=1&nm=on&q=" + text
        #url = "http://www.imdbapi.com/?s=" + text + "&r=json&type=movie"
        
        try:
            response = GetUrlData(url, False)
            result = json.loads(response)
            #print json.dumps(response,indent=2)
        except Exception, e:
            common.messageWindow('Get Data Error', str(e))
            return '', ''
        
        data = []
        try:
            data += result['name_exact']
        except:
            pass
        try:
            data += result['name_popular']
        except:
            pass
        try:
            data += result['name_approx']
        except:
            pass
        try:
            data += result['name_substring']
        except:
            pass
        
        names = []
        name = []
        imdb_id = []
        for show in data:
            desc = show['description']
            desc = RemoveHtmlTags(desc)
            desc = UrlSafe(desc, ' ')
            if len(desc) > 0:
                desc = '('+desc+')'
            names.append(show['name'] + ' ' + desc)
            name.append(show['name'])
            imdb_id.append(show['id'])

    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
    
    if len(names) == 0:
        common.CreateNotification(header="Not Found", message=search_text, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
        return '', ''
        
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select from IMDB Results', names)

    if ret == -1:
        return '', ''
    else:
        return imdb_id[ret], name[ret]


