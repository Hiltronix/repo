import xbmc
import xbmcgui
import resources.lib.common as common
import resources.lib.lookup as lookup
import resources.lib.imdb as imdb


def SearchDialog(search_text):
    # Get search text from user.
    keyboard = xbmc.Keyboard(search_text, 'Enter Search Text', False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        search_text = keyboard.getText()
    else:
        search_text = ''
    return search_text  


def GetSearchText(labelL, title, tvshow):
    if title:
        return title
    elif tvshow:
        return tvshow
    else:
        return labelL


def SearchType():
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Search as...', ['Movie Title', 'TV Series Title', 'TV Episode', "Person's Name"])
    return ret
        

# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
        param=[]
        try:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                  params=sys.argv[2]
                  cleanedparams=params.replace('?','')
                  if (params[len(params)-1]=='/'):
                          params=params[0:len(params)-2]
                  pairsofparams=cleanedparams.split('&')
                  param={}
                  for i in range(len(pairsofparams)):
                          splitparams={}
                          splitparams=pairsofparams[i].split('=')
                          if (len(splitparams))==2:
                                  param[splitparams[0]]=splitparams[1]
          return param
        except:
          return param
          
          
# Initialize URL parameters.
type = None
text = None
params = getParameters()

# Get various possible labels.
labelL = xbmc.getInfoLabel('ListItem.Label')
labelR = xbmc.getInfoLabel('ListItem.Label2')
title = xbmc.getInfoLabel('ListItem.Title')
tvshow = xbmc.getInfoLabel("ListItem.TVShowTitle")
imdb_id = xbmc.getInfoLabel('ListItem.IMDBNumber')
dbid = xbmc.getInfoLabel("ListItem.DBID")
prop_id = xbmc.getInfoLabel("ListItem.Property(id)")

if text == None:
    search_text = GetSearchText(labelL, title, tvshow)
    search_text = SearchDialog(search_text)
    if search_text == '':
        exit()
else:
    search_text = text

if type == None:
    type = SearchType()
    if type == -1:
        exit()
    
if type == 0: # Movie Title
    # Lookup on IMDB and select from list created from json.
    imdb_id, name = lookup.DoImdbLookupMovie(search_text)
    if imdb_id == '':
        exit()
    meta = {}
    try:
        meta = imdb.getMovie(imdb_id)
    except:
        common.CreateNotification(header="Error retrieving data for", message=name, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
    list_item = xbmcgui.ListItem(search_text, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    list_item.setInfo(type="Video", infoLabels=meta)
    xbmcplugin.setContent(handle=int(sys.argv[1]), content='movies')
    xbmc.executebuiltin("ActivateWindow(movieinformation)")

if type == 1: # TV Show Title
    # Lookup on IMDB and select from list created from json.
    imdb_id, name = lookup.DoImdbLookupTVShow(search_text)
    if imdb_id == '':
        exit()
    meta = {}
    try:
        meta = imdb.getTVShow(imdb_id)
    except:
        common.CreateNotification(header="Error retrieving data for", message=name, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
    list_item = xbmcgui.ListItem(search_text, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    list_item.setInfo(type="Video", infoLabels=meta)
    xbmcplugin.setContent(handle=int(sys.argv[1]), content='tvshows')
    xbmc.executebuiltin("ActivateWindow(videos)")

if type == 2: # TV Epsiode
    # Lookup on IMDB and select from list created from json.
    imdb_id, name = lookup.DoImdbLookupEpisode(search_text)
    if imdb_id == '':
        exit()
    meta = {}
    try:
        meta = imdb.getEpisode(imdb_id)
    except:
        common.CreateNotification(header="Error retrieving data for", message=name, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
    list_item = xbmcgui.ListItem(search_text, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    list_item.setInfo(type="Video", infoLabels=meta)
    xbmcplugin.setContent(handle=int(sys.argv[1]), content='episodes')
    xbmc.executebuiltin("ActivateWindow(videos)")


if type == 3: # Person's Name
    imdb_id, name = lookup.DoImdbLookupPeople(search_text)
    if imdb_id == '':
        exit()
    meta = {}
    try:
        meta = imdb.getPeople(imdb_id)
    except:
        common.CreateNotification(header="Error retrieving data for", message=name, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=True)
    list_item = xbmcgui.ListItem(search_text, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    list_item.setInfo(type="Video", infoLabels=meta)
    xbmcplugin.setContent(handle=int(sys.argv[1]), content='artists')
    xbmc.executebuiltin("ActivateWindow(videos)")

