# context.lookuponimdb.dialog  
#### Lookup on IMDb  

Lookup the selected or manually entered video title, episode or cast member, on the IMDb.  

-----

## Kodi/XBMC Repo  
The repository for this add-on can be found here:  

https://github.com/Hiltronix/repo/

OR

https://hiltronix.com/xbmc/

-----

## [Donations](https://hiltronix.com/donations/)  

If you would like to show your appreciation for this project, and/or help support it to keep it current, please consider making a donation.  
[Click Here](https://hiltronix.com/donations/).  
[![Support the project](https://github.com/Hiltronix/repo/blob/master/images/donate.png)](https://hiltronix.com/donations/)

