'''
Created on Mar 29, 2012

@author: Iulian Postaru
'''



from pprint import pprint
#from utils import *
import urllib, sys, os, re, time
from DelugeWebUI import DelugeWebUI
import json
#import urllib2

host = '192.168.56.101'
port = '8112'
url = 'http://' + host + ':' + port + '/json'
password = 'deluge'

ui = DelugeWebUI(url)

def main():
    res = ui.login(password)
    #print res

    res = ui.connected()
    print res
    
    torrents = ui.getTorrentListByLabel('house')
    labels = ui.getStateList(torrents)
    for element in labels:
        print str(element)
        #print ui.getTorrentFiles(element.torrentId)
    
    #print ui.getTorrentFiles('8ac3731ad4b039c05393b5404afa6e7397810b41')
    '''
    res = webUI.connectToFirstHost()
    
    res = webUI.getLabelsFilters()
    for element in res:
        print element.name
        print element.count
    '''
    #res = ui.getLabelsFilters()
    #print res
    
    #res = ui.updateUi()
    #jdata = json.loads(res)
    #pprint(jdata)
    
    #res = ui.getHosts()
    #print res
    
    #res = ui.getHostStatus('672f9462bf40ceac58159d4fd9126e62d82f72dc')
    #print res
    
    #res = ui.isHostOnline('672f9462bf40ceac58159d4fd9126e62d82f72dc')
    #print res
    
    #res = ui.connect('672f9462bf40ceac58159d4fd9126e62d82f72dc')
    #print res
    
    #res = ui.isHostOnline('672f9462bf40ceac58159d4fd9126e62d82f72dc')
    #print res
    
    #res = ui.connectToFirstHost()
    #print res
    #res = ui.connected()
    #print res
    '''
    res = webUI.getHosts()
    for element in res:
        print element[0]
        print element[1]
        print element[2]
        print element[3]
    #res = webUI.getHostStatus('672f9462bf40ceac58159d4fd9126e62d82f72dc')
    #print res
   
    list = webUI.getStateFilters()
    for element in list:
        print element[0]
        print element[1]
'''
    #print res
    #jsonRes = ui.pauseTorrent('8ac3731ad4b039c05393b5404afa6e7397810b41')
    #print jsonRes
    #res = webUI.removeTorrent('083639646ba9ddcc2155b59b5a1f194ca7125cb7', False)
    #print res
    
if __name__ == '__main__':
    main()