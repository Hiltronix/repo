# plugin.videolookup
#### Video Lookup

Lookup the highlighted video title, episode or cast member.  

-----

## Repo  
The repository for this add-on can be found here:  

https://github.com/Hiltronix/repo/

OR

https://hiltronix.com/xbmc/

-----

## Related Links

#### None:  
https://www.

-----

## Known Issues  

#### None Yet...  
- .  
- .  
- .  

-----

## Notes

.  


