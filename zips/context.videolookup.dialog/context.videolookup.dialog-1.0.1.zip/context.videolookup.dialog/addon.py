import xbmc
import xbmcgui
import resources.lib.common as common
import resources.lib.lookup as lookup


def SearchDialog(search_text):
    # Get search text from user.
    keyboard = xbmc.Keyboard(search_text, 'Enter Search Text', False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        search_text = keyboard.getText()
    else:
        search_text = ''
    return search_text  


def GetSearchText(labelL, title, tvshow):
    if title:
        return title
    elif tvshow:
        return tvshow
    else:
        return labelL


def SearchType():
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Search as...', ['Movie Title', 'TV Series Title', 'TV Episode', "Person's Name"])
    return ret
        

# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
        param=[]
        try:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                  params=sys.argv[2]
                  cleanedparams=params.replace('?','')
                  if (params[len(params)-1]=='/'):
                          params=params[0:len(params)-2]
                  pairsofparams=cleanedparams.split('&')
                  param={}
                  for i in range(len(pairsofparams)):
                          splitparams={}
                          splitparams=pairsofparams[i].split('=')
                          if (len(splitparams))==2:
                                  param[splitparams[0]]=splitparams[1]
          return param
        except:
          return param
          
          
# Initialize URL parameters.
type = None
text = None
params = getParameters()

# Get various possible labels.
labelL = xbmc.getInfoLabel('ListItem.Label')
labelR = xbmc.getInfoLabel('ListItem.Label2')
title = xbmc.getInfoLabel('ListItem.Title')
tvshow = xbmc.getInfoLabel("ListItem.TVShowTitle")
imdb_id = xbmc.getInfoLabel('ListItem.IMDBNumber')
dbid = xbmc.getInfoLabel("ListItem.DBID")
prop_id = xbmc.getInfoLabel("ListItem.Property(id)")

if text == None:
    search_text = GetSearchText(labelL, title, tvshow)
    search_text = SearchDialog(search_text)
    if search_text == '':
        exit()
else:
    search_text = text

if type == None:
    type = SearchType()
    if type == -1:
        exit()
    
if type == 0: # Movie Title
    # Lookup on IMDB and select from list created from json.
    ok = True
    while ok and (not xbmc.abortRequested):
        imdb_id = lookup.DoImdbLookupMovie(search_text)
        if imdb_id == '':
            exit()
        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedinfo,imdb_id=%s)' %(imdb_id))
        xbmc.sleep(1000)
        while xbmcgui.Window(10000).getProperty('infodialogs.active') and (not xbmc.abortRequested):
            xbmc.sleep(100)

if type == 1: # TV Show Title
    # Lookup on IMDB and select from list created from json.
    ok = True
    while ok and (not xbmc.abortRequested):
        imdb_id = lookup.DoImdbLookupTVShow(search_text)
        if imdb_id == '':
            exit()
        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedtvinfo,imdb_id=%s)' %(imdb_id))
        xbmc.sleep(1000)
        while xbmcgui.Window(10000).getProperty('infodialogs.active') and (not xbmc.abortRequested):
            xbmc.sleep(100)

if type == 2: # TV Epsiode
    # Lookup on IMDB and select from list created from json.
    ok = True
    while ok and (not xbmc.abortRequested):
        tv_series = lookup.DoImdbLookupEpisode(search_text)
        if tv_series == '':
            exit()
        imdb_id = lookup.DoImdbLookupTVShow(tv_series)
        if imdb_id == '':
            exit()
        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedtvinfo,imdb_id=%s)' %(imdb_id))
        xbmc.sleep(1000)
        while xbmcgui.Window(10000).getProperty('infodialogs.active') and (not xbmc.abortRequested):
            xbmc.sleep(100)

if type == 3: # Person's Name
    # Lookup on IMDB and select from list created from json.
    ok = True
    while ok and (not xbmc.abortRequested):
        #imdb_id = lookup.DoImdbLookupPerson(search_text)
        #if imdb_id == '':
        name = lookup.DoImdbLookupPerson(search_text)
        if name == '':
            exit()
        xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedactorinfo,name=%s)' %(name))
        xbmc.sleep(1000)
        while xbmcgui.Window(10000).getProperty('infodialogs.active') and (not xbmc.abortRequested):
            xbmc.sleep(100)

#if type == 3: # Person's Name
#    xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedactorinfo,name=%s)' %(search_text))

#common.messageWindow("Title", 'LabelL: '+labelL+'\nLabelR: '+labelR+'\nTitle: '+title+'\nTV Show: '+tvshow+'\nIMDB# '+imdb_id+'\nDB ID: '+dbid+'\nProp.ID: '+prop_id)

#title = sys.listitem.getLabel()
#xbmc.executebuiltin("Notification('Video Lookup', '%s')" % title)

#xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedinfo,id=%s)' %('Lost boys'))
#xbmc.executebuiltin('XBMC.RunScript(script.extendedinfo,info=extendedactorinfo,name=%s)' %('James'))

