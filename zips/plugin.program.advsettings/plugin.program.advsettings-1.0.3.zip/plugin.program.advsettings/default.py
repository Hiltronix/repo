import urllib
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import resources.lib.settings as settings


my_addon = xbmcaddon.Addon('plugin.program.advsettings')

file = xbmc.translatePath('special://home/userdata/advancedsettings.xml')


# Add the main directory folders.
def mainMenu():
        addDirectory('[COLOR gold]Options[/COLOR] for Advanced Settings File', 1, True, my_addon.getAddonInfo('path')+'/icon.png')
        addDirectory('[COLOR gold]Create[/COLOR] Adv. Settings File with Preferred Settings', 10, False, my_addon.getAddonInfo('path')+'/icon.png')
        addDirectory('[COLOR gold]View[/COLOR] Advanced Settings File', 11, False, my_addon.getAddonInfo('path')+'/icon.png')
        addDirectory('[COLOR gold]Delete[/COLOR] Advanced Settings File', 12, False, my_addon.getAddonInfo('path')+'/icon.png')


# Add directory item.
def addDirectory(menu_item_name, menu_number, folder, icon):
        return_url = sys.argv[0]+"?url="+urllib.quote_plus("")+"&mode="+str(menu_number)+"&name="+urllib.quote_plus(menu_item_name)
        list_item = xbmcgui.ListItem(menu_item_name, iconImage=icon)
        list_item.setProperty('fanart_image', my_addon.getAddonInfo('fanart'))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=folder, totalItems=3)


# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
        param=[]
        try:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                  params=sys.argv[2]
                  cleanedparams=params.replace('?','')
                  if (params[len(params)-1]=='/'):
                          params=params[0:len(params)-2]
                  pairsofparams=cleanedparams.split('&')
                  param={}
                  for i in range(len(pairsofparams)):
                          splitparams={}
                          splitparams=pairsofparams[i].split('=')
                          if (len(splitparams))==2:
                                  param[splitparams[0]]=splitparams[1]
          return param
        except:
          return param
          
          
# Initialize URL parameters.
menu_number = None
name = None
node = None
default = None
pref = None
action = None
desc = None
params = getParameters()

# Parse internal URL.
try:
    menu_number = int(params["mode"])
    print menu_number
except:
    pass
    
try:
    name = urllib.unquote_plus(params["name"])
    print name
except:
    pass

try:
    node = urllib.unquote_plus(params["node"])
    print node
except:
    pass

try:
    default = urllib.unquote_plus(params["default"])
    print default
except:
    pass

try:
    pref = urllib.unquote_plus(params["pref"])
    print pref
except:
    pass

try:
    action = urllib.unquote_plus(params["action"])
    print action
except:
    pass

try:
    desc = urllib.unquote_plus(params["desc"])
    print desc
except:
    pass


# Open directories based on selection.
if menu_number == None:
    mainMenu()
       
# Advanced Settings file options.
elif menu_number == 1:
    import resources.lib.advancedsettings as advancedsettings
    advancedsettings.menu()
                       
# View node.
elif menu_number == 2:
    import resources.lib.node_view as node_view
    node_view.main(file, desc, node, name)

# Change value.
elif menu_number == 3:
    import resources.lib.node_view as node_view
    value = node_view.readValue(file, node, name)
    if value != '#ERR#':
        keyboard = xbmc.Keyboard(value, 'Update Value for: '+desc, False)
        keyboard.doModal()
        if (keyboard.isConfirmed()):
            value = keyboard.getText()
            import resources.lib.node_update as node_update
            node_update.main(file, desc, node, name, value, action)
        else:
            value = ''
        
# Set value to Preferred value.
elif menu_number == 4:
    import resources.lib.node_update as node_update
    node_update.main(file, desc, node, name, pref, action)

# Set value to Default value.
elif menu_number == 5:
    import resources.lib.node_update as node_update
    node_update.main(file, desc, node, name, default, action)

# Create new Advanced Settings file with preferred settings.
elif menu_number == 10:
    import resources.lib.newadvsetfile as newadvsetfile
    newadvsetfile.main(file)

# View Advanced Settings file.
elif menu_number == 11:
    import resources.lib.viewfile as viewfile
    viewfile.main(file)

# Delete Advanced Settings file.
elif menu_number == 12:
    import resources.lib.delfile as delfile
    delfile.main(file)

xbmcplugin.endOfDirectory(int(sys.argv[1]))        
