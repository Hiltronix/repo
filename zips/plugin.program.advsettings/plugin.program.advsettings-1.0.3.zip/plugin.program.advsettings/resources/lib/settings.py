import xbmcaddon


# Set constants.
__addon__ = xbmcaddon.Addon(id='plugin.program.advsettings')

value = {}

value['hideemptyseries'] = ['videolibrary', 'false', __addon__.getSetting('hideemptyseries'), '', 'Hide empty series in the video library']
value['recentlyaddeditems'] = ['videolibrary', '25', __addon__.getSetting('recentlyaddeditems'), '', 'Recently Added Items']
value['cleanonupdate'] = ['videolibrary', 'false', __addon__.getSetting('cleanonupdate'), '', 'Clean-up old files during library updates']
value['importwatchedstate'] = ['videolibrary', 'false', __addon__.getSetting('importwatchedstate'), '', 'Import watched status from .NFO files while importing']

value['ignoreerrors'] = ['videoscanner', 'false', __addon__.getSetting('ignoreerrors'), '', 'Silently ignore errors while scanning videos']

value['add'] = ['videoextensions', '', __addon__.getSetting('add'), '', 'File extensions to include']
value['remove'] = ['videoextensions', '', __addon__.getSetting('remove'), '', 'File extensions to exclude']

value['regexp'] = ['tvshowmatching', '', __addon__.getSetting('regexp'), 'append', 'TV show matching RegEx (append)']

value['ignoresecondsatstart'] = ['video', '180', __addon__.getSetting('ignoresecondsatstart'), '', 'Ignore resume point in seconds']
value['timeseekforward'] = ['video', '30', __addon__.getSetting('timeseekforward'), '', 'Seek time forward in seconds [small]']
value['timeseekbackward'] = ['video', '-30', __addon__.getSetting('timeseekbackward'), '', 'Seek time back in seconds [small]']
value['timeseekforwardbig'] = ['video', '600', __addon__.getSetting('timeseekforwardbig'), '', 'Seek time forward in seconds [big]']
value['timeseekbackwardbig'] = ['video', '-600', __addon__.getSetting('timeseekbackwardbig'), '', 'Seek time back in seconds [big]']

