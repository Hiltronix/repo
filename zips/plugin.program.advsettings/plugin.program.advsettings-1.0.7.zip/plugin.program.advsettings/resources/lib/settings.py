import xbmcaddon


# Set constants.
__addon__ = xbmcaddon.Addon(id='plugin.program.advsettings')

value = {}

value['videolibrary\hideemptyseries'] = ['videolibrary', 'hideemptyseries', 'false', __addon__.getSetting('hideemptyseries'), '', '', 'Video Library - Hide empty series in the video library']
value['videolibrary\recentlyaddeditems'] = ['videolibrary', 'recentlyaddeditems', '25', __addon__.getSetting('recentlyaddeditems'), '', '', 'Video Library - Recently Added Items']
value['videolibrary\cleanonupdate'] = ['videolibrary', 'cleanonupdate', 'false', __addon__.getSetting('cleanonupdate'), '', '', 'Video Library - Clean-up old files during library updates']
value['videolibrary\importwatchedstate'] = ['videolibrary', 'importwatchedstate', 'false', __addon__.getSetting('importwatchedstate'), '', '', 'Video Library - Import watched status from .NFO files while importing']

value['videoscanner\ignoreerrors'] = ['videoscanner', 'ignoreerrors', 'false', __addon__.getSetting('ignoreerrors'), '', '', 'Video Scanner - Silently ignore errors while scanning videos']

value['videoextensions\add'] = ['videoextensions', 'add', '', __addon__.getSetting('add'), '', '', 'Video File Extensions - Include (use | as sep.)']
value['videoextensions\remove'] = ['videoextensions', 'remove', '', __addon__.getSetting('remove'), '', '', 'Video File Extensions - Exclude (use | as sep.)']

value['tvshowmatching\regexp'] = ['tvshowmatching', 'regexp', '', __addon__.getSetting('regexp'), 'action', 'append', 'TV Show Matching - RegEx (append)']

value['video\ignoresecondsatstart'] = ['video', 'ignoresecondsatstart', '180', __addon__.getSetting('ignoresecondsatstart'), '', '', 'Video - Ignore resume point in seconds']
value['video\timeseekforward'] = ['video', 'timeseekforward', '30', __addon__.getSetting('timeseekforward'), '', '', 'Video - Seek time forward in seconds [small]']
value['video\timeseekbackward'] = ['video', 'timeseekbackward', '-30', __addon__.getSetting('timeseekbackward'), '', '', 'Video - Seek time back in seconds [small]']
value['video\timeseekforwardbig'] = ['video', 'timeseekforwardbig', '600', __addon__.getSetting('timeseekforwardbig'), '', '', 'Video - Seek time forward in seconds [big]']
value['video\timeseekbackwardbig'] = ['video', 'timeseekbackwardbig', '-600', __addon__.getSetting('timeseekbackwardbig'), '', '', 'Video - Seek time back in seconds [big]']

value['network\buffermode'] = ['network', 'buffermode', '0', __addon__.getSetting('buffermode'), '', '', 'Network - Buffermode']
value['network\cachemembuffersize'] = ['network', 'cachemembuffersize', '20971520', __addon__.getSetting('cachemembuffersize'), '', '', 'Network - Cache size']
value['network\readbufferfactor'] = ['network', 'readbufferfactor', '1', __addon__.getSetting('readbufferfactor'), '', '', 'Network - Cache fill rate']

