import os
import xbmc
import xbmcgui
import resources.lib.common as common
import resources.lib.xml_hdler as xml_hdler


def main(file, desc, node, name, pref, attr, action):
    value = xml_hdler.setValue(file, 'advancedsettings', desc, node, name, pref, attr, action)
    xbmc.executebuiltin("Container.Refresh")
