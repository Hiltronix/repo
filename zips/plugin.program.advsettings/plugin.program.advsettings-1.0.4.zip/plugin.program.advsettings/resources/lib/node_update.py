import os
import xbmc
import xbmcgui
import resources.lib.settings as settings
import resources.lib.common as common
from xml.dom.minidom import parse, Document, parseString
import xml.etree.ElementTree as ET


# Removes newlines and whitespace from XML string.
def removeFormatting(xml):
    newstr = ''
    list = xml.split("\n")
    for x in list:
        newstr += x.strip()  # Strip off prepending and appending whitespace on each line.
    print newstr
    return newstr


def setValue(file, _desc_, _node_, _name_, _value_, _attr_, _action_):
    value = None
    filename = os.path.basename(file)

    if os.path.exists(file):
        with open (file, "r") as myfile:
            xml = myfile.read()
        xml = removeFormatting(xml)

        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            common.CreateNotification(header='Malformed XML Document', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
            return '#ERR#'
    else:
        root = ET.Element('advancedsettings')
   
    node = root.find(_node_)
    if node is None:
        node = ET.SubElement(root, _node_)
        if _attr_ != '':
            node.attrib[_attr_] = _action_
        name = ET.SubElement(node, _name_)
        name.text = _value_
    else:
        name = node.find(_name_)
        if name is None:
            name = ET.SubElement(node, _name_)
            name.text = _value_
        else:
            name.text = _value_
        
    
    xml = parseString(ET.tostring(root, 'utf-8')).toprettyxml(indent="    ", newl="\n", encoding="utf-8")
    
    output_file = open(file, 'w' )
    output_file.write(xml)
    output_file.close()
    
    common.CreateNotification(header='Updated: '+_desc_, message=_value_, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    common.CreateNotification(header="Restart is Required", message='for changes to take effect.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)


def main(file, desc, node, name, pref, attr, action):
    value = setValue(file, desc, node, name, pref, attr, action)
    xbmc.executebuiltin("Container.Refresh")
