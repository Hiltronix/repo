# plugin.program.advsettings
#### My Advanced Settings for Kodi/XBMC

View and change advanced settings that aren't easily accessible in Kodi/XBMC.

I created this add-on due to my frustration with the Kodi/XBMC not bringing certain advanced settings to the Expert Settings Level in the GUI System Settings.

-----

## Kodi/XBMC Repo  
The repository for this add-on can be found here:  

https://github.com/Hiltronix/repo/

OR

https://hiltronix.com/xbmc/

-----

## [Donations](https://hiltronix.com/donations/)  

If you would like to show your appreciation for this project, and/or help support it to keep it current, please consider making a donation.  
[Click Here](https://hiltronix.com/donations/).  
[![Support the project](https://github.com/Hiltronix/repo/blob/master/images/donate.png)](https://hiltronix.com/donations/)
