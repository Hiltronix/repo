import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import resources.lib.common as common


my_addon = xbmcaddon.Addon('plugin.program.advsettings')


def GetBacklogItems():
  show_ids = Sickbeard.GetShowIds()
  show_info = Sickbeard.GetShowInfo(show_ids)

  show_names = {}
  for show_name, tvdbid in sorted(show_info.iteritems()):
    show_names[show_name] = str(tvdbid[0])

  backlog = Sickbeard.GetBacklog()
  backlog_list = []
  for episode in backlog:
    tvdbid = show_names[episode['show_name']]
    if (episode['status'] == 'Ended'):
        status = '[COLOR red]' + episode['status'] + '[/COLOR]'
    else:
        status = '[COLOR cyan]' + episode['status'] + '[/COLOR]'
    backlog_list.append([episode['show_name'], '[COLOR gold]'+episode['show_name']+'[/COLOR] '+str(episode['season'])+'x'+str(episode['episode'])+' '+episode['name']+'  '+str(datetime.date.fromordinal(episode['airdate']))+'    '+status, str(tvdbid), episode['season'], episode['episode']])

  return backlog_list
  

def menu():
    common.CreateNotification(header='Coming Soon...', message='This feature under construction.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    return

    list = GetItems()
    total = len(list)
    for node, name, default, pref, attr, action, desc in list:
        context_menu_items = [('Add', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=2&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Change', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=3&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Remove', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=4&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Go Back', 'XBMC.Action(back)')]
        addDirectory(desc, node, name, default, total, context_menu_items)


# Add directory item.
def addDirectory(desc, node, name, default, total, context_menu_items):
    url = sys.argv[0]+"?mode=2&desc="+urllib.quote_plus(desc)+"&node="+urllib.quote_plus(node)+"&name="+urllib.quote_plus(name)+"&default="+urllib.quote_plus(default)
    thumbnail = my_addon.getAddonInfo('path')+'/icon.png'
    list_item = xbmcgui.ListItem(desc, thumbnailImage=thumbnail)
    list_item.setProperty('fanart_image', my_addon.getAddonInfo('fanart'))
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False, totalItems=total)  

