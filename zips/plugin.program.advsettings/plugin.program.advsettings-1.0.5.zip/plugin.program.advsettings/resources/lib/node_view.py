import os
import xbmc
import xbmcgui
import resources.lib.common as common
import resources.lib.node_update as node_update
import xml.etree.ElementTree as ET


def readValue(file, _node_, _name_):
    value = None
    filename = os.path.basename(file)
    
    if os.path.exists(file):
        with open (file, "r") as myfile:
            xml = myfile.read()
        xml = node_update.removeFormatting(xml)

        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            common.CreateNotification(header='Malformed XML Document', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
            return '#ERR#'
    else:
        root = ET.Element('advancedsettings')
   
    try:
        node = root.find(_node_)
        if node is not None:
            name = node.find(_name_)
            value = name.text
    except:
        pass
    return value
            

def main(file, desc, node, name):
    value = readValue(file, node, name)
    if value != '#ERR#':
        if value != None:
            common.messageWindow(desc, value)
        else:
            common.CreateNotification(header=desc, message='No Data.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    xbmc.executebuiltin("Container.Refresh")
