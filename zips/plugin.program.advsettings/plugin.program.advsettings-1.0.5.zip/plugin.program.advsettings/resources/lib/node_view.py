import os
import xbmc
import xbmcgui
import resources.lib.common as common
import resources.lib.xml_hdler as xml_hdler


def main(file, desc, node, name):
    value = xml_hdler.readValue(file, 'advancedsettings', node, name)
    if value != '#ERR#':
        if value != None:
            common.messageWindow(desc, value)
        else:
            common.CreateNotification(header=desc, message='No Data.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    xbmc.executebuiltin("Container.Refresh")
