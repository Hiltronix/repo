import sys
import urllib
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import resources.lib.common as common


my_addon = xbmcaddon.Addon('plugin.program.advsettings')


def GetBacklogItems():
  show_ids = Sickbeard.GetShowIds()
  show_info = Sickbeard.GetShowInfo(show_ids)

  show_names = {}
  for show_name, tvdbid in sorted(show_info.iteritems()):
    show_names[show_name] = str(tvdbid[0])

  backlog = Sickbeard.GetBacklog()
  backlog_list = []
  for episode in backlog:
    tvdbid = show_names[episode['show_name']]
    if (episode['status'] == 'Ended'):
        status = '[COLOR red]' + episode['status'] + '[/COLOR]'
    else:
        status = '[COLOR cyan]' + episode['status'] + '[/COLOR]'
    backlog_list.append([episode['show_name'], '[COLOR gold]'+episode['show_name']+'[/COLOR] '+str(episode['season'])+'x'+str(episode['episode'])+' '+episode['name']+'  '+str(datetime.date.fromordinal(episode['airdate']))+'    '+status, str(tvdbid), episode['season'], episode['episode']])

  return backlog_list
  

class Slider_Dialog(xbmcgui.WindowXMLDialog):
    ACTION_PREVIOUS_MENU = [9, 92, 10]

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.heading = kwargs.get('heading')
        self.label = kwargs.get('label')
        self.min = kwargs.get('min')
        self.delta = kwargs.get('delta')
        self.max = kwargs.get('max')
        self.value = kwargs.get('value')

    def onInit(self):
        self.getControl(10).setLabel(self.heading)

        self.getControl(11).setLabel(self.label)
        self.getControl(11).SetFloatRange(self.min, self.max)
        self.getControl(11).SetFloatInterval(self.delta)
        self.getControl(11).SetFloatValue(self.value)

        self.getControl(12).setText(self.label)

    def onAction(self, action):
        if action in self.ACTION_PREVIOUS_MENU:
            self.close()

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        pass

    def onMessage(self, controlID):
        pass


def menu():
    common.CreateNotification(header='Coming Soon...', message='This feature under construction.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    return

    list = GetItems()
    total = len(list)
    for node, name, default, pref, attr, action, desc in list:
        context_menu_items = [('Add', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=2&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Change', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=3&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Remove', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=4&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Go Back', 'XBMC.Action(back)')]
        addDirectory(desc, node, name, default, total, context_menu_items)


# Add directory item.
def addDirectory(desc, node, name, default, total, context_menu_items):
    url = sys.argv[0]+"?mode=2&desc="+urllib.quote_plus(desc)+"&node="+urllib.quote_plus(node)+"&name="+urllib.quote_plus(name)+"&default="+urllib.quote_plus(default)
    thumbnail = my_addon.getAddonInfo('path')+'/icon.png'
    list_item = xbmcgui.ListItem(desc, thumbnailImage=thumbnail)
    list_item.setProperty('fanart_image', my_addon.getAddonInfo('fanart'))
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False, totalItems=total)  

