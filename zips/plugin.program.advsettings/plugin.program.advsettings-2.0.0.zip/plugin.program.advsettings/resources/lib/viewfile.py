import xbmc
import xbmcgui
import xbmcaddon
import os
import sys
import common
import settings


def viewFile(file):
    #filename = os.path.basename(file)
    filename = file

    if os.path.exists(file):
        with open(file, "r") as myfile:
            data = myfile.read()
    
        w = common.TextViewer_Dialog('DialogTextViewer.xml', settings.addon_path, header=filename, text=data)
        w.doModal()
    else:
        common.CreateNotification(header="File Doesn't Exist", message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)


def main(file):
    viewFile(file)
    xbmc.executebuiltin("Container.Refresh")

