import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import sys
import urllib
import settings


my_addon = xbmcaddon.Addon('plugin.program.advsettings')


def menu():
    total = len(settings.value)
    for title, info in sorted(settings.value.iteritems()):
        node, name, default, pref, attr, action, desc = info
        context_menu_items = [('View', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=2&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Change', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=3&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Preferred', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=4&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Default', 'XBMC.RunPlugin(plugin://'+my_addon.getAddonInfo('id')+'?mode=5&desc='+urllib.quote_plus(desc)+'&node='+urllib.quote_plus(node)+'&name='+urllib.quote_plus(name)+'&default='+urllib.quote_plus(default)+'&pref='+urllib.quote_plus(pref)+'&attr='+urllib.quote_plus(attr)+'&action='+urllib.quote_plus(action)+')'),\
                              ('Go Back', 'XBMC.Action(back)')]
        addDirectory(desc, node, name, default, total, context_menu_items)


# Add directory item.
def addDirectory(desc, node, name, default, total, context_menu_items):
    url = sys.argv[0]+"?mode=99&desc="+urllib.quote_plus(desc)+"&node="+urllib.quote_plus(node)+"&name="+urllib.quote_plus(name)+"&default="+urllib.quote_plus(default)
    thumbnail = my_addon.getAddonInfo('path')+'/icon.png'
    list_item = xbmcgui.ListItem(desc, thumbnailImage=thumbnail)
    list_item.setProperty('fanart_image', my_addon.getAddonInfo('fanart'))
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False, totalItems=total)  

