import xbmc
import xbmcgui
import os
import sys
import shutil
import common
import settings
from xml.dom.minidom import parse, Document, parseString
import xml.etree.ElementTree as ET


def createBackup(file):
    # Create a backup of original file.
    bak_file = file + ".bak"
    shutil.copyfile(file, bak_file)
    os.remove(file)


def confirmContinue(file):
    filename = os.path.basename(file)
    if os.path.exists(file):
        if common.selectNoYes('Replace Existing: ' + filename, 'Cancel', 'Replace File') == True:
            createBackup(file)
            common.CreateNotification(header="File Backed Up", message=filename+'.bak', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
            return True
        else:
            return False
    return True


def createXML(file):
    filename = os.path.basename(file)

    root = ET.Element('advancedsettings')
    
    for title, info in sorted(settings.value.iteritems()):
        _node_, _name_, _default_, _pref_, _attr_, _action_, _desc_ = info

        if _pref_ != '':
            node = root.find(_node_)
            if node is None:
                node = ET.SubElement(root, _node_)
                if _attr_ != '':
                    node.attrib[_attr_] = _action_
                name = ET.SubElement(node, _name_)
                name.text = _pref_
            else:
                name = node.find(_name_)
                if name is None:
                    name = ET.SubElement(node, _name_)
                    name.text = _pref_
                else:
                    name.text = _pref_
    
    xml = parseString(ET.tostring(root, 'utf-8')).toprettyxml(indent="    ", newl="\n", encoding="utf-8")
    
    output_file = open(file, 'w' )
    output_file.write(xml)
    output_file.close()
    
    common.CreateNotification(header="File Created Successfully", message=filename, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
    common.CreateNotification(header="Restart is Required", message='for changes to take effect.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)


def newFile(file):
    if confirmContinue(file) == True:
        createXML(file)


def main(file):
    newFile(file)
    xbmc.executebuiltin("Container.Refresh")

