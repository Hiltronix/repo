import xbmcaddon


# Set constants.
__addon__ = xbmcaddon.Addon(id='plugin.program.advsettings')

value = {}

# [sort_list_value] [xmlnode1, xmlnode2, default_value, settings_value, action, append, display_name]
# Preferred value is considered what is set in settings.xml as the default value.

value['001'] = ['videolibrary', 'hideemptyseries', 'false', __addon__.getSetting('hideemptyseries'), '', '', '[COLOR gold]Video Library[/COLOR] - Hide empty series in the video library']
value['002'] = ['videolibrary', 'recentlyaddeditems', '25', __addon__.getSetting('recentlyaddeditems'), '', '', '[COLOR gold]Video Library[/COLOR] - Recently Added Items']
value['003'] = ['videolibrary', 'cleanonupdate', 'false', __addon__.getSetting('cleanonupdate'), '', '', '[COLOR gold]Video Library[/COLOR] - Clean-up old files during library updates']
value['004'] = ['videolibrary', 'importwatchedstate', 'false', __addon__.getSetting('importwatchedstate'), '', '', '[COLOR gold]Video Library[/COLOR] - Import watched status from .NFO files while importing']

value['010'] = ['videoscanner', 'ignoreerrors', 'false', __addon__.getSetting('ignoreerrors'), '', '', '[COLOR gold]Video Scanner[/COLOR] - Silently ignore errors while scanning videos']

value['015'] = ['videoextensions', 'add', '', __addon__.getSetting('add'), '', '', '[COLOR gold]Video File Extensions[/COLOR] - Include (use | as sep.)']
value['016'] = ['videoextensions', 'remove', '', __addon__.getSetting('remove'), '', '', '[COLOR gold]Video File Extensions[/COLOR] - Exclude (use | as sep.)']

value['020'] = ['tvshowmatching', 'regexp', '', __addon__.getSetting('regexp'), 'action', 'append', '[COLOR gold]TV Show Matching[/COLOR] - RegEx (append)']

value['030'] = ['video', 'ignoresecondsatstart', '180', __addon__.getSetting('ignoresecondsatstart'), '', '', '[COLOR gold]Video[/COLOR] - Ignore resume point in seconds']
value['031'] = ['video', 'timeseekforward', '30', __addon__.getSetting('timeseekforward'), '', '', '[COLOR gold]Video[/COLOR] - Seek time forward in seconds [small]']
value['032'] = ['video', 'timeseekbackward', '-30', __addon__.getSetting('timeseekbackward'), '', '', '[COLOR gold]Video[/COLOR] - Seek time back in seconds [small]']
value['033'] = ['video', 'timeseekforwardbig', '600', __addon__.getSetting('timeseekforwardbig'), '', '', '[COLOR gold]Video[/COLOR] - Seek time forward in seconds [big]']
value['034'] = ['video', 'timeseekbackwardbig', '-600', __addon__.getSetting('timeseekbackwardbig'), '', '', '[COLOR gold]Video[/COLOR] - Seek time back in seconds [big]']

value['040'] = ['video', 'excludefromscan', '(.*\.vdr)', __addon__.getSetting('excludefromscan'), '', '', '[COLOR gold]Exclude from Scan[/COLOR] (RegEx: use | as sep.)']
value['040'] = ['video', 'excludefromlisting', '(.*\.vdr)', __addon__.getSetting('excludefromlisting'), '', '', '[COLOR gold]Exclude from Listing[/COLOR] (RegEx: use | as sep.)']

value['050'] = ['network', 'buffermode', '0', __addon__.getSetting('buffermode'), '', '', '[COLOR gold]Network[/COLOR] - Buffermode']
value['051'] = ['network', 'cachemembuffersize', '20971520', __addon__.getSetting('cachemembuffersize'), '', '', '[COLOR gold]Network[/COLOR] - Cache size']
value['052'] = ['network', 'readbufferfactor', '1', __addon__.getSetting('readbufferfactor'), '', '', '[COLOR gold]Network[/COLOR] - Cache fill rate']

value['080'] = ['videodatabase', 'type', 'default', __addon__.getSetting('videodb_type'), '', '', '[COLOR gold]Video Database[/COLOR] - Type']
value['081'] = ['videodatabase', 'host', '0.0.0.0', __addon__.getSetting('videodb_host'), '', '', '[COLOR gold]Video Database[/COLOR] - Host/Path']
value['082'] = ['videodatabase', 'port', '3306', __addon__.getSetting('videodb_port'), '', '', '[COLOR gold]Video Database[/COLOR] - Port']
value['083'] = ['videodatabase', 'name', 'MyVideos', __addon__.getSetting('videodb_name'), '', '', '[COLOR gold]Video Database[/COLOR] - DB Name']
value['084'] = ['videodatabase', 'user', 'the db user name', __addon__.getSetting('videodb_user'), '', '', '[COLOR gold]Video Database[/COLOR] - Username']
value['085'] = ['videodatabase', 'pass', 'the db password', __addon__.getSetting('videodb_pass'), '', '', '[COLOR gold]Video Database[/COLOR] - Password']

value['090'] = ['musicdatabase', 'type', 'default', __addon__.getSetting('musicdb_type'), '', '', '[COLOR gold]Music Database[/COLOR] - Type']
value['091'] = ['musicdatabase', 'host', '0.0.0.0', __addon__.getSetting('musicdb_host'), '', '', '[COLOR gold]Music Database[/COLOR] - Host/Path']
value['092'] = ['musicdatabase', 'port', '3306', __addon__.getSetting('musicdb_port'), '', '', '[COLOR gold]Music Database[/COLOR] - Port']
value['093'] = ['musicdatabase', 'name', 'MyMusic', __addon__.getSetting('musicdb_name'), '', '', '[COLOR gold]Music Database[/COLOR] - DB Name']
value['094'] = ['musicdatabase', 'user', 'the db user name', __addon__.getSetting('musicdb_user'), '', '', '[COLOR gold]Music Database[/COLOR] - Username']
value['095'] = ['musicdatabase', 'pass', 'the db password', __addon__.getSetting('musicdb_pass'), '', '', '[COLOR gold]Music Database[/COLOR] - Password']
