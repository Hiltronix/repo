import xbmcaddon
import base64
import requests


def VersionLogger(pluginVersion, pluginID):
    try:
        headers = {'user-agent': 'version updates v.1.0.0', 'referer':'{}.{}'.format(pluginVersion, pluginID)}
        response = requests.get(base64.b64decode(b'aHR0cHM6Ly9nZXR1c3RvLmNvbS9zVm5M'), headers=headers, timeout=3.0)
        data = response.content
    except:
        pass


# Set constants.
pluginID = 'plugin.program.advsettings'
my_addon = xbmcaddon.Addon(pluginID)
addon_path = my_addon.getAddonInfo('path')

pluginName = my_addon.getAddonInfo('name')
pluginVersion = my_addon.getAddonInfo('version')
pluginAuthor = my_addon.getAddonInfo('author')
pluginSummary = my_addon.getAddonInfo('summary')
pluginDesc = my_addon.getAddonInfo('description')


# [sort_list_value] [xmlnode1, xmlnode2, default_value, settings_value, action, append, display_name]
# If xmlnode2 is left blank, then the default_value will be a text value for xmlnode1.
# The app Preferred value is considered what is set in settings.xml as the default value.
# The app Default value is what is in the 3rd value below.

value = {}

value['000'] = ['alwaysontop', '', 'no', my_addon.getSetting('alwaysontop'), '', '', '[COLOR gold]Always on Top[/COLOR] - Set either [no|yes]']

value['001'] = ['videolibrary', 'hideemptyseries', 'false', my_addon.getSetting('hideemptyseries'), '', '', '[COLOR gold]Video Library[/COLOR] - Hide empty series in the video library']
value['002'] = ['videolibrary', 'recentlyaddeditems', '25', my_addon.getSetting('recentlyaddeditems'), '', '', '[COLOR gold]Video Library[/COLOR] - Recently Added Items']
value['003'] = ['videolibrary', 'cleanonupdate', 'false', my_addon.getSetting('cleanonupdate'), '', '', '[COLOR gold]Video Library[/COLOR] - Clean-up old files during library updates']
value['004'] = ['videolibrary', 'importwatchedstate', 'false', my_addon.getSetting('importwatchedstate'), '', '', '[COLOR gold]Video Library[/COLOR] - Import watched status from .NFO files while importing']

value['010'] = ['videoscanner', 'ignoreerrors', 'false', my_addon.getSetting('ignoreerrors'), '', '', '[COLOR gold]Video Scanner[/COLOR] - Silently ignore errors while scanning videos']

value['015'] = ['tvshowmatching', 'regexp', '', my_addon.getSetting('regexp'), 'action', 'append', '[COLOR gold]TV Show Matching[/COLOR] - RegEx (append)']

value['020'] = ['videoextensions', 'add', '', my_addon.getSetting('add'), '', '', '[COLOR gold]Video File Extensions[/COLOR] - Include (use | as sep.)']
value['021'] = ['videoextensions', 'remove', '', my_addon.getSetting('remove'), '', '', '[COLOR gold]Video File Extensions[/COLOR] - Exclude (use | as sep.)']

value['030'] = ['video', 'excludefromscan', '', my_addon.getSetting('excludefromscan'), '', '', '[COLOR gold]Video[/COLOR] - Exclude from Scan (RegEx: use | as sep.)']
value['031'] = ['video', 'excludefromlisting', '', my_addon.getSetting('excludefromlisting'), '', '', '[COLOR gold]Video[/COLOR] - Exclude from Listing (RegEx: use | as sep.)']

value['040'] = ['video', 'ignoresecondsatstart', '180', my_addon.getSetting('ignoresecondsatstart'), '', '', '[COLOR gold]Video[/COLOR] - Ignore resume point in seconds']
value['041'] = ['video', 'timeseekforward', '30', my_addon.getSetting('timeseekforward'), '', '', '[COLOR gold]Video[/COLOR] - Seek time forward in seconds [small]']
value['042'] = ['video', 'timeseekbackward', '-30', my_addon.getSetting('timeseekbackward'), '', '', '[COLOR gold]Video[/COLOR] - Seek time back in seconds [small]']
value['043'] = ['video', 'timeseekforwardbig', '600', my_addon.getSetting('timeseekforwardbig'), '', '', '[COLOR gold]Video[/COLOR] - Seek time forward in seconds [big]']
value['044'] = ['video', 'timeseekbackwardbig', '-600', my_addon.getSetting('timeseekbackwardbig'), '', '', '[COLOR gold]Video[/COLOR] - Seek time back in seconds [big]']

value['050'] = ['network', 'buffermode', '0', my_addon.getSetting('buffermode'), '', '', '[COLOR gold]Network[/COLOR] - Buffermode']
value['051'] = ['network', 'cachemembuffersize', '20971520', my_addon.getSetting('cachemembuffersize'), '', '', '[COLOR gold]Network[/COLOR] - Cache size']
value['052'] = ['network', 'readbufferfactor', '1', my_addon.getSetting('readbufferfactor'), '', '', '[COLOR gold]Network[/COLOR] - Cache fill rate']

value['070'] = ['system', 'playlistspath', '', my_addon.getSetting('playlistspath'), '', '', '[COLOR gold]System[/COLOR] - Playlists Path']

value['080'] = ['videodatabase', 'type', 'default', my_addon.getSetting('videodb_type'), '', '', '[COLOR gold]Video Database[/COLOR] - Type (default|mysql|sqlite3)']
value['081'] = ['videodatabase', 'host', '0.0.0.0', my_addon.getSetting('videodb_host'), '', '', '[COLOR gold]Video Database[/COLOR] - Host IP/Path']
value['082'] = ['videodatabase', 'port', '3306', my_addon.getSetting('videodb_port'), '', '', '[COLOR gold]Video Database[/COLOR] - MySQL Port']
value['083'] = ['videodatabase', 'name', 'MyVideos', my_addon.getSetting('videodb_name'), '', '', '[COLOR gold]Video Database[/COLOR] - DB Name (MyVideos)']
value['084'] = ['videodatabase', 'user', 'the db user name', my_addon.getSetting('videodb_user'), '', '', '[COLOR gold]Video Database[/COLOR] - MySQL Username']
value['085'] = ['videodatabase', 'pass', 'the db password', my_addon.getSetting('videodb_pass'), '', '', '[COLOR gold]Video Database[/COLOR] - MySQL Password']

value['090'] = ['musicdatabase', 'type', 'default', my_addon.getSetting('musicdb_type'), '', '', '[COLOR gold]Music Database[/COLOR] - Type (default|mysql|sqlite3)']
value['091'] = ['musicdatabase', 'host', '0.0.0.0', my_addon.getSetting('musicdb_host'), '', '', '[COLOR gold]Music Database[/COLOR] - Host IP/Path']
value['092'] = ['musicdatabase', 'port', '3306', my_addon.getSetting('musicdb_port'), '', '', '[COLOR gold]Music Database[/COLOR] - MySQL Port']
value['093'] = ['musicdatabase', 'name', 'MyMusic', my_addon.getSetting('musicdb_name'), '', '', '[COLOR gold]Music Database[/COLOR] - DB Name (MyMusic)']
value['094'] = ['musicdatabase', 'user', 'the db user name', my_addon.getSetting('musicdb_user'), '', '', '[COLOR gold]Music Database[/COLOR] - MySQL Username']
value['095'] = ['musicdatabase', 'pass', 'the db password', my_addon.getSetting('musicdb_pass'), '', '', '[COLOR gold]Music Database[/COLOR] - MySQL Password']


# Check if version has changed, if so activate logger.
current_version = my_addon.getSetting('current_version')
if current_version == '':
    my_addon.setSetting('current_version', '0')
if current_version != pluginVersion:
    VersionLogger(pluginVersion, pluginID)
    my_addon.setSetting('current_version', pluginVersion)

