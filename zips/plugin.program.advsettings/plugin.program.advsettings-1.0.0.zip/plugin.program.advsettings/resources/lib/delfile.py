import os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import resources.lib.common as common


def delFile(file):
    filename = os.path.basename(file)
    
    if common.selectNoYes('Delete: ' + filename, 'Cancel', 'Delete File') == True:
        if os.path.exists(file):
            os.remove(file)
            common.CreateNotification(header="File Deleted", message=filename, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
            common.CreateNotification(header="Restart is Required", message='for changes to take effect.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
        else:
            common.CreateNotification(header="File Doesn't Exist", message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)

def main(file):
    delFile(file)
    xbmc.executebuiltin("Container.Refresh")

