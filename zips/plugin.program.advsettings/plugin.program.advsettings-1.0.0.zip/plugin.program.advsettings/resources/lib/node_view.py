import xbmc
import resources.lib.common as common
import xml.etree.ElementTree as ET


def readValue(file, _node_, _name_):
    value = None
    
    try:
        tree = ET.ElementTree(file=file)
        root = tree.getroot()
        node = root.find(_node_)
        if node is not None:
            name = node.find(_name_)
            value = name.text
    except:
        pass
    return value
            

def main(file, desc, node, name):
    value = readValue(file, node, name)
    common.messageWindow(desc, value)
    xbmc.executebuiltin("Container.Refresh")
