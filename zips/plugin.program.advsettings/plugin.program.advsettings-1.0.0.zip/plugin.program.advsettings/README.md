# plugin.program.advsettings
#### My Advanced Settings for Kodi/XBMC

View and change advanced settings that aren't easily accessible in Kodi/XBMC.

I created this add-on due to my frustration with the Kodi/XBMC not bringing certain advanced settings to the Expert Settings Level in the GUI System Settings.

-----

## Repo  
The repository for this add-on can be found here:  

https://github.com/Hiltronix/repo/

OR

https://hiltronix.com/xbmc/

-----

## Related Links

#### None:  
https://www.

-----

## Known Issues  

#### None Yet...  
- .  
- .  
- .  

-----

## Notes

.  


