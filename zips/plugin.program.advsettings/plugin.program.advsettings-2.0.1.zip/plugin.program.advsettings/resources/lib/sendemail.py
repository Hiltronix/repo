import xbmc
import xbmcgui
import xbmcaddon
import os
import io
import sys
import common

import time
import datetime
from smtplib import SMTP_SSL               # This invokes the secure SMTP protocol (port 465, uses SSL)
from smtplib import SMTP                   # Use this for standard SMTP protocol (port 25, no encryption)
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart


# Get mail settings from addon settings tab.
__addon__ = xbmcaddon.Addon(id='plugin.program.advsettings')
send_to = __addon__.getSetting('email_send_to')
sender = __addon__.getSetting('email_sender')
SMTPserver = __addon__.getSetting('email_smtp_server')
SMTPport = __addon__.getSetting('email_smtp_port')
SSL = __addon__.getSetting('email_ssl')
username = __addon__.getSetting('email_username')
password = __addon__.getSetting('email_password')

text_subtype = 'plain'  # Typical values for text_subtype are plain, html, xml.


def GetDateTimeString():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def SendMail(subject='', content='', attachment=''):

    global send_to
    global sender
    global SMTPserver
    global SMTPport
    global SSL
    global username
    global password
    global text_subtype

    try:
        xbmc.executebuiltin("ActivateWindow(busydialog)")
    
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['From']    = sender
        msg['To']      = send_to

        text = MIMEText(content, text_subtype)
        msg.attach(text)
        if attachment <> '':
            img_data = GetUrlData(url=attachment, add_useragent=True, encodeType='')
            image = MIMEImage(img_data, name=os.path.basename(attachment))
            msg.attach(image)

        if SSL == "true":
            conn = SMTP_SSL(SMTPserver, SMTPport)
        else:
            conn = SMTP(SMTPserver, SMTPport)
        conn.set_debuglevel(False)
        conn.login(username, password)
        try:
            conn.sendmail(sender, send_to, msg.as_string())
        finally:
            conn.close()

        msg = "Success: %s" % subject
        common.messageWindow('Send Email', msg)

    except Exception, e:
        msg = "Failed: %s" % str(e)
        common.messageWindow('Send Email', msg)
        sys.exit(msg)

    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")


def sendFile(file):

    filename = os.path.basename(file)

    if os.path.exists(file):
        with io.open(file, mode='r', encoding='utf-8-sig') as myfile:   # Open UTF-8 log file as text without the initial 3 byte BOM.
            data = myfile.read()
            SendMail('Kodi File: ' + filename, data, '')
    else:
        common.CreateNotification(header="File Doesn't Exist", message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)


def main(file):
    sendFile(file)
    xbmc.executebuiltin("Container.Refresh")

