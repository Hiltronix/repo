import xbmcgui
import os
import common
import xml.etree.ElementTree as ET


# Removes newlines and whitespace from XML string.
def removeFormatting(xml):
    newstr = ''
    list = xml.split("\n")
    for x in list:
        newstr += x.strip()  # Strip off prepending and appending whitespace on each line.
    print newstr
    return newstr


def readValue(file, root_element, _node_, _name_):
    value = None
    filename = os.path.basename(file)
    
    if os.path.exists(file):
        # If XML file exists, open, remove formatting for better parsing, and find root node.
        with open (file, "r") as myfile:
            xml = myfile.read()
        xml = removeFormatting(xml)
        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            common.CreateNotification(header='Malformed XML Document', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
            return '#ERR#'
    else:
        # If file doesn't exist, create root node.
        root = ET.Element(root_element)
   
    # Attempt to read node.
    try:
        node = root.find(_node_)
        if node is not None:
            if _node_ and not _name_:
                # This will be a text value for node/xmlnode1.
                value = node.text
            else:
                # This will be a text value for name/xmlnode2.
                name = node.find(_name_)
                value = name.text
    except:
        common.CreateNotification(header='Error reading XML node.', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
        return '#ERR#'
    return value
            

def indentXML(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indentXML(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i
            
            
def setValue(file, root_element, _desc_, _node_, _name_, _value_, _attr_, _action_, notify=True):
    value = None
    filename = os.path.basename(file)

    if os.path.exists(file):
        # If XML file exists, open, remove formatting for better parsing, and find root node.
        with open (file, "r") as myfile:
            xml = myfile.read()
        xml = removeFormatting(xml)

        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            common.CreateNotification(header='Malformed XML Document', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
            return '#ERR#'
    else:
        # If file doesn't exist, create root node.
        root = ET.Element(root_element)
   
    # Attempt to read node.
    node = root.find(_node_)
    try:
        if node is None:
            node = ET.SubElement(root, _node_)
            if _attr_ != '':
                node.attrib[_attr_] = _action_
            if _node_ and not _name_:
                # This will be a text value for node/xmlnode1.
                node.text = _value_
            else:
                # This will be a text value for name/xmlnode2.
                name = ET.SubElement(node, _name_)
                name.text = _value_
        else:
            if _node_ and not _name_:
                # This will be a text value for node/xmlnode1.
                node.text = _value_
            else:
                # This will be a text value for name/xmlnode2.
                name = node.find(_name_)
                if name is None:
                    name = ET.SubElement(node, _name_)
                    name.text = _value_
                else:
                    name.text = _value_
    except:
        common.CreateNotification(header='Error writing XML node.', message=filename, icon=xbmcgui.NOTIFICATION_ERROR, time=5000, sound=True)
        return '#ERR#'      
    
    # Save XML.
    #root = ET.fromstring("<fruits><fruit>banana</fruit><fruit>apple</fruit></fruits>")   # Test string.
    tree = ET.ElementTree(root)
    indentXML(root)
    tree.write(file, encoding="utf-8")
    
    if notify:
        common.CreateNotification(header='Updated: '+_desc_, message=_value_, icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)
        common.CreateNotification(header="Restart is Required", message='for changes to take effect.', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)

