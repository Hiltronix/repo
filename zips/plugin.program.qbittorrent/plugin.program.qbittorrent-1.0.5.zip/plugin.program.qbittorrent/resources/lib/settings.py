import sys
import xbmcgui
import xbmcaddon


# Show error pop up then exit plugin.
def messageWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)


# Show error pop up then exit plugin.
def errorWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)
    sys.exit()


def createURL(ip, port, use_ssl, custom_url):
    if custom_url != "":
        return custom_url
    if str(ip) == "" or str(port) == "":
        errorWindow("Error", "Must configure IP and port settings before use.")
    else:
        if use_ssl == "true":
            return "https://"+str(ip) + ':' + str(port)
        else:
            return "http://"+str(ip) + ':' + str(port)


# Set constants.
__addonID__ = 'plugin.program.qbittorrent'
__addon__ = xbmcaddon.Addon(__addonID__)
__ip__ = __addon__.getSetting('IP')
__port__= __addon__.getSetting('Port')
__ssl_bool__= __addon__.getSetting('Use SSL')
__username__ = __addon__.getSetting('Username')
__password__= __addon__.getSetting('Password')
__url_bool__= __addon__.getSetting('Use Custom URL')
if __url_bool__ == "true":
    __custom_url__= __addon__.getSetting('Custom URL')
else:
    __custom_url__= ""


# Create the URL used to access webserver.
__url__ = createURL(__ip__, __port__, __ssl_bool__, __custom_url__)

