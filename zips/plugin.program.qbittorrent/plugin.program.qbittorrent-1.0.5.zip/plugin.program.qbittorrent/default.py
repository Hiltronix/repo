import urllib
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import resources.lib.common as common
import resources.lib.settings as settings
import resources.lib.utility as utility


my_addon = settings.__addon__

Utility = utility.Util()


# Add the main directory folders.
def mainMenu():
        addDirectory('List Torrents (All)', 1, True, my_addon.getAddonInfo('path')+'/icon.png', my_addon.getAddonInfo('path')+'/icon.png')
        addDirectory('Add Torrent from URL', 5, False, my_addon.getAddonInfo('path')+'/icon.png', my_addon.getAddonInfo('path')+'/icon.png')
        addDirectory('qBittorrent Server Version', 2, False, my_addon.getAddonInfo('path')+'/icon.png', my_addon.getAddonInfo('path')+'/icon.png')
        xbmc.executebuiltin("Container.SetViewMode(502)")  # Set List view mode.


# Add directory item.
def addDirectory(menu_item_name, mode, folder, icon, thumbnail):
        return_url = sys.argv[0]+"?url="+urllib.quote_plus("")+"&mode="+str(mode)+"&name="+urllib.quote_plus(menu_item_name)
        list_item = xbmcgui.ListItem(menu_item_name, iconImage=thumbnail, thumbnailImage=icon)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=folder, totalItems=7)


# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
        param=[]
        try:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                  params=sys.argv[2]
                  cleanedparams=params.replace('?','')
                  if (params[len(params)-1]=='/'):
                          params=params[0:len(params)-2]
                  pairsofparams=cleanedparams.split('&')
                  param={}
                  for i in range(len(pairsofparams)):
                          splitparams={}
                          splitparams=pairsofparams[i].split('=')
                          if (len(splitparams))==2:
                                  param[splitparams[0]]=splitparams[1]
          return param
        except:
          return param
          
          
def showKeyboardDialog(header='Text Entry', text=None):
    keyboard = xbmc.Keyboard(text, header, False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        text = keyboard.getText()
    else:
        text = ''
    return text  

  
def AddUrl(url):
    url = showKeyboardDialog('Add Torrent from URL', url)
    if (url == ''):
        mainMenu()
    return url
        
    
# Initialize URL parameters.
url = None
name = None
mode = None
token = None
action = None
hash = None
params = getParameters()

# Parse internal URL.
try:
    url = urllib.unquote_plus(params["url"])
    print url
    mode = 5
except:
    pass

try:
    name = urllib.unquote_plus(params["name"])
    print name
except:
    pass

try:
    number = urllib.unquote_plus(params["number"])
    print number
except:
    pass

try:
    mode = int(params["mode"])
    print mode
except:
    pass
    
try:
    token = urllib.unquote_plus(params["token"])
    print token
except:
    pass

try:
    action = urllib.unquote_plus(params["action"])
    print action
except:
    pass

try:
    hash = urllib.unquote_plus(params["hash"])
    print hash
except:
    pass

# Open directories based on selection.
if mode == None:
    mainMenu()
       
# Torrent list.
elif mode == 1:
    import resources.lib.list as list
    dialog = xbmcgui.Dialog()
    list.menu()

# qBittorrent version.
elif mode == 2:
    dialog = xbmcgui.Dialog()
    ver = Utility.GetVersion()
    common.messageWindow('qBittorrent', 'Version ' + str(ver))

# Refresh list.
elif mode == 3:
    xbmc.executebuiltin('Container.Refresh')

# Torrent action command.
elif mode == 4:
    Utility.TorrentAction(url=settings.__url__, token=token, hash=hash, action=action)
    xbmc.executebuiltin('Container.Refresh')

# Add Torrent download URL.
elif mode == 5:
    url = AddUrl(url)
    auth_token = Utility.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    Utility.TorrentAction(url=settings.__url__, token=auth_token, hash=url, action='/command/download')
    xbmc.executebuiltin('Container.Refresh')

# Open context menu on normal left click selection.
elif mode == 99:
    xbmc.executebuiltin('Action(ContextMenu)')

xbmcplugin.endOfDirectory(int(sys.argv[1]))

