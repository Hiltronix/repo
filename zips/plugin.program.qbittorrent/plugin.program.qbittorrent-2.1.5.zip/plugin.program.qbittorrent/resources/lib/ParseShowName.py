#!/usr/local/bin/python2.7
# -*- coding: utf-8 -*-

# Original work by Divij Bindlish (dvjbndlsh93@gmail.com) PTN (Parse Torrent Names) version 1.1.1, license MIT.
# v.1.1.2, 2016-11, Modified by Hiltronix due to conflicts when requesting pull requests.


import re


patterns = [
    #('season', '(s?([0-9]{1,2}))[ex]'),
    #('episode', '([ex]?([0-9]{2})(?:[^0-9]|$))'),
    ('season', '((s?|season.?)([0-9]{1,2})).?([ex]|ep|.?episode)'),
    ('episode', '(([ex]|ep|episode.?)([0-9]{2})(?:[^0-9]|$))'),
    ('year', '([\[\(]?((?:19[0-9]|20[01])[0-9])[\]\)]?)'),
    ('resolution', '([0-9]{3,4}p)'),
    ('quality', ('((?:PPV\.)?[HP]DTV|(?:HD)?CAM|B[DR]Rip|TS|(?:PPV '
                 ')?WEB-?DL(?: DVDRip)?|HDRip|DVDRip|DVDR'
                 'IP|CamRip|W[EB]BRip|BluRay|DvDScr|hdtv)')),
    ('codec', '(xvid|HEVC|[hx]\.?26[45])'),
    ('audio', ('(MP3|DD5\.?1|Dual[\- ]Audio|LiNE|H?DTS|AC-3|AAC(?:\.?2\.0)?|AC\-?3(?:\.5\.1)?)')),
    ('group', '(- ?([^-]+(?:-={[^-]+-?$)?))$'),
    ('region', 'R[0-9]'),
    ('extended', '(EXTENDED(:?.CUT)?)'),
    ('hardcoded', 'HC'),
    ('proper', 'PROPER'),
    ('repack', 'REPACK'),
    ('container', '(MKV|AVI)'),
    ('widescreen', 'WS'),
    ('website', '^(\[ ?([^\]]+?) ?\])'),
    ('language', 'rus\.eng'),
    ('sbs', '(?:Half-)?SBS'),
]

types = {
    'season': 'integer',
    'episode': 'integer',
    'year': 'integer',
    'extended': 'boolean',
    'hardcoded': 'boolean',
    'proper': 'boolean',
    'repack': 'boolean',
    'widescreen': 'boolean'
}


class PSN(object):
    def _escape_regex(self, string):
        return re.sub('[\-\[\]{}()*+?.,\\\^$|#\s]', '\\$&', string)

    def __init__(self):
        self.torrent = None
        self.excess_raw = None
        self.group_raw = None
        self.start = None
        self.end = None
        self.title_raw = None
        self.parts = None

    def _part(self, name, match, raw, clean):
        # The main core instructuions
        self.parts[name] = clean

        if len(match) != 0:
            # The instructions for extracting title
            index = self.torrent['name'].find(match[0])
            if index == 0:
                self.start = len(match[0])
            elif self.end is None or index < self.end:
                self.end = index

        if name != 'excess':
            # The instructions for adding excess
            if name == 'group':
                self.group_raw = raw
            if raw is not None:
                self.excess_raw = self.excess_raw.replace(raw, '')

    def _late(self, name, clean):
        if name == 'group':
            self._part(name, [], None, clean)
        elif name == 'episodeName':
            clean = re.sub('[\._]', ' ', clean)
            clean = re.sub('_+$', '', clean)
            self._part(name, [], None, clean.strip())

    def parse(self, name):
        self.parts = {}
        self.torrent = {'name': name}
        self.excess_raw = name
        self.group_raw = ''
        self.start = 0
        self.end = None
        self.title_raw = None

        for key, pattern in patterns:
            if key not in ('season', 'episode', 'website'):
                pattern = r'\b%s\b' % pattern

            clean_name = re.sub('_', ' ', self.torrent['name'])
            match = re.findall(pattern, clean_name, re.I)
            if len(match) == 0:
                continue

            index = {}
            if isinstance(match[0], tuple):
                match = list(match[0])
            if len(match) > 2:
                index['raw'] = 0
                index['clean'] = 2
            elif len(match) > 1:
                index['raw'] = 0
                index['clean'] = 1
            else:
                index['raw'] = 0
                index['clean'] = 0

            if key in types.keys() and types[key] == 'boolean':
                clean = True
            else:
                clean = match[index['clean']]
                if key in types.keys() and types[key] == 'integer':
                    clean = int(clean)
            if key == 'group':
                if re.search(patterns[5][1], clean, re.I) \
                        or re.search(patterns[4][1], clean):
                    continue  # Codec and quality.
                if re.match('[^ ]+ [^ ]+ .+', clean):
                    key = 'episodeName'
            if key == 'episode':
                sub_pattern = self._escape_regex(match[index['raw']])
                self.torrent['map'] = re.sub(
                    sub_pattern, '{episode}', self.torrent['name']
                )
            self._part(key, match, match[index['raw']], clean)

        # Start process for title
        raw = self.torrent['name']
        if self.end is not None:
            raw = raw[self.start:self.end].split('(')[0]

        clean = re.sub('^ -', '', raw)
        if clean.find(' ') == -1 and clean.find('.') != -1:
            clean = re.sub('\.', ' ', clean)
        clean = re.sub('_', ' ', clean)
        clean = re.sub('([\[\(_]|- )$', '', clean).strip()

        self._part('title', [], raw, clean)

        # Start process for end
        clean = re.sub('(^[-\. ()]+)|([-\. ]+$)', '', self.excess_raw)
        clean = re.sub('[\(\)\/]', ' ', clean)
        match = re.split('\.\.+| +', clean)
        if len(match) > 0 and isinstance(match[0], tuple):
            match = list(match[0])

        clean = [item for item in filter(bool, match)]
        clean = [item for item in filter(lambda a: a != '-', clean)]
        if len(clean) != 0:
            group_pattern = clean[-1] + self.group_raw
            if self.torrent['name'].find(group_pattern) == \
                    len(self.torrent['name']) - len(group_pattern):
                self._late('group', clean.pop() + self.group_raw)

            if 'map' in self.torrent.keys() and len(clean) != 0:
                episode_name_pattern = (
                    '{episode}'
                    '' + re.sub('_+$', '', clean[0])
                )
                if self.torrent['map'].find(episode_name_pattern) != -1:
                    self._late('episodeName', clean.pop(0))

        if len(clean) != 0:
            if len(clean) == 1:
                clean = clean[0]
            self._part('excess', [], self.excess_raw, clean)
        return self.parts


psn = PSN()


def parse(name):
    return psn.parse(name)


def ConvertFilenameToShowName(filename, show_name=''):
# Formats a media file name in a proper logical format.
# If "show_name" exists, then that will replace the title text.
# TV Shows: Name Here SxxExx Meta Data
# Movies: Name Here (year) Meta Data
# Returns None if error.
    # Remove SageTV airing ID.
    filename = re.sub('\-([0-9]{4,9})\-[0-9]{1}\.', '.', filename)
    # Remove and save file extension.
    ext = ''
    match = re.search('\.(avi|m4v|mkv|mov|mp[1-9]|mpg|ts|vp[0-9]{1,2}|webm|wmv)', filename)
    if match:
        ext = match.group(0)
        if filename.endswith(ext):
            filename = re.sub(ext, '', filename, flags=re.IGNORECASE)
    # Remove hyphens.
    clean = re.sub('\-', ' ', filename)
    # Remove periods.
    clean = re.sub('\.', ' ', clean)
    # Remove square brackets.
    clean = re.sub('\[', ' ', clean)
    clean = re.sub('\]', ' ', clean)
    # Remove excess whitespace.
    clean = re.sub(r'\s+', ' ', clean)

    clean = parse(clean)
    info = parse(filename)

    try:

        title = clean.get('title').title()
        year = info.get('year')
        season = info.get('season')
        episode = info.get('episode')
        #episodeName = info.get('episodeName')
        quality = info.get('quality')
        resolution = info.get('resolution')
        codec = info.get('codec')
        audio = info.get('audio')

        if show_name:
            name = show_name
        else:
            name = title
        if year:
            name += ' (%s)' %year
        if season:
            name += ' S{:02d}'.format(int(season))
        if episode:
            name += 'E{:02d}'.format(int(episode))
        #if episodeName:
        #    name += ' %s' %episodeName.title()
        if resolution:
            name += ' %s' %resolution
        if quality:
            name += ' %s' %quality
        if codec:
            name += ' %s' %codec
        if audio:
            name += ' %s' %audio
        if ext:
            name += ext
    except:
        name = None
    return name


if __name__ == '__main__':
    filenames = [
                 "Gotham-S03E09-{Mad City The Executioner}-17956898-0.ts",
                 "Timeless (2016)-S01E06-The Watergate Tape-17956528-0.ts",
                 "How.It's.Made-S28E09-EndoscopesMegaphonesandUranium-17957510-0.ts",
                 "How It's Made-S28E09-Endoscopes   Megaphones  and       Uranium-17957510-0.ts",
                 'Westworld S01E07 720p HDTV x264-Belex - Dual Audio',
                 'Westworld.S01.EP02.HDTV.x264.[ExYu-Subs HC]',
                 'Westworld [WEB-DL-1080p](Season 01 Episode 04)(www.kinokopilka.pro)',
                 'Westworld 1080p Almas de metal ENG ESP ITA FRE DEU',
                 'WESTWORLD (Season 01) DUB 1080',
                 'WESTWORLD_2016_S01_RUS_DUB_Kravec_Eng_DD5.1_N.B_HDTV_1080p',
                 'Westworld.1973.720p.10bit.BluRay.6CH.x265.HEVC-PSA',
                 'Westworld.S11E27.HDTV.x264-KILLERS',
                 'Westworld S01E07 Trompe L Oeil WEBRip 480p x264 AAC-VYTO',
                 'Westworld.S01E07.Trompe.L.Oeil.1080p.WebRip.x264.Crazy4ad.mkv',
                 'Westworld.S01E07.HDTV.mkv',
                 'Westworld.S01E07.Trompe.L.Oeil.720p.HBO.WEBRip.430MB.MkvCage.mkv',
                 "Westworld.S01E07.480p.194mb.hdtv.x264-][ Trompe L'Oeil ][ mp4",
                 'Westworld.S01E07.Trompe.L.Oeil.720p.HBO.WEBRip.DD5.1.H264-monkee[rarbg]',
                 'Westworld S01E07 Trompe L Oeil 720p HBO WEBRip HEVC 2CH x.265',
                 'Westworld.S01E07.Trompe.L.Oeil.WEBRip.480p.x264.AAC-VYTO [P2PDL.com]',
                 'Westworld S12E18 Trompe L Oeil 1080p HBO WEBRip HEVC DD5.1 AC-3',
                 'Westworld S01E07 Trompe L Oeil 1080p HBO WEBRip AC-3 HEVC DD5.1 x265'
                 ]
    for filename in filenames:
        print ConvertFilenameToShowName(filename, None) + ' <--------------- ' + filename

    file = 'Name Here s01x4 something blah xxx'
    info = parse(file)
    season = int(info.get('season', 0))
    episode = int(info.get('episode', 0))
    print int(season), int(episode)

