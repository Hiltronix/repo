# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import re
import os
import sys
import json
import math
import urllib
import urllib2
import requests
import settings


# Convert bytes to formatted sizes.
def convertBytes(size, places):
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    if (size > 0):
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size/p, places)
        if places == 0:
            s = int(s)
        return '%s %s' %(s, size_name[i])
    else:
        return '0B'


# Convert seconds into years, days, hours, min, seconds.
def convertSeconds(secs):
    years, secs = divmod(secs, 31556952)
    min, secs = divmod(secs, 60)
    hours, min = divmod(min, 60)
    days, hours = divmod(hours, 24)

    string = ''
    if years:
        string = str(years) + 'yrs'
    if days:
        if string:
            string += ','
        string += str(days) + 'days'
    if hours:
        if string:
            string += ','
        string += str(hours) + 'hrs'
    if min:
        if string:
            string += ','
        string += str(min) + 'min'
    if secs:
        if string:
            string += ','
        string += str(min) + 'sec'

    return string
    

# Replace troublesome characters, that effect sorting.
def FixBadChar(text):
    text = text.replace(u'\u2019', u"'")  # Replace curved apostrophe � with standard ' apostrophe.
    text = text.replace(u'\u2010', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2011', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2012', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2013', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2014', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2015', u"-")  # Replace wide dash with standard hyphen.
    return text
    

def getFromDict(dataDict, mapList, default_result=None):
# Similar to dictionary '.get' but for nested dictionaies.
# Example: getFromDict(dataDict, ["b", "v", "y"])
# Returns 'None' if not found, unless a default result is provided.
    try:
        value = reduce(lambda d, k: d[k], mapList, dataDict)
        if value:
            return value
        else:
            return default_result
    except Exception:
        return default_result


def GetUrlData(url=None, headers={}, proxies={}, verify=False, log=None, timeout=10):
    # Fetches data from "url" (http or https) and return it as a string, with timeout.
    # Supply any headers and proxies as dict.
    # A default User-Agent will be added if the headers dict doesn't contain one.
    # Set "verify" True if you want SSL certs to be verified.
    # If using logging, pass your log handle.
    try:
        if not headers.get('User-Agent'):
            headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'

        response = requests.get(url, headers=headers, proxies=proxies, verify=verify, timeout=timeout)
        if response.status_code == 200:
            return response.content
        else:
            return None
    except requests.Timeout:
        common.messageWindow('Network Connection', 'The request timed out.[CR]The server may be busy or unavailable.')
        return None
    except Exception, e:
        #print e
        xbmc.log('sickrage.sickbeard.GetUrlData: {0}'.format(e), xbmc.LOGERROR)
        if log:
            log.debug('*** Exception ***', exc_info=1)
        err = 'Exception: {0}'.format(e)
        common.messageWindow('Network Connection', err)
        return None


# SickRage class which mas all API calls to SickRage.
class Util:

    CONNECT_ERROR = "I was unable to retrieve data.\n\nError: "

    
    # Get the list of shows and all meta data.
    def GetList(self, auth_token, filter, category):
        torrents=[]
        try:
            if category:
                response = GetUrlData(url=settings.__url__+'/query/torrents?filter={}&category={}'.format(filter, category), headers={'Cookie':auth_token})
            else:
                response = GetUrlData(url=settings.__url__+'/query/torrents?filter={}'.format(filter), headers={'Cookie':auth_token})
            result = json.loads(response)
            #print json.dumps(result, sort_keys=True, indent=4)
            for each in result:
                torrent = {}
                torrent['added_on'] = each.get('added_on', 0)
                torrent['category'] = each.get('category', '')
                torrent['completed'] = each.get('completed', 0)
                torrent['completion_on'] = each.get('completion_on', 0)
                torrent['dl_limit'] = each.get('dl_limit', 0)
                torrent['dlspeed'] = each.get('dlspeed', 0)
                torrent['downloaded'] = each.get('downloaded', 0)
                torrent['downloaded_session'] = each.get('downloaded_session', 0)
                torrent['eta'] = each.get('eta', 0)
                torrent['f_l_piece_prio'] = each.get('f_l_piece_prio', False)
                torrent['force_start'] = each.get('force_start', False)
                torrent['hash'] = each.get('hash', '')
                torrent['last_activity'] = each.get('last_activity', 0)
                torrent['name'] = each.get('name', '')
                torrent['num_complete'] = each.get('num_complete', 0)
                torrent['num_incomplete'] = each.get('num_incomplete', 0)
                torrent['num_leechs'] = each.get('num_leechs', 0)
                torrent['num_seeds'] = each.get('num_seeds', 0)
                torrent['priority'] = each.get('priority', 0)
                torrent['progress'] = each.get('progress', 0.0)
                torrent['ratio'] = each.get('ratio', 0.0)
                torrent['ratio_limit'] = each.get('ratio_limit', 0)
                torrent['remaining'] = each.get('remaining', 0)
                torrent['save_path'] = each.get('save_path', '')
                torrent['seen_complete'] = each.get('seen_complete', 0)
                torrent['seq_dl'] = each.get('seq_dl', False)
                torrent['size'] = each.get('size', 0)
                torrent['state'] = each.get('state', '')
                torrent['super_seeding'] = each.get('super_seeding', False)
                torrent['total_size'] = each.get('total_size', 0)
                torrent['tracker'] = each.get('tracker', 0)
                torrent['up_limit'] = each.get('up_limit', 0)
                torrent['uploaded'] = each.get('uploaded', 0)
                torrent['uploaded_session'] = each.get('uploaded_session', 0)
                torrent['upspeed'] = each.get('upspeed', 0)

                torrents.append(torrent)
        except Exception, e:
            settings.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return torrents
    

    # Get the show ID numbers.
    def GetVersion(self):
        result = ''
        try:
            result = GetUrlData(url=settings.__url__+"/version/qbittorrent")
        except Exception, e:
            settings.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return result
    

    # Get the API version.
    def GetApiVersion(self):
        result = ''
        try:
            result = GetUrlData(url=settings.__url__+"/version/api")
        except Exception, e:
            settings.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return result
    

    # Log into server and get security token from cookie.
    def GetQBLoginToken(self, url=None, username=None, password=None):
        data = urllib.urlencode({'username': username,
                                 'password': password})
    
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Content-Length': len(data)}
    
        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + '/login', data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
        except urllib2.HTTPError,e:
            result = e
            print e, e.code
    
        # Check. Substitute with appropriate HTTP code.
        if result.code == 200:
            cookie = result.info()['Set-Cookie']
            auth_token = 'SID=' + re.search('SID=(.*?)\;', cookie).group(1)
        else:
            auth_token = None
        return auth_token
    
      
    def TorrentAction(self, url=None, token=None, hash=None, action=None, category=''):
        if hash:
            if action in ['/command/delete','/command/deletePerm']:
                data = urllib.urlencode({'hashes': hash})

            elif action in ['/command/setForceStart']:
                data = urllib.urlencode({'hashes': hash, 'value': 'true'})
                
            elif action in ['/command/download']:
                data = urllib.urlencode({'urls': hash, 'category': category})  # We are using the hash variable to transfer the URL string.

            elif action in ['/command/setCategory']:
                data = urllib.urlencode({'hashes': hash, 'category': category})

            else:
                data = urllib.urlencode({'hash': hash})
        else:
            data = ''

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Content-Length': len(data),
                   'Cookie': token}
    
        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + action, data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
        except urllib2.HTTPError,e:
            result = e
            print e, e.code
        print 'Action: '+action + ' ' + str(result.code)
    
