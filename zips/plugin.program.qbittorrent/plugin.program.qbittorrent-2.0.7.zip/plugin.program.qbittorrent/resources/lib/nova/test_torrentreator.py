

from engines.torrentreactor import torrentreactor
from fix_encoding import fix_encoding


fix_encoding()

result = torrentreactor().search('Queen of the South S01E08')

print result
