import sys
from engines.torrentz import torrentz
from fix_encoding import fix_encoding


fix_encoding()

temp_file = 'C:\\Users\\Carey\\AppData\\Local\\qBittorrent\\nova\\text.txt'
stdout = sys.stdout
sys.stdout = open(temp_file, 'w')

result = torrentz().search('From Dusk Till Dawn The Series S03E09')

sys.stdout.flush()
sys.stdout = stdout

print result
