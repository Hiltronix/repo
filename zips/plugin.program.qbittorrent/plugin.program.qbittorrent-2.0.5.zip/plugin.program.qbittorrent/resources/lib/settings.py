import sys
import xbmcgui
import xbmcaddon


# Show error pop up then exit plugin.
def messageWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)


# Show error pop up then exit plugin.
def errorWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)
    sys.exit()


def createURL(ip, port, use_ssl, custom_url):
    if custom_url != "":
        return custom_url
    if str(ip) == "" or str(port) == "":
        errorWindow("Error", "Must configure IP and port settings before use.")
    else:
        if use_ssl == "true":
            return "https://"+str(ip) + ':' + str(port)
        else:
            return "http://"+str(ip) + ':' + str(port)


# Set constants.
pluginID = 'plugin.program.qbittorrent'
my_addon = xbmcaddon.Addon(pluginID)
addon_path = my_addon.getAddonInfo('path')

__ip__ = my_addon.getSetting('IP')
__port__= my_addon.getSetting('Port')
__ssl_bool__= my_addon.getSetting('Use SSL')
__username__ = my_addon.getSetting('Username')
__password__= my_addon.getSetting('Password')
__url_bool__= my_addon.getSetting('Use Custom URL')
if __url_bool__ == "true":
    __custom_url__= my_addon.getSetting('Custom URL')
else:
    __custom_url__= ""


# Create the URL used to access webserver.
__url__ = createURL(__ip__, __port__, __ssl_bool__, __custom_url__)


# Initialize default settings.
search_engines = my_addon.getSetting('search_engines')
if search_engines == '':
    my_addon.setSetting('search_engines', 'all')
    
search_categories = ['all', 'movies', 'tv', 'music', 'games', 'anime', 'software', 'pictures', 'books']

torrent_filter = ['all', 'downloading', 'seeding', 'completed', 'resumed', 'paused', 'active', 'inactive', 'errored']

torrent_filter_preselect = my_addon.getSetting('torrent_filter_preselect')
if torrent_filter_preselect == '':
    my_addon.setSetting('torrent_filter_preselect', '0')
    
search_cat_preselect = my_addon.getSetting('search_cat_preselect')
if search_cat_preselect == '':
    my_addon.setSetting('search_cat_preselect', '0')
    
