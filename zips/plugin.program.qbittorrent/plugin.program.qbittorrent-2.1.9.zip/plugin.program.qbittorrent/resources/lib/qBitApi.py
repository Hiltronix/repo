# -*- coding: utf-8 -*-
#
# qBitorrent API Library.
#
# (c) Hiltronix 2017
#
# Requirements:
#   qBitorrent must have internal webserver enabled, with username and password set.


import re
import os
import sys
import json
import urllib
import urllib2
import traceback
import BaseHTTPServer
try:
    import requests
except ImportError, e:
    print e


# qBitorrent class which with API calls to qBitorrent application.
class qBit:

    CONNECT_ERROR = "I was unable to retrieve data.\n\nError: "
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'

    def GetList(self, url, token, filter, category):
    # Get the list of shows and all meta data.
    # Returns a tuple (return value, error message, traceback string)
    #   "return value" is None if not available or error.
    #   "error message" is None if no error exists.
    #   "traceback string" is the formatted multi-line traceback string, if available.
        torrents=[]
        try:
            if category:
                response = requests.get('{}/api/v2/torrents/info?filter={}&category={}'.format(url, filter, category), headers={'Cookie': token, 'User-Agent': self.user_agent, 'Origin': url, 'Content-Type': 'text/html; charset=utf-8'}, proxies={}, verify=False, timeout=30)
            else:
                response = requests.get('{}/api/v2/torrents/info?filter={}'.format(url, filter), headers={'Cookie': token, 'User-Agent': self.user_agent, 'Origin': url, 'Content-Type': 'text/html; charset=utf-8'}, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                result = json.loads(response.content)
                #print json.dumps(result, sort_keys=True, indent=4)
            else:
                return None, requests.status_codes._codes[response.status_code][0], None

            for each in result:
                torrent = {}
                torrent['added_on'] = each.get('added_on', 0)
                torrent['category'] = each.get('category', '')
                torrent['completed'] = each.get('completed', 0)
                torrent['completion_on'] = each.get('completion_on', 0)
                torrent['dl_limit'] = each.get('dl_limit', 0)
                torrent['dlspeed'] = each.get('dlspeed', 0)
                torrent['downloaded'] = each.get('downloaded', 0)
                torrent['downloaded_session'] = each.get('downloaded_session', 0)
                torrent['eta'] = each.get('eta', 0)
                torrent['f_l_piece_prio'] = each.get('f_l_piece_prio', False)
                torrent['force_start'] = each.get('force_start', False)
                torrent['hash'] = each.get('hash', '')
                torrent['last_activity'] = each.get('last_activity', 0)
                torrent['name'] = each.get('name', '')
                torrent['num_complete'] = each.get('num_complete', 0)
                torrent['num_incomplete'] = each.get('num_incomplete', 0)
                torrent['num_leechs'] = each.get('num_leechs', 0)
                torrent['num_seeds'] = each.get('num_seeds', 0)
                torrent['priority'] = each.get('priority', 0)
                torrent['progress'] = each.get('progress', 0.0)
                torrent['ratio'] = each.get('ratio', 0.0)
                torrent['ratio_limit'] = each.get('ratio_limit', 0)
                torrent['remaining'] = each.get('remaining', 0)
                torrent['save_path'] = each.get('save_path', '')
                torrent['seen_complete'] = each.get('seen_complete', 0)
                torrent['seq_dl'] = each.get('seq_dl', False)
                torrent['size'] = each.get('size', 0)
                torrent['state'] = each.get('state', '')
                torrent['super_seeding'] = each.get('super_seeding', False)
                torrent['total_size'] = each.get('total_size', 0)
                torrent['tracker'] = each.get('tracker', 0)
                torrent['up_limit'] = each.get('up_limit', 0)
                torrent['uploaded'] = each.get('uploaded', 0)
                torrent['uploaded_session'] = each.get('uploaded_session', 0)
                torrent['upspeed'] = each.get('upspeed', 0)

                torrents.append(torrent)
        except Exception, e:
            trbk = traceback.format_exc()
            print trbk
            return None, e, trbk
        return torrents, None, None


    def GetVersion(self, url, token=None):
    # Get the qBittorrent server version number.
    # Returns a tuple (return value, error message, traceback string)
    #   "return value" is None if not available or error.
    #   "error message" is None if no error exists.
    #   "traceback string" is the formatted multi-line traceback string, if available.
        try:
            response = requests.get('{}/api/v2/app/version'.format(url), headers={'Cookie': token, 'User-Agent': self.user_agent, 'Origin': url}, proxies={}, verify=False, timeout=5)
            if response.status_code == 200:
                return response.content
            else:
                return requests.status_codes._codes[response.status_code][0]
        except Exception, e:
            trbk = traceback.format_exc()
            print trbk
            return None


    def GetApiVersion(self, url, token=None):
    # Get the qBitorrent server API version.
    # Returns a tuple (return value, error message, traceback string)
    #   "return value" is None if not available or error.
    #   "error message" is None if no error exists.
    #   "traceback string" is the formatted multi-line traceback string, if available.
        try:
            response = requests.get('{}/api/v2/app/webapiVersion'.format(url), headers={'Cookie': token, 'User-Agent': self.user_agent, 'Origin': url}, proxies={}, verify=False, timeout=5)
            if response.status_code == 200:
                return response.content
            else:
                return requests.status_codes._codes[response.status_code][0]
        except Exception, e:
            trbk = traceback.format_exc()
            print trbk
            return None


    def GetQBLoginToken(self, url, username, password):
    # Log into server and get security token from cookie.
        data = urllib.urlencode({'username': username,
                                 'password': password})

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Origin': url,
                   'Content-Length': len(data)}

        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + '/api/v2/auth/login', data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
        except urllib2.HTTPError, e:
            tb = traceback.format_exc()
            print tb
            result = e

        # Check. Substitute with appropriate HTTP code.
        if result.code == 200:
            cookie = result.info()['Set-Cookie']
            token = 'SID=' + re.search('SID=(.*?)\;', cookie).group(1)
        else:
            token = None
        return token


    def TorrentAction(self, url, token=None, hash=None, action=None, category=''):
    # Initiates a qBitorrent action.
    # Does not return a result code, only errors if they occur.
    # Returns a tuple (return value, error message, traceback string)
    #   "error message" is None if no error exists.
    #   "traceback string" is the formatted multi-line traceback string, if available.
        if hash:
            if action in ['/api/v2/torrents/delete']:
                data = urllib.urlencode({'hashes': hash, 'deleteFiles': 'true'})

            elif action in ['/api/v2/torrents/pauseAll']:
                action = '/api/v2/torrents/pause'
                data = urllib.urlencode({'hashes': 'all'})

            elif action in ['/api/v2/torrents/resumeAll']:
                action = '/api/v2/torrents/resume'
                data = urllib.urlencode({'hashes': 'all'})

            elif action in ['/api/v2/torrents/setForceStart']:
                data = urllib.urlencode({'hashes': hash, 'value': 'true'})

            elif action in ['/api/v2/torrents/add']:
                data = urllib.urlencode({'urls': hash, 'category': category})  # We are using the hash variable to transfer the URL string.

            elif action in ['/api/v2/torrents/setCategory']:
                data = urllib.urlencode({'hashes': hash, 'category': category})

            else:
                data = urllib.urlencode({'hashes': hash})
        else:
            data = ''

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Content-Length': len(data),
                   'Origin': url,
                   'Cookie': token}

        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + action, data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
            msg = '{} {}'.format(result.code, BaseHTTPServer.BaseHTTPRequestHandler.responses[result.code][0])
            print 'Action: {} {}'.format(action, msg)
            if result.code == 200:
                return None, None
            else:
                raise Exception('qBit Action was not successfull!')
                return msg, None
        except Exception, e:
            trbk = traceback.format_exc()
            print trbk
            return e, trbk

