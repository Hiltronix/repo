# -*- coding: utf-8 -*-

from pprint import pprint
import re
import os
import sys
import math
import urllib
import urllib2
import socket
import json
import settings
import xbmc
import xbmcgui


# Convert bytes to formatted sizes.
def convertBytes(size, places):
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    if (size > 0):
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size/p, places)
        if places == 0:
            s = int(s)
        return '%s %s' %(s, size_name[i])
    else:
        return '0B'


# Convert seconds into years, days, hours, min, seconds.
def convertSeconds(secs):
    years, secs = divmod(secs, 31556952)
    min, secs = divmod(secs, 60)
    hours, min = divmod(min, 60)
    days, hours = divmod(hours, 24)

    string = ''
    if years:
        string = str(years) + 'yrs'
    if days:
        if string:
            string += ','
        string += str(days) + 'days'
    if hours:
        if string:
            string += ','
        string += str(hours) + 'hrs'
    if min:
        if string:
            string += ','
        string += str(min) + 'min'
    if secs:
        if string:
            string += ','
        string += str(min) + 'sec'

    return string
    

# Replace troublesome characters, that effect sorting.
def FixBadChar(text):
    text = text.replace(u'\u2019', u"'")  # Replace curved apostrophe � with standard ' apostrophe.
    text = text.replace(u'\u2010', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2011', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2012', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2013', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2014', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2015', u"-")  # Replace wide dash with standard hyphen.
    return text
    

def GetUrlData(url=None, add_useragent=False, cookie=None, encodeType='utf-8'):
    # Fetches data from "url" (http or https) and return it as a string, with timeout.
    # Set "encodeType" to None for image and binary files.
    attempts = 0
    request = urllib2.Request(url)
    if cookie:
        headers = {'Cookie': cookie}
        for (key, value) in headers.iteritems():
            request.add_header(key, value)
    if add_useragent:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'}
        for (key, value) in headers.iteritems():
            request.add_header(key, value)
    # Try up to 3 times to make connection.
    while (attempts < 3) and (not xbmc.abortRequested):
        try:
            response = urllib2.urlopen(request, timeout=10)  # Wait 10 seconds for connection.
            if not encodeType:
                data = response.read()
                return data
            else:
                encoding = response.headers.getparam('charset')
                if encoding:
                    print 'Encoding: ' + str(encoding)
                    data = response.read().decode(encoding)
                    return data.encode(encodeType, 'ignore')
                else:
                    data = response.read()
                    return data
        except urllib2.URLError, e:
            print "URLError Msg: %s   Getting data from: %s" %(e, url)
            xbmc.sleep(500)
            if xbmc.abortRequested:
                break
            attempts += 1
        except socket.timeout, e:
            print "Socket Timeout Error Msg: %s   Getting data from: %s" %(e, url)
            xbmc.sleep(500)
            if xbmc.abortRequested:
                break
            attempts += 1
        except Exception, e:
            print "GetUrlData Exception Error: %s   Getting data from: %s" %(e, url)
            return None
    return None


# SickRage class which mas all API calls to SickRage.
class Util:

    CONNECT_ERROR = "I was unable to retrieve data.\n\nError: "

    
    # Get the list of shows.
    def GetList(self, auth_token):
        torrents=[]
        try:
            response = GetUrlData(url=settings.__url__+'/query/torrents?filter=all', add_useragent=True, cookie=auth_token, )
            result = json.loads(response)
            for each in result:
                torrent = {}
                torrent['dlspeed'] = each['dlspeed']
                torrent['eta'] = each['eta']
                torrent['f_l_piece_prio'] = each['f_l_piece_prio']
                torrent['force_start'] = each['force_start']
                torrent['hash'] = each['hash']
                torrent['label'] = each['label']
                torrent['name'] = FixBadChar(each['name'])
                torrent['num_complete'] = each['num_complete']
                torrent['num_incomplete'] = each['num_incomplete']
                torrent['num_leechs'] = each['num_leechs']
                torrent['num_seeds'] = each['num_seeds']
                torrent['priority'] = each['priority']
                torrent['progress'] = each['progress']
                torrent['ratio'] = each['ratio']
                torrent['seq_dl'] = each['seq_dl']
                torrent['size'] = each['size']
                torrent['state'] = each['state']
                torrent['super_seeding'] = each['super_seeding']
                torrent['upspeed'] = each['upspeed']
                torrents.append(torrent)
        except Exception, e:
            settings.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return torrents
    

    # Get the show ID numbers
    def GetVersion(self):
        result = ''
        try:
            result = GetUrlData(settings.__url__+"/version/qbittorrent", False)
        except Exception, e:
            settings.errorWindow(sys._getframe().f_code.co_name, self.CONNECT_ERROR+str(e))
        return result
    

    # Log into server and get security token from cookie.
    def GetQBLoginToken(self, url=None, username=None, password=None):
        data = urllib.urlencode({'username': username,
                                 'password': password})
    
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Content-Length': len(data)}
    
        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + '/login', data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
        except urllib2.HTTPError,e:
            result = e
            print e, e.code
    
        # Check. Substitute with appropriate HTTP code.
        if result.code == 200:
            cookie = result.info()['Set-Cookie']
            auth_token = 'SID=' + re.search('SID=(.*?)\;', cookie).group(1)
        else:
            auth_token = None
        return auth_token
    
      
    def TorrentAction(self, url=None, token=None, hash=None, action=None):
        if hash:
            if action in ['/command/delete','/command/deletePerm']:
                data = urllib.urlencode({'hashes': hash})
            elif action in ['/command/setForceStart']:
                data = urllib.urlencode({'hashes': hash,
                                         'value': 'true'})
            elif action in ['/command/download']:
                data = urllib.urlencode({'urls': hash})  # We are using the hash variable to transfer the URL string.
            else:
                data = urllib.urlencode({'hash': hash})
        else:
            data = ''

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
                   'Content-Type': 'application/x-www-form-urlencoded',
                   'Content-Length': len(data),
                   'Cookie': token}
    
        method = 'POST'
        handler = urllib2.HTTPHandler()
        opener = urllib2.build_opener(handler)
        request = urllib2.Request(url + action, data=data)

        for (key, value) in headers.iteritems():
            request.add_header(key, value)

        request.get_method = lambda: method
        try:
            result = opener.open(request)
        except urllib2.HTTPError,e:
            result = e
            print e, e.code
        print 'Action: '+action + ' ' + str(result.code)
    
