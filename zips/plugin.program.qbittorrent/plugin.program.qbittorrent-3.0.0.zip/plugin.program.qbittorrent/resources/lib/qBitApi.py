# -*- coding: utf-8 -*-

__title__ = 'qBitApi'
__description__ = 'qBittorrent API library.'
__author__ = 'Hiltronix'
__copyright__ = 'Copyright 2020 Hiltronix'
__license__ = 'Apache 2.0'
__url__ = 'https://hiltronix.com'
__version_major__ = 1
__version_minor__ = 2
__version_patch__ = 2
__version_info__ = (__version_major__, __version_minor__, __version_patch__)
__version__ = '.'.join(str(i) for i in __version_info__)

# Refer:
#   WebUI API Documentation
#       https://github.com/qbittorrent/qBittorrent/wiki/Web-API-Documentation
#
# Requirements:
#   qBitorrent must have internal webserver enabled, with username and password assigned.

try:
    import re
    import os
    import sys
    import json
    import time
    from urllib.parse import urlencode, urlparse
    import traceback
    import requests

except ImportError as e:
    msg = 'Warning! {}'.format(e)
    print(msg)
    raise Exception(msg)


def SafeGet(dct, *keys, defVal=None):
    for key in keys:
        try:
            dct = dct[key]
        except KeyError:
            return defVal
    return dct


def GetOriginUrl(url):
# Returns the "Origin" formatted header value from an URL.
# Similar to "Referer" header value, but the path is removed.
# As per: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin
    try:
        newUrl = url

        scheme = urlparse(url).scheme
        host = urlparse(url).hostname
        port = urlparse(url).port
        path = urlparse(url).path

        newUrl = '{}://{}{}'.format(scheme, host, ':{}'.format(port) if port else '')

    except Exception as e:
        trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
        print(trbk)
        try: log.debug(trbk)
        except Exception as e: print(e)

    finally:
        return newUrl


# qBitorrent class which with API calls to qBitorrent application.
class qBit:

    minApiVer = '2.2.0'
    CONNECT_ERROR = "I was unable to retrieve data.\n\nError: "
    userAgent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0'


    def GetQBLoginToken(self, url, username, password):
        try:
            authToken = None

            data = urlencode({'username': username,
                              'password': password})

            headers = {'User-Agent': self.userAgent,
                       'Content-Type': 'application/x-www-form-urlencoded',
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Content-Length': str(len(data))}

            url = '{}/api/v2/auth/login'.format(url)

            response = requests.post(url, data=data, headers=headers, proxies={}, verify=False, timeout=30)
            if response.content == b'Ok.':
                reqHeaders = response.headers
                #print(reqHeaders)
                cookie = SafeGet(reqHeaders, 'Set-Cookie')
                authToken = re.search('(SID=(.*?))\;', cookie).group(1)
                return authToken

            return authToken

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def GetVersion(self, url, token):
    # Get the qBittorrent server version number.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/app/version'.format(url)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)
            if response.status_code == 200:
                reqHeaders = response.headers
                #print(reqHeaders)
                return str(response.content, 'utf-8')
            else:
                return None

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def GetApiVersion(self, url, token):
    # Get the qBitorrent server API version.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/app/webapiVersion'.format(url)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)
            if response.status_code == 200:
                reqHeaders = response.headers
                #print(reqHeaders)
                return str(response.content, 'utf-8')
            else:
                return None

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def GetList(self, url, token, filter, category):
    # Get the list of shows and all meta data.
    # Returns a tuple (return value, error message, traceback string)
    #   "return value" is None if not available or error.
    #   "error message" is None if no error exists.
    #   "traceback string" is the formatted multi-line traceback string, if available.
        try:
            torrents = []

            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            if category:
                url = '{}/api/v2/torrents/info?filter={}&category={}&sort=num_seeds&reverse=true'.format(url, filter, category)
            else:
                url = '{}/api/v2/torrents/info?filter={}&sort=num_seeds&reverse=true'.format(url, filter)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                result = json.loads(response.content)
                #print(json.dumps(result, sort_keys=True, indent=4))
            else:
                return

            for each in result:
                torrent = {}
                torrent['added_on'] = SafeGet(each, 'added_on', defVal=0)
                torrent['category'] =  SafeGet(each, 'category', defVal='')
                torrent['completed'] =  SafeGet(each, 'completed', defVal=0)
                torrent['completion_on'] =  SafeGet(each, 'completion_on', defVal=0)
                torrent['dl_limit'] =  SafeGet(each, 'dl_limit', defVal=0)
                torrent['dlspeed'] =  SafeGet(each, 'dlspeed', defVal=0)
                torrent['downloaded'] =  SafeGet(each, 'downloaded', defVal=0)
                torrent['downloaded_session'] =  SafeGet(each, 'downloaded_session', defVal=0)
                torrent['eta'] =  SafeGet(each, 'eta', defVal=0)
                torrent['f_l_piece_prio'] =  SafeGet(each, 'f_l_piece_prio', defVal=False)
                torrent['force_start'] =  SafeGet(each, 'force_start', defVal=False)
                torrent['hash'] =  SafeGet(each, 'hash', defVal='')
                torrent['last_activity'] =  SafeGet(each, 'last_activity', defVal=0)
                torrent['name'] =  SafeGet(each, 'name', defVal='')
                torrent['num_complete'] =  SafeGet(each, 'num_complete', defVal=0)
                torrent['num_incomplete'] =  SafeGet(each, 'num_incomplete', defVal=0)
                torrent['num_leechs'] =  SafeGet(each, 'num_leechs', defVal=0)
                torrent['num_seeds'] =  SafeGet(each, 'num_seeds', defVal=0)
                torrent['priority'] =  SafeGet(each, 'priority', defVal=0)
                torrent['progress'] =  SafeGet(each, 'progress', defVal=0.0)
                torrent['ratio'] =  SafeGet(each, 'ratio', defVal=0.0)
                torrent['ratio_limit'] =  SafeGet(each, 'ratio_limit', defVal=0)
                torrent['remaining'] =  SafeGet(each, 'remaining', defVal=0)
                torrent['save_path'] =  SafeGet(each, 'save_path', defVal='')
                torrent['seen_complete'] =  SafeGet(each, 'seen_complete', defVal=0)
                torrent['seq_dl'] =  SafeGet(each, 'seq_dl', defVal=False)
                torrent['size'] =  SafeGet(each, 'size', defVal=0)
                torrent['state'] =  SafeGet(each, 'state', defVal='')
                torrent['super_seeding'] =  SafeGet(each, 'super_seeding', defVal=False)
                torrent['tags'] =  SafeGet(each, 'tags', defVal='')
                torrent['total_size'] =  SafeGet(each, 'total_size', defVal=0)
                torrent['tracker'] =  SafeGet(each, 'tracker', defVal=0)
                torrent['up_limit'] =  SafeGet(each, 'up_limit', defVal=0)
                torrent['uploaded'] =  SafeGet(each, 'uploaded', defVal=0)
                torrent['uploaded_session'] =  SafeGet(each, 'uploaded_session', defVal=0)
                torrent['upspeed'] =  SafeGet(each, 'upspeed', defVal=0)

                torrents.append(torrent)

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return

        finally:
            return torrents


    def Delete(self, url, token, hashes, deleteFiles=True):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to delete.
    # "hashes" can contain multiple hashes separated by |, to delete multiple torrents.
    # Or set to all, to delete all torrents.
    # Returns True if communication was successful, which is not an indication that the item existed and was deleted.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/delete?hashes={}&deleteFiles={}'.format(url, hashes, str(deleteFiles).lower())

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def Pause(self, url, token, hashes):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to delete.
    # "hashes" can contain multiple hashes separated by |, to delete multiple torrents.
    # Or set to all, to delete all torrents.
    # Returns True if communication was successful, which is not an indication that the item existed.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/pause?hashes={}'.format(url, hashes)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def Resume(self, url, token, hashes):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to delete.
    # "hashes" can contain multiple hashes separated by |, to delete multiple torrents.
    # Or set to all, to delete all torrents.
    # Returns True if communication was successful, which is not an indication that the item existed.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/resume?hashes={}'.format(url, hashes)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def Recheck(self, url, token, hashes):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to Set Force Start.
    # "hashes" can contain multiple hashes separated by |, to force start multiple torrents.
    # Or set to all, for all torrents.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/recheck?hashes={}'.format(url, hashes)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def ForceStart(self, url, token, hashes):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to Set Force Start.
    # "hashes" can contain multiple hashes separated by |, to force start multiple torrents.
    # Or set to all, for all torrents.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/setForceStart?hashes={}&value=true'.format(url, hashes)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def SetCategory(self, url, token, hashes, categoryName):
    # Requires knowing the torrent hashes. You can get them from the torrent list.
    # Set "hashes" to the torrents you want to Set Force Start.
    # "hashes" can contain multiple hashes separated by |, to force start multiple torrents.
    # Or set to all, for all torrents.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/setCategory?hashes={}&category={}'.format(url, hashes, categoryName)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def SearchStart(self, url, token, pattern, plugins='enabled', category='all'):
    # Submit a search using the "pattern" parameter.
    # The parameters "plugins" and "category" are optional.
    # Function will return a searchID value.
    # The search will continue to run on the qBit app.
    # Completion status and results must be queried separately.
    # Returns None or a JSON result.
        try:
            authToken = None

            data = urlencode({'pattern': pattern,
                              'plugins': plugins,
                              'category': category})

            headers = {'User-Agent': self.userAgent,
                       'Content-Type': 'application/x-www-form-urlencoded',
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token,
                       'Content-Length': str(len(data))}

            url = '{}/api/v2/search/start'.format(url)

            response = requests.post(url, data=data, headers=headers, proxies={}, verify=False, timeout=30)
            if response.status_code == 200:
                result = json.loads(response.content)
                return result
            elif response.status_code == 409:
                result = {"id": 'MaxLimit'}
                return result
            else:
                return None

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def SearchStop(self, url, token, searchId=''):
    # Instruct qBit app to stop this search via the search job ID.
    # Returns True or False on success.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/search/stop?id={}'.format(url, searchId)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False


    def SearchStatus(self, url, token, searchId=''):
    # Query the qBit app to see if a submitted search is still running or completed.
    # Returns None or a JSON result.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/search/status?id={}'.format(url, searchId)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                result = json.loads(response.content)
                return result
            else:
                return None

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def SearchResults(self, url, token, searchId='', limit=0):
    # Retrievey the results from the search query initiated with SearchStart.
    # A "limit" of 0 means no limit, otherwise set the max results you want to wait for.
    # Returns None or a JSON result.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/search/results?id={}'.format(url, searchId)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                result = json.loads(response.content)
                return result
            else:
                return None

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return None


    def AddTorrent(self, url, token, link, category=None, rename=None, savepath=None):
    # This method can add torrents from server local file or from URLs.
    # http://, https://, magnet: and bc://bt/ links are supported.
        try:
            headers = {'User-Agent': self.userAgent,
                       'Origin': GetOriginUrl(url),
                       'Referer': url,
                       'Cookie': token}

            url = '{}/api/v2/torrents/add?urls={}'.format(url, link)

            if category:
                url = '{}&category={}'.format(url, category)

            if rename:
                url = '{}&rename={}'.format(url, rename)

            if savepath:
                url = '{}&savepath={}&root_folder=true'.format(url, savepath)

            response = requests.get(url, headers=headers, proxies={}, verify=False, timeout=30)

            if response.status_code == 200:
                return True
            else:
                return False

        except Exception as e:
            trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
            print(trbk)
            try: log.debug(trbk)
            except Exception as e: print(e)
            return False

