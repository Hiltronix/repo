# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon
import sys
import base64
import requests


# Show error pop up then exit plugin.
def messageWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)


# Show error pop up then exit plugin.
def errorWindow(header, message):
    dialog = xbmcgui.Dialog()
    dialog.ok(header, message)
    sys.exit()


def createURL(ip, port, use_ssl, custom_url):
    if custom_url != "":
        return custom_url
    if str(ip) == "" or str(port) == "":
        errorWindow("Error", "Must configure IP and port settings before use.")
    else:
        if use_ssl == "true":
            return "https://"+str(ip) + ':' + str(port)
        else:
            return "http://"+str(ip) + ':' + str(port)


def VersionLogger(pluginVersion, pluginID):
# NOTE FROM HILTRONIX!!! If you are forking this addon for your own use, please delete this function, it's for my use only.
# It's does nothing for you if you don't understand how to change this function for your own version tracking use.  Thanks.
    try:
        headers = {'user-agent': 'version updates v.1.1.0', 'referer':'{}.{}'.format(pluginVersion, pluginID)}
        response = requests.get(base64.b64decode(b'aHR0cHM6Ly9nby5oaWx0cm9uaXguY29tL3NWbkw='), headers=headers, verify=False, timeout=3.0)
        data = response.content
    except:
        pass


# Set constants.
pluginID = 'plugin.program.qbittorrent'
my_addon = xbmcaddon.Addon(pluginID)
addon_path = my_addon.getAddonInfo('path')

pluginName = my_addon.getAddonInfo('name')
pluginVersion = my_addon.getAddonInfo('version')
pluginAuthor = my_addon.getAddonInfo('author')
pluginSummary = my_addon.getAddonInfo('summary')
pluginDesc = my_addon.getAddonInfo('description')

__ip__ = my_addon.getSetting('IP')
__port__= my_addon.getSetting('Port')
__ssl_bool__= my_addon.getSetting('Use SSL')
__username__ = my_addon.getSetting('Username')
__password__= my_addon.getSetting('Password')
__url_bool__= my_addon.getSetting('Use Custom URL')
if __url_bool__ == "true":
    __custom_url__= my_addon.getSetting('Custom URL')
else:
    __custom_url__= ""


# Create the URL used to access webserver.
__url__ = createURL(__ip__, __port__, __ssl_bool__, __custom_url__)


# Initialize default settings.
search_categories = ['all', 'movies', 'tv', 'music', 'games', 'anime', 'software', 'pictures', 'books']

torrent_filter = ['all', 'downloading', 'seeding', 'completed', 'resumed', 'paused', 'active', 'inactive', 'errored']

torrent_filter_preselect = my_addon.getSetting('torrent_filter_preselect')
if torrent_filter_preselect == '':
    my_addon.setSetting('torrent_filter_preselect', '0')

search_cat_preselect = my_addon.getSetting('search_cat_preselect')
if search_cat_preselect == '':
    my_addon.setSetting('search_cat_preselect', '0')

# If NumTorrentList is blank, then set it to 0.
if my_addon.getSetting('NumTorrentList') == "":
    my_addon.setSetting('NumTorrentList', '0')

# Check if version has changed, if so activate logger.
# NOTE FROM HILTRONIX!!! If you are forking this addon for your own use, please delete the next 6 code lines, it's for my use only.
# It's does nothing for you if you don't understand how to change this functionality for your own version tracking use.  Thanks.
current_version = my_addon.getSetting('current_version')
if current_version == '':
    my_addon.setSetting('current_version', '0')
if current_version != pluginVersion:
    VersionLogger(pluginVersion, pluginID)
    my_addon.setSetting('current_version', pluginVersion)

