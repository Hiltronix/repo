# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcplugin
import re
import sys
import time
import traceback
from urllib.parse import urlencode, urlparse, quote_plus, unquote_plus
import resources.lib.qBitApi as qBitApi
import resources.lib.common as common
import resources.lib.settings as settings


def LoginToQBit():
    try:
        qBit = qBitApi.qBit()

        qBitAuthToken = qBit.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
        qBitUrl = settings.__url__
        if not qBitAuthToken:
            msg = 'ERROR! Getting qBit login auth tokin.'
            common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
            xbmc.log(msg, xbmc.LOGERROR)
            return None, None

        return qBitAuthToken, qBitUrl

    except Exception as e:
        trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
        xbmc.log(trbk, xbmc.LOGERROR)


def QBitSearch(searchTxt):
# Performs a search using qBittorrent, and returns results in a list.
    try:
        qBit = qBitApi.qBit()

        qBitAuthToken, qBitUrl = LoginToQBit()
        if not qBitAuthToken or not qBitUrl:
            msg = 'ERROR! Getting qBit login auth tokin.'
            common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
            xbmc.log(msg, xbmc.LOGERROR)
            return

        # Try to read the version number, as a way to check if the qBit auth token is still good.
        # If unable to retrieve the version number, re-login to qBit to get a new token.
        appVer = qBit.GetVersion(qBitUrl, token=qBitAuthToken)
        if not appVer:
            qBitAuthToken, qBitUrl = LoginToQBit()
            if not qBitAuthToken or not qBitUrl:
                msg = 'ERROR! Getting qBit login auth tokin.'
                common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
                xbmc.log(msg, xbmc.LOGERROR)
                return

        common.CreateNotification(header='qBittorrent Search', message=searchTxt, icon=xbmcgui.NOTIFICATION_INFO, time=10000, sound=False)

        result = qBit.SearchStart(qBitUrl, token=qBitAuthToken, pattern=searchTxt)
        if result:
            searchId = qBitApi.SafeGet(result, 'id')
            if searchId == 'MaxLimit':
                msg = 'User has reached the max limit of qBit running searches! Can\'t start search: "{}"'.format(searchTxt)
                common.CreateNotification(header='Warning!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
                xbmc.log(msg, xbmc.LOGERROR)
                return
        else:
            msg = 'ERROR! Can\'t start qBit search "{}", search ID not issued.'.format(searchTxt)
            common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
            xbmc.log(msg, xbmc.LOGERROR)
            return

        # Delay so the search can accumulate some matches.
        maxSecs = 30
        status = ''
        startTimer = time.time()
        delay = 0
        while (delay < maxSecs) and (status != 'Stopped'):
            time.sleep(1)
            result = qBit.SearchStatus(qBitUrl, token=qBitAuthToken, searchId=searchId)
            if result:
                status = qBitApi.SafeGet(result[0], 'status')
                total = qBitApi.SafeGet(result[0], 'total')
            else:
                log.debug('ERROR! Getting qBit search status.')
                return
            delay = time.time() - startTimer

        # Stop this search.
        result = qBit.SearchStop(qBitUrl, token=qBitAuthToken, searchId=searchId)
        if not result:
            msg = 'ERROR! Unable to stop qBit search job ID: {}.'.format(searchId)
            common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
            xbmc.log(msg, xbmc.LOGERROR)

        # Retrieve the search results.
        result = qBit.SearchResults(qBitUrl, token=qBitAuthToken, searchId=searchId)
        if result:
            results = qBitApi.SafeGet(result, 'results')
            status = qBitApi.SafeGet(result, 'status')
            total = qBitApi.SafeGet(result, 'total')
        else:
            msg = 'ERROR! Getting qBit search results.'
            common.CreateNotification(header='Error!', message=msg, icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
            xbmc.log(msg, xbmc.LOGERROR)
            return

        # Sort search results list of dict descending by seeders.
        results = sorted(results, key=lambda k: k['nbSeeders'], reverse=True)

        common.CreateNotification(header='qBittorrent Query', message='Search Complete!', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=True)

        return results

    except Exception as e:
        trbk = 'Exception! {}: {}\n{}'.format(e.__class__.__name__, e, traceback.format_exc())
        xbmc.log(trbk, xbmc.LOGERROR)


def GetListInfo(keywords='', category='all'):
    # keywords e.g: 'westworld s01e07'
    # category = 'tv'
    # CATEGORIES = {'all', 'movies', 'tv', 'music', 'games', 'anime', 'software', 'pictures', 'books'}

    torrent_names = []

    keywords = common.SanitizeSearchText(keywords)

    results = QBitSearch(searchTxt=keywords)
    if results:
        for result in results:
            name = common.SafeGet(result, 'fileName', defVal = '')
            size = common.SafeGet(result, 'fileSize', defVal = 0)
            size = common.ConvertBytes(size, 1)
            seeders = common.SafeGet(result, 'nbSeeders', defVal = 0)
            leechers = common.SafeGet(result, 'nbLeechers', defVal = 0)
            link = common.SafeGet(result, 'fileUrl', defVal = '')
            searchEngine = common.SafeGet(result, 'siteUrl', defVal = '')

            title = '[COLOR gold]{}[/COLOR]  [COLOR cyan]Size:[/COLOR]{}  [COLOR cyan]Seeders:[/COLOR]{}  [COLOR cyan]Leechers:[/COLOR]{}  [COLOR purple]{}[/COLOR]  {}'.format(name, size, seeders, leechers, link[0:20]+'...', searchEngine)

            torrent_names.append([title, name, size, seeders, leechers, link, searchEngine])

    return torrent_names


# Parse through shows and add dirs for each.
def menu(handle=0, keywords='', category=''):

    list_info = GetListInfo(keywords, category)
    total_items = len(list_info)

    for title, name, size, seeders, leechers, link, searchEngine in list_info:

        context_menu_items = []
        context_menu_items.append(('Add Torrent', 'RunPlugin(plugin://' + str(settings.pluginID) + '?mode=4&hash=' + quote_plus(link) + '&action=' + quote_plus("add") + '&category=' + quote_plus(category) + ')'))
        context_menu_items.append(('Refresh List', 'RunPlugin(plugin://' + str(settings.pluginID) + '?mode=88)'))
        context_menu_items.append(('Go Back', 'Action("back")'))

        thumbnailPath = settings.addon_path + '/search.png'
        fanartPath = settings.addon_path + '/fanart.jpg'
        bannerPath = ''

        addDirectory(handle, title, name, size, seeders, leechers, link, searchEngine, category, thumbnailPath, fanartPath, bannerPath, total_items, context_menu_items)

    xbmcplugin.addSortMethod(handle=int(handle), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(handle=int(handle), content='tvshows')
    xbmcplugin.endOfDirectory(int(handle))
    common.CreateNotification(header=str(total_items)+ ' Items', message=' in torrent list', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)


# Add directory item.
def addDirectory(handle, title, name, size, seeders, leechers, link, searchEngine, category, thumbnailPath, fanartPath, bannerPath, total_items, context_menu_items):
    return_url = 'plugin://{}/?mode={}'.format(settings.pluginID, 99)   # mode=99 - Open context menu.
    list_item = xbmcgui.ListItem(name)
    list_item.setArt({'icon': thumbnailPath, 'thumb': thumbnailPath, 'poster': thumbnailPath, 'fanart': fanartPath, 'banner': bannerPath, 'clearart': '', 'clearlogo': '', 'landscape': ''})
    list_item.setProperty('LibraryHasMovie', '0')  # Removes the "Play" button from the video info screen, and replaces it with "Browse".
    meta = {}
    meta['title'] = title
    meta['plot'] = '[COLOR gold]{}[/COLOR][CR][COLOR cyan]Size:[/COLOR] {}[CR][COLOR cyan]Seeders:[/COLOR] {}  [COLOR cyan]Leechers:[/COLOR] {}[CR][COLOR cyan]Search Category:[/COLOR] {}[CR]{}'.format(title[:30]+'...', size, seeders, leechers, category, searchEngine)
    list_item.setInfo(type="Video", infoLabels=meta)
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(handle), url=return_url, listitem=list_item, isFolder=False, totalItems=total_items)


