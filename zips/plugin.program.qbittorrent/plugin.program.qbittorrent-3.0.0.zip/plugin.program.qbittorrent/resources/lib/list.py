# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcplugin
import sys
import traceback
from urllib.parse import urlencode, urlparse, quote_plus, unquote_plus
import resources.lib.settings as settings
import resources.lib.common as common
import resources.lib.qBitApi as qBitApi


qBit = qBitApi.qBit()


def GetListInfo(filter='all'):

    torrent_names = []

    token = qBit.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)

    torrents = qBit.GetList(url=settings.__url__, token=token, filter=filter, category='')

    for torrent in sorted(torrents, key=lambda k: k['name'], reverse=False):
        name = torrent.get('name', '')
        hash = torrent.get('hash', '')
        state = torrent.get('state', '')
        progress = torrent.get('progress', '')
        size = torrent.get('size', '')
        dlspeed = torrent.get('dlspeed', '')
        upspeed = torrent.get('upspeed', '')
        seeds = torrent.get('num_seeds', '')
        leechers = torrent.get('num_leechs', '')
        eta = torrent.get('eta', '')
        category = torrent.get('category', '')

        try:
            #progress = "{:.0%}".format(float(progress))   # <-- This doesn't work on the Android version of Kodi, causes exception, but not on Windows.
            #progress = str(int(progress * 100)) + '%'
            progress = '{}%'.format(int(round(float(progress) * 100.0, 0)))
        except:
            progress = '?%'
        size = common.ConvertBytes(size, 0)
        dlspeed = common.ConvertBytes(dlspeed, 0) + '/s'
        upspeed = common.ConvertBytes(upspeed, 0) + '/s'
        eta = common.ConvertSeconds(eta)

        torrent_names.append([name, '[COLOR gold]'+name+'[/COLOR]  [COLOR cyan]'+state+'[/COLOR]  Done:'+progress+'  '+size+'  Dn:'+dlspeed+'  Up:'+upspeed+'  '+eta, token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, category])

    return torrent_names


# Parse through shows and add dirs for each.
def menu(handle=0, filter='all'):
    list_info = GetListInfo(filter)
    total_items = len(list_info)

    if total_items == 0 and filter != 'all':
        settings.my_addon.setSetting('torrent_filter_preselect', '0')   # Revert to default "all" filter.
        settings.messageWindow('Filter [{}]'.format(filter), 'No items to display for this filter selection.[CR]Reverting to "all".')
        xbmc.executebuiltin('Container.Refresh()')

    for name, title, token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, category in list_info:

        context_menu_items = []
        context_menu_items.append(('Filter', 'RunPlugin(plugin://'+str(settings.pluginID)+'?mode=5)'))
        context_menu_items.append(('Set Label Category', 'RunPlugin(plugin://'+str(settings.pluginID)+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&category='+quote_plus(category)+'&action='+quote_plus("setCategory")+')'))
        context_menu_items.append(('Delete Torrent', 'RunPlugin(plugin://'+str(settings.pluginID)+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("deleteTor")+')'))
        context_menu_items.append(('Delete Tor+File', 'RunPlugin(plugin://'+str(settings.pluginID)+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("deleteFile")+')'))
        context_menu_items.append(('Pause', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("pause")+')'))
        context_menu_items.append(('Resume', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("resume")+')'))
        context_menu_items.append(('Pause All', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("pauseAll")+')'))
        context_menu_items.append(('Resume All', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("resumeAll")+')'))
        context_menu_items.append(('Force Start', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("setForceStart")+')'))
        context_menu_items.append(('Force Recheck', 'RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+quote_plus(token)+'&action='+quote_plus("recheck")+')'))
        context_menu_items.append(('Refresh List', 'RunPlugin(plugin://'+str(settings.pluginID)+'?mode=88)'))
        context_menu_items.append(('Go Back', 'Action("back")'))

        thumbnailPath = settings.addon_path + '/manage.png'
        fanartPath = settings.addon_path + '/fanart.jpg'

        addDirectory(handle, name, title, token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, filter, category, thumbnailPath, fanartPath, total_items, context_menu_items)

    xbmcplugin.addSortMethod(handle=handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    xbmcplugin.setContent(handle=handle, content='tvshows')
    xbmcplugin.endOfDirectory(handle=handle)
    # User timer to refresh list to see updated values.
    xbmc.executebuiltin("AlarmClock({0}, Container.Refresh(), '00:00:10', true, true)".format(settings.pluginID))

    # Only display notification of number of torrents in list when it changes.
    if int(settings.my_addon.getSetting('NumTorrentList')) != total_items:
        common.CreateNotification(header=str(total_items)+' Items', message='in torrent list', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
    settings.my_addon.setSetting('NumTorrentList', str(total_items))


# Add directory item.
def addDirectory(handle, name, title, token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, filter, category, thumbnailPath, fanartPath, total_items, context_menu_items):
    return_url = 'plugin://{}/?hash={}&mode={}&name{}'.format(settings.pluginID, quote_plus(str(hash)), 99, quote_plus(name.encode("utf-8")))   # mode=99 - Open context menu.
    list_item = xbmcgui.ListItem(title)
    list_item.setArt({'thumb': thumbnailPath, 'fanart': fanartPath})
    meta = {}
    meta['title'] = title
    meta['plot'] = '[COLOR gold]{}[/COLOR][CR][COLOR cyan]Status:[/COLOR] {}[CR][COLOR cyan]Size:[/COLOR] {}[CR][COLOR cyan]Done:[/COLOR] {}  [COLOR cyan]ETA:[/COLOR] {}[CR][COLOR cyan]Down:[/COLOR] {}  [COLOR cyan]Up:[/COLOR]{}[CR][COLOR cyan]Seeders:[/COLOR] {}  [COLOR cyan]Leechers:[/COLOR] {}[CR][COLOR cyan]Filter:[/COLOR] {}[CR][COLOR cyan]Label Category:[/COLOR] {}'.format(name[:30]+'...', state, size, progress, eta, dlspeed, upspeed, seeds, leechers, filter, category)
    list_item.setInfo(type="Video", infoLabels=meta)
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(handle), url=return_url, listitem=list_item, isFolder=False, totalItems=total_items)

