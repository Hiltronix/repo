# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import os
import sys
import time
import traceback
from urllib.parse import urlencode, urlparse, quote_plus, unquote_plus
import resources.lib.list as list
import resources.lib.common as common
import resources.lib.settings as settings
import resources.lib.searchlist as searchlist
import resources.lib.qBitApi as qBitApi


qBit = qBitApi.qBit()


# Add the main directory folders.
def mainMenu():
    addDirectory('Search', 1, True, settings.addon_path + '/search.png')
    addDirectory('Torrent List', 2, True, settings.addon_path + '/manage.png')
    addDirectory('Add Torrent from URL', 3, False, settings.addon_path + '/add.png')
    addDirectory('Settings', 77, False, settings.addon_path + '/settings.png')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Add directory item.
def addDirectory(menu_item_name, mode, folder, iconPath):

    thumbnailPath = settings.addon_path + '/manage.png'
    fanartPath = settings.addon_path + '/fanart.jpg'

    return_url = 'plugin://{}/?mode={}&name={}'.format(settings.pluginID, mode, quote_plus(menu_item_name))

    list_item = xbmcgui.ListItem(menu_item_name)
    list_item.setArt({'icon': iconPath, 'thumb': thumbnailPath, 'fanart': fanartPath})

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=folder, totalItems=4)


# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
    param=[]
    try:
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
              params=sys.argv[2]
              cleanedparams=params.replace('?','')
              if (params[len(params)-1]=='/'):
                      params=params[0:len(params)-2]
              pairsofparams=cleanedparams.split('&')
              param={}
              for i in range(len(pairsofparams)):
                      splitparams={}
                      splitparams=pairsofparams[i].split('=')
                      if (len(splitparams))==2:
                              param[splitparams[0]]=splitparams[1]
      return param
    except:
      return param


def showKeyboardDialog(header='Text Entry', text=None):
    keyboard = xbmc.Keyboard(text, header, False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        text = keyboard.getText()
    else:
        text = ''
    return text


def AddUrl(url):
    url = showKeyboardDialog('Add Torrent from URL', url)
    if (url == ''):
        exit()
    return url


def TorrentActionCmd(action, hash, category):

    token = qBit.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)

    if action == 'add':
        result = qBit.AddTorrent(url=settings.__url__, token=token, link=hash, category=category, rename=None, savepath=None)

    if action == 'setCategory':
        result = qBit.SetCategory(url=settings.__url__, token=token, hashes=hash, categoryName=category)

    if action == 'deleteTor':
        result = qBit.Delete(url=settings.__url__, token=token, hashes=hash, deleteFiles=False)

    if action == 'deleteFile':
        result = qBit.Delete(url=settings.__url__, token=token, hashes=hash, deleteFiles=True)

    if action == 'pause':
        result = qBit.Pause(url=settings.__url__, token=token, hashes=hash)

    if action == 'resume':
        result = qBit.Resume(url=settings.__url__, token=token, hashes=hash)

    if action == 'pauseAll':
        result = qBit.Pause(url=settings.__url__, token=token, hashes='all')

    if action == 'resumeAll':
        result = qBit.Resume(url=settings.__url__, token=token, hashes='all')

    if action == 'setForceStart':
        result = qBit.ForceStart(url=settings.__url__, token=token, hashes=hash)

    if action == 'recheck':
        result = qBit.Recheck(url=settings.__url__, token=token, hashes=hash)

    if not result:
        common.CreateNotification(header='Error!', message='Operation was not successful.', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=True)

    # Don't refresh gui list for the actions in this list.
    if action not in ['add']:
        xbmc.executebuiltin('Container.Refresh()')


# Initialize URL parameters.
url = None
keywords = None
name = None
mode = None
token = None
action = None
hash = None
category = None
params = getParameters()

# Parse internal URL.
try:
    url = unquote_plus(params["url"])
    print(url)
    mode = 3
except:
    pass

try:
    name = unquote_plus(params["name"])
    print(name)
except:
    pass

try:
    keywords = unquote_plus(params["keywords"])
    print(keywords)
except:
    pass

try:
    number = unquote_plus(params["number"])
    print(number)
except:
    pass

try:
    mode = int(params["mode"])
    print(mode)
except:
    pass

try:
    token = unquote_plus(params["token"])
    print(token)
except:
    pass

try:
    action = unquote_plus(params["action"])
    print(action)
except:
    pass

try:
    hash = unquote_plus(params["hash"])
    print(hash)
except:
    pass

try:
    category = unquote_plus(params["category"])
    print(category)
except:
    pass

# Open directories based on selection.
if mode == None:
    mainMenu()

# Search Torrents.
elif mode == 1:

    if not keywords:
        keywords = settings.my_addon.getSetting('keywords')
    keywords = showKeyboardDialog('Search Keywords', keywords)
    if (keywords == ''):
        exit()
    settings.my_addon.setSetting('keywords', keywords)

    search_cat_preselect = int(settings.my_addon.getSetting('search_cat_preselect'))
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Search Category", settings.search_categories, preselect=search_cat_preselect)
    if ret == -1:
        exit()
    settings.my_addon.setSetting('search_cat_preselect', str(ret))

    searchlist.menu(handle=int(sys.argv[1]), keywords=keywords, category=settings.search_categories[ret])

# Torrent list.
elif mode == 2:
    torrent_filter_preselect = int(settings.my_addon.getSetting('torrent_filter_preselect'))
    list.menu(handle=int(sys.argv[1]), filter=settings.torrent_filter[torrent_filter_preselect])

# Add Torrent download URL manually.
elif mode == 3:
    url = AddUrl(url)
    text = showKeyboardDialog('Enter Label Category Name', category)
    if (text == ''):
        exit()
    category = text
    TorrentActionCmd('add', url, category)

# Torrent action command.
elif mode == 4:
    if action in ['add', 'setCategory']:
        text = showKeyboardDialog('Enter Label Category Name', category)
        if (text == ''):
            exit()
        category = text
    TorrentActionCmd(action, hash, category)
    if action == 'add':
        xbmc.executebuiltin('Action("back")')
    else:
        time.sleep(1)
        xbmc.executebuiltin('Container.Refresh()')

# Torrent list filter.
elif mode == 5:
    torrent_filter_preselect = int(settings.my_addon.getSetting('torrent_filter_preselect'))
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Torrent Filter", settings.torrent_filter, preselect=torrent_filter_preselect)
    if ret == -1:
        exit()
    settings.my_addon.setSetting('torrent_filter_preselect', str(ret))
    xbmc.executebuiltin('Container.Refresh()')

# Settings menu.
elif mode == 77:
    ret = 0
    while ret >= 0:
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Settings", ["Add-on Settings", "Add Add-on to Favouties", "Show Server Version", "Change Log", "About"])

        if ret == 0:    # Open Add-on settings.
            xbmcaddon.Addon(settings.pluginID).openSettings()
            exit()

        if ret == 1:    # Add to favourites.
            try:
                xml_open = '<favourites>\n'
                xml_fav = '    <favourite name="{0}" thumb="special://home/addons/{1}/icon.png">ActivateWindow(10025,&quot;plugin://{1}/&quot;,return)</favourite>\n'.format(settings.pluginName, settings.pluginID)
                xml_close = '</favourites>\n'
                xbmc.executebuiltin("ActivateWindow(busydialog)")
                filename = xbmc.translatePath('special://home/userdata/favourites.xml')
                if os.path.isfile(filename):
                    with open(filename, 'r') as f:
                        data = f.read()
                    # Check is fav already exists.  If not, add it to end of file.
                    find_str = 'name="{}"'.format(settings.pluginName)
                    if find_str not in data:
                        data = data.replace(xml_close, xml_fav + xml_close)
                else:
                    data = xml_open + xml_fav + xml_close
                # Save favourites file.
                f = open(filename, 'w')
                f.write(data)
                f.close()
                common.messageWindow('Add to Favourites', 'Done.')
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialog)")

        if ret == 2:    # qBitTorrent Version.
            token = qBit.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
            ver = qBit.GetVersion(url=settings.__url__, token=token)
            api = qBit.GetApiVersion(url=settings.__url__, token=token)
            common.messageWindow('qBittorrent', 'Program Version [COLOR cyan]{}[/COLOR]\nAPI Version [COLOR cyan]{}[/COLOR]'.format(str(ver), str(api)))

        if ret == 3:    # Change log.
            try:
                xbmc.executebuiltin("ActivateWindow(busydialog)")
                filename = os.path.join(settings.addon_path, 'changelog.txt')
                if os.path.isfile(filename):
                    with open(filename, 'r') as f:
                        data = f.read()
                else:
                    data = 'Change log not available.'
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
            w = common.TextViewer_Dialog('DialogTextViewer.xml', settings.addon_path, header='Change Log', text=data)
            w.doModal()

        if ret == 4:    # About.
            try:
                xbmc.executebuiltin("ActivateWindow(busydialog)")
                filename = os.path.join(settings.addon_path, 'about.txt')
                if os.path.isfile(filename):
                    with open(filename, 'r') as f:
                        data = f.read()
                else:
                    data = 'About file not available.'
                data = '[COLOR gold]{} v.{}[CR]by {}[/COLOR][CR][COLOR cyan]{}[CR]{}[/COLOR][CR][CR]'.format(settings.pluginName, settings.pluginVersion, settings.pluginAuthor, settings.pluginSummary, settings.pluginDesc) + data
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
            w = common.TextViewer_Dialog('DialogTextViewer.xml', settings.addon_path, header='About', text=data)
            w.doModal()

# Refresh list.
elif mode == 88:
    xbmc.executebuiltin('Container.Refresh()')

# Open context menu on normal right click selection.
elif mode == 99:
    xbmc.executebuiltin('Action("ContextMenu")')

