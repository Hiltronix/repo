import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import os
import sys
import urllib
import resources.lib.list as list
import resources.lib.common as common
import resources.lib.settings as settings
import resources.lib.utility as utility
import resources.lib.searchlist as searchlist
import resources.lib.NovaSearch as NovaSearch

Utility = utility.Util()


# Add the main directory folders.
def mainMenu():
    addDirectory('Search', 1, True, settings.addon_path + '/search.png')
    addDirectory('Torrent List', 2, True, settings.addon_path + '/manage.png')
    addDirectory('Add Torrent from URL', 3, False, settings.addon_path + '/add.png')
    addDirectory('Settings', 77, False, settings.addon_path + '/settings.png')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Add directory item.
def addDirectory(menu_item_name, mode, folder, icon):
    return_url = '{}?url={}&mode={}&name={}'.format(sys.argv[0], urllib.quote_plus(""), mode, urllib.quote_plus(menu_item_name))
    list_item = xbmcgui.ListItem(menu_item_name, iconImage=icon, thumbnailImage=icon)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=folder, totalItems=4)


# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
    param=[]
    try:
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
              params=sys.argv[2]
              cleanedparams=params.replace('?','')
              if (params[len(params)-1]=='/'):
                      params=params[0:len(params)-2]
              pairsofparams=cleanedparams.split('&')
              param={}
              for i in range(len(pairsofparams)):
                      splitparams={}
                      splitparams=pairsofparams[i].split('=')
                      if (len(splitparams))==2:
                              param[splitparams[0]]=splitparams[1]
      return param
    except:
      return param
          
          
def showKeyboardDialog(header='Text Entry', text=None):
    keyboard = xbmc.Keyboard(text, header, False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        text = keyboard.getText()
    else:
        text = ''
    return text  

  
def AddUrl(url):
    url = showKeyboardDialog('Add Torrent from URL', url)
    if (url == ''):
        exit()
    return url


def TorrentActionCmd(hash, action, category):
    auth_token = Utility.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    Utility.TorrentAction(url=settings.__url__, token=auth_token, hash=hash, action=action, category=category)
    if action not in ['/command/download']: # Don't refresh gui list for the actions in this list.
        xbmc.executebuiltin('Container.Refresh')
        
    
# Initialize URL parameters.
url = None
keywords = None
name = None
mode = None
token = None
action = None
hash = None
category = None
params = getParameters()

# Parse internal URL.
try:
    url = urllib.unquote_plus(params["url"])
    print url
    mode = 3
except:
    pass

try:
    name = urllib.unquote_plus(params["name"])
    print name
except:
    pass

try:
    keywords = urllib.unquote_plus(params["keywords"])
    print keywords
except:
    pass

try:
    number = urllib.unquote_plus(params["number"])
    print number
except:
    pass

try:
    mode = int(params["mode"])
    print mode
except:
    pass
    
try:
    token = urllib.unquote_plus(params["token"])
    print token
except:
    pass

try:
    action = urllib.unquote_plus(params["action"])
    print action
except:
    pass

try:
    hash = urllib.unquote_plus(params["hash"])
    print hash
except:
    pass

try:
    category = urllib.unquote_plus(params["category"])
    print category
except:
    pass

# Open directories based on selection.
if mode == None:
    mainMenu()
       
# Search TV Show Torrents.
elif mode == 1:
    if not keywords:
        keywords = settings.my_addon.getSetting('keywords')
    keywords = showKeyboardDialog('Search Keywords', keywords)
    if (keywords == ''):
        exit()
    settings.my_addon.setSetting('keywords', keywords)
    search_engines = settings.my_addon.getSetting('search_engines')     # Multiple search engine names as a comma separated string, not as a list.
    search_cat_preselect = int(settings.my_addon.getSetting('search_cat_preselect'))
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Search Category", settings.search_categories, preselect=search_cat_preselect)
    if ret == -1:
        exit()
    settings.my_addon.setSetting('search_cat_preselect', str(ret))
    searchlist.menu(handle=sys.argv[1], keywords=keywords, engine=search_engines, category=settings.search_categories[ret])

# Torrent list.
elif mode == 2:
    torrent_filter_preselect = int(settings.my_addon.getSetting('torrent_filter_preselect'))
    list.menu(handle=sys.argv[1], filter=settings.torrent_filter[torrent_filter_preselect])

# Add Torrent download URL manually.
elif mode == 3:
    url = AddUrl(url)
    category = ''  # ???
    TorrentActionCmd(url, '/command/download', category)

# Torrent action command.
elif mode == 4:
    if action in ['/command/download','/command/setCategory']:
        text = showKeyboardDialog('Enter Label Category Name', category)
        if (text == ''):
            exit()
        category = text
    TorrentActionCmd(hash, action, category)
    # Don't place a Container.Refresh here!

# Torrent list filter.
elif mode == 5:
    torrent_filter_preselect = int(settings.my_addon.getSetting('torrent_filter_preselect'))
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Torrent Filter", settings.torrent_filter, preselect=torrent_filter_preselect)
    if ret == -1:
        exit()
    settings.my_addon.setSetting('torrent_filter_preselect', str(ret))
    xbmc.executebuiltin('Container.Refresh')

# Settings menu.
elif mode == 77:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Settings", ["Search Engine(s)", "Change Log", "App Settings", "Add App to Favouties", "Show Server Version", "About"])

    if ret == 0:#    # Set default search engine.
        engine_list = NovaSearch.SupportedEngines()
        search_engines = settings.my_addon.getSetting('search_engines').split(',')
        try:
            sel_list = [engine_list.index(i) for i in search_engines]
        except Exception:
            sel_list = [0]
        dialog = xbmcgui.Dialog()
        eng_list = dialog.multiselect("Search Engine(s) to Use", engine_list, preselect=sel_list)
        if (eng_list == None):
            exit()
        search_engines = [engine_list[i] for i in eng_list]
        settings.my_addon.setSetting('search_engines', ','.join(search_engines))

    if ret == 1:    # Change log.
        try:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            filename = os.path.join(settings.addon_path, 'changelog.txt')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = f.read()
            else:
                data = 'Change log not available.'
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        w = common.TextViewer_Dialog('DialogTextViewer.xml', settings.addon_path, header='Change Log', text=data)
        w.doModal()

    if ret == 2:    # Open app settings.
        xbmc.executebuiltin('XBMC.Addon.OpenSettings({0})'.format(settings.pluginID))
        exit()

    if ret == 3:    # Add to favourites.
        try:
            xml_open = '<favourites>\n'
            xml_fav = '    <favourite name="{0}" thumb="special://home/addons/{1}/icon.png">ActivateWindow(10025,&quot;plugin://{1}/&quot;,return)</favourite>\n'.format(settings.pluginName, settings.pluginID)
            xml_close = '</favourites>\n'
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            filename = xbmc.translatePath('special://home/userdata/favourites.xml')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = f.read()
                # Check is fav already exists.  If not, add it to end of file.
                find_str = 'name="{}"'.format(settings.pluginName)
                if find_str not in data:
                    data = data.replace(xml_close, xml_fav + xml_close)
            else:
                data = xml_open + xml_fav + xml_close
            # Save favourites file.
            f = open(filename, 'w')
            f.write(data)
            f.close()
            common.messageWindow('Add to Favourites', 'Done.')
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")

    if ret == 4:    # qBitTorrent Version.
        ver = Utility.GetVersion()
        api = Utility.GetApiVersion()
        common.messageWindow('qBittorrent', 'Program Version {}\nAPI Version {}'.format(str(ver), str(api)))

    if ret == 5:    # About.
        try:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            filename = os.path.join(settings.addon_path, 'about.txt')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = f.read()
            else:
                data = 'About file not available.'
            data = '[COLOR gold]{} v.{}[CR]by {}[/COLOR][CR][COLOR cyan]{}[CR]{}[/COLOR][CR][CR]'.format(settings.pluginName, settings.pluginVersion, settings.pluginAuthor, settings.pluginSummary, settings.pluginDesc) + data
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        w = common.TextViewer_Dialog('DialogTextViewer.xml', settings.addon_path, header='About', text=data)
        w.doModal()
        
# Refresh list.
elif mode == 88:
    xbmc.executebuiltin('Container.Refresh')

# Open context menu on normal right click selection.
elif mode == 99:
    xbmc.executebuiltin('Action(ContextMenu)')

