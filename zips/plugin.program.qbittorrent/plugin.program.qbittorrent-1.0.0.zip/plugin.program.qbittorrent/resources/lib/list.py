import sys
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import common
import resources.lib.settings as settings
import resources.lib.utility as utility


Utility = utility.Util()


def GetListInfo():
    auth_token = Utility.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    torrents = Utility.GetList(auth_token)
    torrent_names = []
    for torrent in sorted(torrents, key=lambda k: k['name'], reverse=False):
        name = torrent['name']
        hash = torrent['hash']
        state = torrent['state']
        progress = torrent['progress']
        size = torrent['size']
        dlspeed = torrent['dlspeed']
        upspeed = torrent['upspeed']
        eta = torrent['eta']

        progress = str("{:.0%}".format(progress))
        size = utility.convertBytes(size, 0)
        dlspeed = utility.convertBytes(dlspeed, 0) + '/s'
        upspeed = utility.convertBytes(upspeed, 0) + '/s'
        eta = utility.convertSeconds(eta)

        torrent_names.append([name, '[COLOR gold]'+name+'[/COLOR]  [COLOR cyan]'+state+'[/COLOR]  Done:'+progress+'  '+size+'  Dn:'+dlspeed+'  Up:'+upspeed+'  '+eta, auth_token, hash, state, progress, size, dlspeed, upspeed, eta])
      
    return torrent_names


# Parse through shows and add dirs for each.
def menu():
    list_info = GetListInfo()
    list_total = len(list_info)
    for name, title, auth_token, hash, state, progress, size, dlspeed, upspeed, eta in list_info:

        context_menu_items = []
        context_menu_items.append(('Delete', 'XBMC.RunPlugin(plugin://'+str(settings.__addonID__)+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/delete")+')'))
        context_menu_items.append(('Delete + Data', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/deletePerm")+')'))
        context_menu_items.append(('Pause', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/pause")+')'))
        context_menu_items.append(('Resume', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/resume")+')'))
        context_menu_items.append(('Pause All', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/pauseAll")+')'))
        context_menu_items.append(('Resume All', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/resumeAll")+')'))
        context_menu_items.append(('Force Start', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/setForceStart")+')'))
        context_menu_items.append(('Force Recheck', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/recheck")+')'))
        context_menu_items.append(('Add Torrent from URL', 'XBMC.RunPlugin(plugin://'+settings.__addonID__+'?mode=5&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/download")+')'))
        context_menu_items.append(('Refresh List', 'XBMC.RunPlugin(plugin://'+str(settings.__addonID__)+'?mode=3)'))
        context_menu_items.append(('Go Back', 'XBMC.Action(back)'))
        
        thumbnail_path = settings.__addon__.getAddonInfo('path')+'/icon.png'
        fanart_path = settings.__addon__.getAddonInfo('path')+'/fanart.jpg'
        
        addDirectory(name, title, auth_token, hash, 99, thumbnail_path, fanart_path, list_total, context_menu_items)

    xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    xbmcplugin.setContent(handle=int(sys.argv[1]), content='tvshows')
    common.CreateNotification(header='Torrent List', message=str(list_total)+' Torrents in list', icon=xbmcgui.NOTIFICATION_INFO, time=5000, sound=False)


# Add directory item.
def addDirectory(name, title, auth_token, hash, menu_number, thumbnail_path, fanart_path, list_total, context_menu_items):
    return_url = sys.argv[0]+"?hash="+urllib.quote_plus(str(hash))+"&mode="+str(menu_number)+"&name="+urllib.quote_plus(name.encode( "utf-8" ))
    list_item = xbmcgui.ListItem(title, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    meta = {'title':title}
    list_item.setInfo(type="Video", infoLabels=meta)
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=False, totalItems=list_total)  

