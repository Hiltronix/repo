# -*- coding: utf-8 -*-

#VERSION: 1.00
#DATE: 2017-05-07
#AUTHORS: Hiltronix <hiltronix@gmail.com>
#CONTRIBUTORS: Diego de las Heras (ngosang@hotmail.es)

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the author nor the names of its contributors may be
#      used to endorse or promote products derived from this software without
#      specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.


# *******************
# Testing Purposes Only - Manually set the path to the qBittorrent nova directory.
#import sys
#nova_location = 'C:\\Users\\Carey\\AppData\\Roaming\\Kodi\\addons\\plugin.program.qbittorrent\\resources\\lib\\nova'
#sys.path.insert(0, nova_location)
#import urllib
# *******************


from HTMLParser import HTMLParser
#qBt
from novaprinter import prettyPrinter
from helpers import download_file, retrieve_url


class skytorrents(object):
    """ Search engine class """
    url = 'https://www.skytorrents.in'
    name = 'Sky Torrents'

    class MyHtmlParser(HTMLParser):
        def __init__(self, results, url):
            HTMLParser.__init__(self)
            self.results = results
            self.url = url
            self.td_counter = None
            self.tablerow = False
            self.rowcol = 0
            self.current_item = dict()
            self.current_item['name'] = ''
            self.current_item['size'] = ''
            self.current_item['seeds'] = ''
            self.current_item['leech'] = ''
            self.current_item['link'] = ''
            self.current_item['desc_link'] = ''
            self.current_item['engine_url'] = ''

        def handle_starttag(self, tag, attrs):
            params = dict(attrs)
            if tag == 'tr':
                self.tablerow = True
            if self.tablerow and tag == 'td' and 'style' in params:
                self.rowcol += 1
                return
            if self.tablerow and self.rowcol == 1 and tag == 'a':
                self.current_item['name'] = params.get('title', '')
                self.current_item['desc_link'] = ''.join((self.url, params.get('href', '')))
                self.rowcol += 1
                return
            if self.tablerow and self.rowcol == 2 and tag == 'a':
                torrent = ''.join((self.url, params.get('href', '')))
                if torrent:
                    self.current_item['link'] = torrent
                self.rowcol += 1
                return
            if self.tablerow and self.rowcol == 3 and tag == 'a':
                magnet = params.get('href', '')
                if magnet:  # Replace torrent link with magnet link if it exists.
                    self.current_item['link'] = magnet
                self.rowcol += 1
                return

        def handle_data(self, data):
            if self.tablerow and self.rowcol == 4:
                self.current_item['size'] = data
                return
            if self.tablerow and self.rowcol == 7:
                self.current_item['seeds'] = data
                return
            if self.tablerow and self.rowcol == 8:
                self.current_item['leech'] = data
                return

        def handle_endtag(self, tag):
            if tag == "tr" and self.tablerow and self.rowcol:
                self.current_item['engine_url'] = self.url
                self.tablerow = False
                self.rowcol = 0
                prettyPrinter(self.current_item)
                #print self.current_item
                self.current_item = dict()

    def download_torrent(self, info):
        print(download_file(info))

    def search(self, what, cat='all'):
        """ Performs search """
        results_list = []
        parser = self.MyHtmlParser(results_list, self.url)
        i = 1
        while i < 12:
            # "what" is already urlencoded.
            url = self.url + '/search/all/ed/{}/?l=en-us&q={}'.format(i, what)
            html = retrieve_url(url)
            #print html
            parser.feed(html)
            if len(results_list) < 1:
                break
            del results_list[:]
            i += 1
        parser.close()


# *******************
# Testing Purposes Only.
#if __name__ == '__main__':
#    sky = skytorrents()
#    what = urllib.quote('lucifer s02e14')
#    sky.search(what)
# *******************


