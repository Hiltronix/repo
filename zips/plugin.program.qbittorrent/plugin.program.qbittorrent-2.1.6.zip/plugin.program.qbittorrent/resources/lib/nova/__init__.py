import StringIO

# Buffer used to collect search results from nova2.
searchData = StringIO.StringIO()
