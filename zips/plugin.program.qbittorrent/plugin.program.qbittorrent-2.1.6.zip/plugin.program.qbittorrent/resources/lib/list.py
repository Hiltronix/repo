import xbmc
import xbmcgui
import xbmcplugin
import sys
import urllib
import common
import settings
import utility
import qBitApi


qBit = qBitApi.qBit()


def GetListInfo(filter='all'):
    auth_token = qBit.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    torrents, err_msg, trbk = qBit.GetList(url=settings.__url__, auth_token=auth_token, filter=filter, category='')
    if trbk:
        xbmc.log(trbk, xbmc.LOGERROR)
    if err_msg:
        cur_func_name = sys._getframe().f_code.co_name
        settings.errorWindow(cur_func_name, err_msg)
    torrent_names = []
    for torrent in sorted(torrents, key=lambda k: k['name'], reverse=False):
        name = torrent.get('name', '')
        hash = torrent.get('hash', '')
        state = torrent.get('state', '')
        progress = torrent.get('progress', '')
        size = torrent.get('size', '')
        dlspeed = torrent.get('dlspeed', '')
        upspeed = torrent.get('upspeed', '')
        seeds = torrent.get('num_seeds', '')
        leechers = torrent.get('num_leechs', '')
        eta = torrent.get('eta', '')
        category = torrent.get('category', '')

        try:
            #progress = "{:.0%}".format(float(progress))   # <-- This doesn't work on the Android version of Kodi, causes exception, but not on Windows.
            progress = str(int(progress * 100)) + '%'
        except:
            progress = '?%'
        size = utility.convertBytes(size, 0)
        dlspeed = utility.convertBytes(dlspeed, 0) + '/s'
        upspeed = utility.convertBytes(upspeed, 0) + '/s'
        eta = utility.convertSeconds(eta)

        torrent_names.append([name, '[COLOR gold]'+name+'[/COLOR]  [COLOR cyan]'+state+'[/COLOR]  Done:'+progress+'  '+size+'  Dn:'+dlspeed+'  Up:'+upspeed+'  '+eta, auth_token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, category])
      
    return torrent_names


# Parse through shows and add dirs for each.
def menu(handle=0, filter='all'):
    list_info = GetListInfo(filter)
    total_items = len(list_info)

    if total_items == 0 and filter != 'all':
        settings.my_addon.setSetting('torrent_filter_preselect', '0')   # Revert to default "all" filter.
        settings.messageWindow('Filter [{}]'.format(filter), 'No items to display for this filter selection.[CR]Reverting to "all".')
        xbmc.executebuiltin('Container.Refresh')

    for name, title, auth_token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, category in list_info:

        context_menu_items = []
        context_menu_items.append(('Filter', 'XBMC.RunPlugin(plugin://'+str(settings.pluginID)+'?mode=5)'))
        context_menu_items.append(('Edit Label Category', 'XBMC.RunPlugin(plugin://'+str(settings.pluginID)+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&category='+urllib.quote_plus(category)+'&action='+urllib.quote_plus("/command/setCategory")+')'))
        context_menu_items.append(('Delete', 'XBMC.RunPlugin(plugin://'+str(settings.pluginID)+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/delete")+')'))
        context_menu_items.append(('Delete + Data', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/deletePerm")+')'))
        context_menu_items.append(('Pause', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/pause")+')'))
        context_menu_items.append(('Resume', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/resume")+')'))
        context_menu_items.append(('Pause All', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/pauseAll")+')'))
        context_menu_items.append(('Resume All', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/resumeAll")+')'))
        context_menu_items.append(('Force Start', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/setForceStart")+')'))
        context_menu_items.append(('Force Recheck', 'XBMC.RunPlugin(plugin://'+settings.pluginID+'?mode=4&hash='+hash+'&token='+urllib.quote_plus(auth_token)+'&action='+urllib.quote_plus("/command/recheck")+')'))
        context_menu_items.append(('Refresh List', 'XBMC.RunPlugin(plugin://'+str(settings.pluginID)+'?mode=88)'))
        context_menu_items.append(('Go Back', 'XBMC.Action(back)'))
        
        thumbnail_path = settings.addon_path + '/manage.png'
        fanart_path = settings.addon_path + '/fanart.jpg'
        
        addDirectory(handle, name, title, auth_token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, filter, category, thumbnail_path, fanart_path, total_items, context_menu_items)

    xbmcplugin.addSortMethod(handle=int(handle), sortMethod=xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)
    xbmcplugin.setContent(handle=int(handle), content='tvshows')
    xbmcplugin.endOfDirectory(int(handle))
    # User timer to refresh list to see updated values.
    xbmc.executebuiltin("XBMC.AlarmClock(settings.pluginID, XBMC.Container.Refresh, '00:00:15', true, true)")

    # Only display notification of number of torrents in list when it changes.
    if int(settings.my_addon.getSetting('NumTorrentList')) != total_items:
        common.CreateNotification(header=str(total_items)+' Items', message='in torrent list', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)
    settings.my_addon.setSetting('NumTorrentList', str(total_items))


# Add directory item.
def addDirectory(handle, name, title, auth_token, hash, state, progress, size, dlspeed, upspeed, seeds, leechers, eta, filter, category, thumbnail_path, fanart_path, total_items, context_menu_items):
    return_url = 'plugin://{}/?hash={}&mode={}&name{}'.format(settings.pluginID, urllib.quote_plus(str(hash)), 99, urllib.quote_plus(name.encode("utf-8")))   # mode=99 - Open context menu.
    list_item = xbmcgui.ListItem(title, thumbnailImage=thumbnail_path)
    list_item.setProperty('fanart_image', fanart_path) 
    meta = {}
    meta['title'] = title
    meta['plot'] = '[COLOR gold]{}[/COLOR][CR][COLOR cyan]Status:[/COLOR] {}[CR][COLOR cyan]Size:[/COLOR] {}[CR][COLOR cyan]Done:[/COLOR] {}  [COLOR cyan]ETA:[/COLOR] {}[CR][COLOR cyan]Down:[/COLOR] {}  [COLOR cyan]Up:[/COLOR]{}[CR][COLOR cyan]Seeders:[/COLOR] {}  [COLOR cyan]Leechers:[/COLOR] {}[CR][COLOR cyan]Filter:[/COLOR] {}[CR][COLOR cyan]Label Category:[/COLOR] {}'.format(name[:30]+'...', state, size, progress, eta, dlspeed, upspeed, seeds, leechers, filter, category)
    list_item.setInfo(type="Video", infoLabels=meta)
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(handle), url=return_url, listitem=list_item, isFolder=False, totalItems=total_items)  

