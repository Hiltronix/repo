# -*- coding: utf-8 -*-

import os
import sys
import math


def getFromDict(dataDict, mapList, default_result=None):
# Similar to dictionary '.get' but for nested dictionaies.
# Example: getFromDict(dataDict, ["b", "v", "y"])
# Returns 'None' if not found, unless a default result is provided.
    try:
        value = reduce(lambda d, k: d[k], mapList, dataDict)
        if value:
            return value
        else:
            return default_result
    except Exception:
        return default_result


def convertBytes(size, places):
# Convert bytes to formatted sizes.
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    if (size > 0):
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size/p, places)
        if places == 0:
            s = int(s)
        return '%s %s' %(s, size_name[i])
    else:
        return '0B'


def convertSeconds(secs):
# Convert seconds into years, days, hours, min, seconds.
    years, secs = divmod(secs, 31556952)
    min, secs = divmod(secs, 60)
    hours, min = divmod(min, 60)
    days, hours = divmod(hours, 24)

    string = ''
    if years:
        string = str(years) + 'yrs'
    if days:
        if string:
            string += ','
        string += str(days) + 'days'
    if hours:
        if string:
            string += ','
        string += str(hours) + 'hrs'
    if min:
        if string:
            string += ','
        string += str(min) + 'min'
    if secs:
        if string:
            string += ','
        string += str(min) + 'sec'

    return string
    

def FixBadChar(text):
# Replace troublesome characters, that effect sorting.
    text = text.replace(u'\u2019', u"'")  # Replace curved apostrophe � with standard ' apostrophe.
    text = text.replace(u'\u2010', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2011', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2012', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2013', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2014', u"-")  # Replace wide dash with standard hyphen.
    text = text.replace(u'\u2015', u"-")  # Replace wide dash with standard hyphen.
    return text
    

