import xbmc
import xbmcgui
import xbmcplugin
import sys
import urllib
import common
import utility
import settings
import NovaSearch


def GetListInfo(keywords='', engine='all', category='tv'):
    #engine = 'extratorrent'                 # Options are "all" or any of the file names in the "engines" sub dir (btdigg, demonoid, extratorrent, kickasstorrents, legittorrents, mininova, piratebay, torlock, torrentreactor, torrentz)
    #category = 'tv'                         # CATEGORIES = {'all', 'movies', 'tv', 'music', 'games', 'anime', 'software', 'pictures', 'books'}
    #keywords = 'westworld s01e07'

    # Remove non-alpha-numeric characters.
    keywords = NovaSearch.SanitizeStr(keywords)

    results = NovaSearch.search(engine, category, keywords)

    torrent_names = []
    if results:
        for result in results:
            link = result[0]
            title = result[1]
            size = result[2]
            seeds = result[3]
            leechers = result[4]
            engine_url = result[5]
            webpage = result[6]

            size = utility.convertBytes(size, 0)
            
            torrent_names.append(['[COLOR gold]' + title + '[/COLOR]  [COLOR cyan]Size:[/COLOR]' + size + '  [COLOR cyan]Seeders:[/COLOR]' + str(seeds) + '  ' + '[COLOR cyan]Leechers:[/COLOR]' + str(leechers) + '  ' + engine_url, title, link, size, seeds, leechers, engine_url, webpage])
      
    return torrent_names


# Parse through shows and add dirs for each.
def menu(handle=0, keywords='', engine='all', category=''):
    list_info = GetListInfo(keywords, engine, category)
    total_items = len(list_info)
    for name, title, link, size, seeds, leechers, engine_url, webpage in list_info:

        context_menu_items = []
        context_menu_items.append(('Add Torrent', 'XBMC.RunPlugin(plugin://' + settings.pluginID + '?mode=4&hash=' + urllib.quote_plus(link) + '&action=' + urllib.quote_plus("/command/download") + '&category=' + urllib.quote_plus(category) + ')'))
        context_menu_items.append(('Refresh List', 'XBMC.RunPlugin(plugin://' + str(settings.pluginID) + '?mode=88)'))
        context_menu_items.append(('Go Back', 'XBMC.Action(back)'))
        
        thumbnail_path = settings.addon_path + '/search.png'
        fanart_path = settings.addon_path + '/fanart.jpg'
        banner_path = ''
        
        addDirectory(handle, name, title, link, size, seeds, leechers, engine_url, webpage, category, thumbnail_path, fanart_path, banner_path, total_items, context_menu_items)

    xbmcplugin.addSortMethod(handle=int(handle), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(handle=int(handle), content='tvshows')
    xbmcplugin.endOfDirectory(int(handle))
    common.CreateNotification(header=str(total_items)+ ' Items', message=' in torrent list', icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False)


# Add directory item.
def addDirectory(handle, name, title, link, size, seeds, leechers, engine_url, webpage, category, thumbnail_path, fanart_path, banner_path, total_items, context_menu_items):
    return_url = 'plugin://{}/?mode={}'.format(settings.pluginID, 99)   # mode=99 - Open context menu.
    list_item = xbmcgui.ListItem(name)
    list_item.setArt({'icon': thumbnail_path, 'thumb': thumbnail_path, 'poster': thumbnail_path, 'fanart': fanart_path, 'banner': banner_path, 'clearart': '', 'clearlogo': '', 'landscape': ''})
    list_item.setProperty('LibraryHasMovie', '0')  # Removes the "Play" button from the video info screen, and replaces it with "Browse".
    meta = {}
    meta['title'] = name
    meta['plot'] = '[COLOR gold]{}[/COLOR][CR][COLOR cyan]Size:[/COLOR] {}[CR][COLOR cyan]Seeders:[/COLOR] {}  [COLOR cyan]Leechers:[/COLOR] {}[CR][COLOR cyan]Search Category:[/COLOR] {}[CR]{}'.format(title[:30]+'...', size, seeds, leechers, category, engine_url)
    list_item.setInfo(type="Video", infoLabels=meta)
    list_item.addContextMenuItems(context_menu_items, replaceItems = True)
    xbmcplugin.addDirectoryItem(handle=int(handle), url=return_url, listitem=list_item, isFolder=False, totalItems=total_items)  


