#!/usr/local/bin/python2.7
# -*- coding: utf-8 -*-

# Requires:
#   ParseShowName.py
#   qBittorrent installed.
#       Variable "nova_location" set to the correct directory location.

import os
import re
import sys
import math
import locale
import subprocess
from glob import glob


# Manually set the path to the qBittorrent nova directory.
#nova_location = 'C:\\Users\\Carey\\AppData\\Local\\qBittorrent\\nova'
#sys.path.insert(0, nova_location)
#import nova2

# If the qBitTorrent search files directory named nova is included
# in the package (same dir) then we can call it directly.
try:
    import nova.nova2 as nova2
except ImportError, e:
    print e

# Try to import 3rd party module: parse_torrent_name
try:
    import ParseShowName as PSN
except ImportError, e:
    print e


def convertBytes(size, places):
    # Convert bytes to formatted sizes.
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    size = int(size)
    places = int(places)
    if (size > 0):
        i = int(math.floor(math.log(size, 1024)))
        p = math.pow(1024, i)
        s = round(size/p, places)
        if places == 0:
            s = int(s)
        return '%s %s' %(s, size_name[i])
    else:
        return '0B'


def SanitizeStr(string):
    # Sanitizes string of non-alpha-numeric characters, except spaces.
    string = string.strip()  # Remove whitespace from beginning and end.
    string = string.replace('.', ' ')  # Replace periods with spaces.
    string = string.replace('-', ' ')  # Replace hyphens with spaces.
    string = string.replace('\t', ' ')  # Replace tabs with spaces.
    string = re.sub(' +', ' ',string)  # Remove multiple spaces.
    string = re.sub(r'([^\s\w]|_)+', '', string)  # Remove non-alpha-numeric characters.
    return string


def SupportedEngines():
    # Returns a list of the available search engines.
    supported_engines = []
    supported_engines.append('all')

    engines = glob(os.path.join(os.path.dirname(__file__), 'nova', 'engines', '*.py'))
    for engine in engines:
        engi = os.path.basename(engine).split('.')[0].strip()
        if len(engi) == 0 or engi.startswith('_'):
            continue
        try:
            supported_engines.append(engi)
        except:
            pass

    return supported_engines


def search(engine, category, keywords):
# The qBitTorrent nova search scripts simply print results to stdout, and the data must be parsed from there.
# But if using threads or processes, the output could get mixed with output from other processes.
# So the safest way to get just the data we want is to run it in a separate process using Popen.
    results_list = []

    # "startupinfo" params will be used to hide commandline window on Windows only.
    startupinfo = None
    if os.name == 'nt':
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    #script = os.path.join(nova_location, 'nova2.py')
    script = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'nova', 'nova2.py')
    cmdline = 'python "' + script + '" ' + engine + ' ' + category + ' ' + '"' + keywords + '"'
    SubPro = subprocess.Popen(cmdline, startupinfo=startupinfo, stderr=subprocess.PIPE, stdout=subprocess.PIPE, universal_newlines=True)
    (stdout, stderr) = SubPro.communicate()
    exit_code = SubPro.wait()
    SubPro = None

    # Try to decode to utf-8.  Otherwise convert to ascii and drop unknown characters.
    try:
        output = stdout.decode(sys.stdin.encoding or locale.getpreferredencoding(True))
    except UnicodeDecodeError, e:
        output = stdout.decode('ascii', 'ignore')

    # If data exists in the saved stdout string after execution, parse result into list of lists.
    if output:
        for line in output.splitlines():
            if line.count(u'|') == 6:
                result = line.split('|')
                try:
                    result[2] = int(result[2])
                except ValueError:
                    result[2] = 0
                try:
                    result[3] = int(result[3])
                except ValueError:
                    result[3] = 0
                try:
                    result[4] = int(result[4])
                except ValueError:
                    result[4] = 0
                results_list.append(result)

    if len(results_list) > 1:
        # Sort results list by seeds (fourth field.)
        results_list = sorted(results_list, key=lambda x: x[3], reverse=True)

    return results_list


if __name__ == '__main__':
    if len(sys.argv) == 4:
        engine = sys.argv[1]
        category = sys.argv[2]
        keywords = sys.argv[3]
    else:
        engine = 'extratorrent'                  # Options are "all" or any of the file names in the "engines" sub dir (btdigg, demonoid, extratorrent, kickasstorrents, legittorrents, mininova, piratebay, torlock, torrentreactor, torrentz)
        category = 'tv'                 # CATEGORIES = {'all', 'movies', 'tv', 'music', 'games', 'anime', 'software', 'pictures', 'books'}
        keywords = 'westworld s01e07'

    engine_list = SupportedEngines()

    # Remove non-alpha-numeric characters.
    keywords = SanitizeStr(keywords)

    info = PSN.parse(keywords)
    search_title = info.get('title').lower()
    search_season = info.get('season')
    search_episode = info.get('episode')
    search_quality = info.get('quality')
    search_codec = info.get('codec')

    results = search(engine, category, keywords)

    if results:
        for result in results:
            link = result[0]
            title = result[1]
            size = result[2]
            seeds = result[3]
            leechers = result[4]
            engine_url = result[5]
            webpage = result[6]

            info = PSN.parse(title)
            if search_title in info.get('title').lower() and search_season == info.get('season') and search_episode == info.get('episode'):
                #print result
                print title
                print 'Seeds: %s  Leechers: %s  Size: %s' %(seeds, leechers, convertBytes(size, 1))
                print link
                print

