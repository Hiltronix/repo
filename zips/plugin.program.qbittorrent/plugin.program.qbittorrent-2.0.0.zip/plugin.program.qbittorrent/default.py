import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import os
import sys
import urllib
import resources.lib.list as list
import resources.lib.common as common
import resources.lib.settings as settings
import resources.lib.utility as utility
import resources.lib.searchlist as searchlist
import resources.lib.NovaSearch as NovaSearch

Utility = utility.Util()


pluginID = 'plugin.program.qbittorrent'
my_addon = xbmcaddon.Addon(pluginID)
addon_path = my_addon.getAddonInfo('path')


# Add the main directory folders.
def mainMenu():
    addDirectory('Search - TV Shows', 6, True, addon_path + '/icon.png')
    addDirectory('Search - Movies', 7, True, addon_path + '/icon.png')
    addDirectory('List Torrents (All)', 1, True, addon_path + '/icon.png')
    addDirectory('List Torrents (TV Shows)', 8, True, addon_path + '/icon.png')
    addDirectory('List Torrents (Movies)', 9, True, addon_path + '/icon.png')
    addDirectory('Add Torrent from URL', 5, False, addon_path + '/icon.png')
    addDirectory('Settings', 2, False, addon_path + '/icon.png')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# Add directory item.
def addDirectory(menu_item_name, mode, folder, icon):
    return_url = sys.argv[0]+"?url="+urllib.quote_plus("")+"&mode="+str(mode)+"&name="+urllib.quote_plus(menu_item_name)
    list_item = xbmcgui.ListItem(menu_item_name, iconImage=icon, thumbnailImage=icon)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=return_url, listitem=list_item, isFolder=folder, totalItems=4)


# Get the parameters from the URL supplied as an arg to this script.
def getParameters():
    param=[]
    try:
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
              params=sys.argv[2]
              cleanedparams=params.replace('?','')
              if (params[len(params)-1]=='/'):
                      params=params[0:len(params)-2]
              pairsofparams=cleanedparams.split('&')
              param={}
              for i in range(len(pairsofparams)):
                      splitparams={}
                      splitparams=pairsofparams[i].split('=')
                      if (len(splitparams))==2:
                              param[splitparams[0]]=splitparams[1]
      return param
    except:
      return param
          
          
def showKeyboardDialog(header='Text Entry', text=None):
    keyboard = xbmc.Keyboard(text, header, False)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        text = keyboard.getText()
    else:
        text = ''
    return text  

  
def AddUrl(url):
    url = showKeyboardDialog('Add Torrent from URL', url)
    if (url == ''):
        mainMenu()
    return url
        
    
# Initialize URL parameters.
url = None
keywords = None
name = None
mode = None
token = None
action = None
hash = None
category = None
params = getParameters()

# Parse internal URL.
try:
    url = urllib.unquote_plus(params["url"])
    print url
    mode = 5
except:
    pass

try:
    name = urllib.unquote_plus(params["name"])
    print name
except:
    pass

try:
    number = urllib.unquote_plus(params["number"])
    print number
except:
    pass

try:
    mode = int(params["mode"])
    print mode
except:
    pass
    
try:
    token = urllib.unquote_plus(params["token"])
    print token
except:
    pass

try:
    action = urllib.unquote_plus(params["action"])
    print action
except:
    pass

try:
    hash = urllib.unquote_plus(params["hash"])
    print hash
except:
    pass

try:
    category = urllib.unquote_plus(params["category"])
    print category
except:
    pass

# Open directories based on selection.
if mode == None:
    mainMenu()
       
# Torrent list - all.
elif mode == 1:
    dialog = xbmcgui.Dialog()
    list.menu(category='')

# Torrent list - tv.
elif mode == 8:
    dialog = xbmcgui.Dialog()
    list.menu(category='tv')

# Torrent list - movies.
elif mode == 9:
    dialog = xbmcgui.Dialog()
    list.menu(category='movies')

# Settings menu.
elif mode == 2:
    dialog = xbmcgui.Dialog()
    ret = dialog.select("Settings", ["Search Engine", "Change Log", "App Settings", "Show Server Version", "About"])
    if ret == 0:    # Set default search engine.
        engine_list = NovaSearch.SupportedEngines()
        search_engine = my_addon.getSetting('search_engine')
        try:
            sel = engine_list.index(search_engine)
        except ValueError:
            sel = 0
        dialog = xbmcgui.Dialog()
        eng = dialog.select("Search Engine(s) to Use", engine_list, preselect=sel)
        if (eng == -1):
            exit()
        my_addon.setSetting('search_engine', engine_list[eng])
    
    if ret == 1:    # Change log.
        try:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            filename = os.path.join(addon_path, 'changelog.txt')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = f.read()
            else:
                data = 'Change log not available.'
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        w = common.TextViewer_Dialog('DialogTextViewer.xml', addon_path, header='Change Log', text=data)
        w.doModal()

    if ret == 2:    # Open app settings.
        xbmc.executebuiltin('XBMC.Addon.OpenSettings({0})'.format(pluginID))

    if ret == 3:    # qBitTorrent Version.
        ver = Utility.GetVersion()
        api = Utility.GetApiVersion()
        common.messageWindow('qBittorrent', 'Program Version {}\nAPI Version {}'.format(str(ver), str(api)))

    if ret == 4:    # About.
        try:
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            filename = os.path.join(addon_path, 'about.txt')
            if os.path.isfile(filename):
                with open(filename, 'r') as f:
                    data = f.read()
            else:
                data = 'About file not available.'
        finally:
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        w = common.TextViewer_Dialog('DialogTextViewer.xml', addon_path, header='About', text=data)
        w.doModal()

# Refresh list.
elif mode == 3:
    xbmc.executebuiltin('Container.Refresh')

# Torrent action command.
elif mode == 4:
    auth_token = Utility.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    Utility.TorrentAction(url=settings.__url__, token=auth_token, hash=hash, action=action, category=category)
    if action not in ['/command/download']: # Don't refresh list for these actions.
        xbmc.executebuiltin('Container.Refresh')

# Add Torrent download URL.
elif mode == 5:
    url = AddUrl(url)
    auth_token = Utility.GetQBLoginToken(url=settings.__url__, username=settings.__username__, password=settings.__password__)
    Utility.TorrentAction(url=settings.__url__, token=auth_token, hash=url, action='/command/download', category=category)
    xbmc.executebuiltin('Container.Refresh')

# Search TV Show Torrents.
elif mode == 6:
    #common.messageWindow('Search for Torrent', 'Under construction.')
    keywords = my_addon.getSetting('keywords_tvshows')
    keywords = showKeyboardDialog('TV Show Search Keywords', keywords)
    if (keywords == ''):
        mainMenu()
        exit()
    my_addon.setSetting('keywords_tvshows', keywords)
    search_engine = my_addon.getSetting('search_engine')
    searchlist.menu(keywords=keywords, engine=search_engine, category='tv')

# Search Movies Torrents.
elif mode == 7:
    #common.messageWindow('Search for Torrent', 'Under construction.')
    keywords = my_addon.getSetting('keywords_movies')
    keywords = showKeyboardDialog('Movie Search Keywords', keywords)
    if (keywords == ''):
        mainMenu()
        exit()
    my_addon.setSetting('keywords_movies', keywords)
    search_engine = my_addon.getSetting('search_engine')
    searchlist.menu(keywords=keywords, engine=search_engine, category='movies')

# Open context menu on normal left click selection.
elif mode == 99:
    xbmc.executebuiltin('Action(ContextMenu)')

